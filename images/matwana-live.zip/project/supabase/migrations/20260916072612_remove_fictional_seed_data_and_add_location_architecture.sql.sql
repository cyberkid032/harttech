/*
# Remove Fictional Seed Data & Add Location Architecture

## What this migration does

1. DELETES all fictional/sample matatu data that was inserted during Phase 3.
   This includes all rows in matatus, matatu_aliases, matatu_photos,
   matatu_followers, community_sightings, matatu_verifications, and matatu_reports.
   The tables themselves are kept — only the data is removed.

2. ADDS new tables to support future Google Maps integration:
   - `matatu_locations` — stores community-reported and future live GPS locations
     for matatus. Includes latitude, longitude, timestamp, source type (community vs
     user_consented), consent flag, and expiry time for temporary sharing.
   - `route_stages` — stores named stages/stops along a route with coordinates,
     ready for Google Maps display.

3. All new tables have RLS enabled with anon+authenticated access since this is
   a no-auth app at present.

## Important notes
- No real user data is lost — only fictional sample data inserted by the developer.
- The location tables are empty and ready for future phases. No tracking happens yet.
- Privacy: the `consent_given` column on matatu_locations enforces that all future
  location entries must have explicit consent recorded.
*/

-- Step 1: Remove all fictional seed data
DELETE FROM matatu_reports;
DELETE FROM matatu_verifications;
DELETE FROM community_sightings;
DELETE FROM matatu_followers;
DELETE FROM matatu_photos;
DELETE FROM matatu_aliases;
DELETE FROM matatus;

-- Reset follower count RPC functions (they still work, just no data to operate on)

-- Step 2: Create matatu_locations table for future Google Maps integration
CREATE TABLE IF NOT EXISTS matatu_locations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  matatu_id uuid REFERENCES matatus(id) ON DELETE CASCADE,
  latitude double precision NOT NULL,
  longitude double precision NOT NULL,
  accuracy double precision,
  heading double precision,
  speed double precision,
  source text NOT NULL DEFAULT 'community_reported'
    CHECK (source IN ('community_reported', 'user_consented_riding', 'system_gps')),
  consent_given boolean NOT NULL DEFAULT false,
  reporter_identifier text,
  location_timestamp timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE matatu_locations ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_locations" ON matatu_locations;
CREATE POLICY "anon_select_locations" ON matatu_locations
  FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_locations" ON matatu_locations;
CREATE POLICY "anon_insert_locations" ON matatu_locations
  FOR INSERT TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_locations" ON matatu_locations;
CREATE POLICY "anon_update_locations" ON matatu_locations
  FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_locations" ON matatu_locations;
CREATE POLICY "anon_delete_locations" ON matatu_locations
  FOR DELETE TO anon, authenticated USING (true);

-- Index for quick lookup of latest location per matatu
CREATE INDEX IF NOT EXISTS idx_matatu_locations_matatu_id ON matatu_locations(matatu_id);
CREATE INDEX IF NOT EXISTS idx_matatu_locations_active ON matatu_locations(is_active) WHERE is_active = true;

-- Step 3: Create route_stages table for named stops along routes
CREATE TABLE IF NOT EXISTS route_stages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  route_number text NOT NULL,
  stage_name text NOT NULL,
  latitude double precision,
  longitude double precision,
  display_order integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE route_stages ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_route_stages" ON route_stages;
CREATE POLICY "anon_select_route_stages" ON route_stages
  FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_route_stages" ON route_stages;
CREATE POLICY "anon_insert_route_stages" ON route_stages
  FOR INSERT TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_route_stages" ON route_stages;
CREATE POLICY "anon_update_route_stages" ON route_stages
  FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_route_stages" ON route_stages;
CREATE POLICY "anon_delete_route_stages" ON route_stages
  FOR DELETE TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_route_stages_route_number ON route_stages(route_number);
