/*
# Follower count increment/decrement functions

Creates two SECURITY DEFINER functions to safely adjust matatu follower counts.
These are called when a user follows/unfollows a matatu.

1. `increment_follower_count(matatu_id uuid)` — adds 1 to follower_count
2. `decrement_follower_count(matatu_id uuid)` — subtracts 1 from follower_count (floor at 0)

Both are executable by anon + authenticated roles.
*/

CREATE OR REPLACE FUNCTION increment_follower_count(matatu_id uuid)
RETURNS void AS $$
BEGIN
  UPDATE matatus SET follower_count = follower_count + 1 WHERE id = matatu_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION decrement_follower_count(matatu_id uuid)
RETURNS void AS $$
BEGIN
  UPDATE matatus SET follower_count = GREATEST(follower_count - 1, 0) WHERE id = matatu_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

GRANT EXECUTE ON FUNCTION increment_follower_count TO anon, authenticated;
GRANT EXECUTE ON FUNCTION decrement_follower_count TO anon, authenticated;
