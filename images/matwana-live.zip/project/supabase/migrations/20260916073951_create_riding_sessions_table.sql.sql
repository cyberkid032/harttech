/*
# Create Riding Sessions Table for "I'm Riding" Feature

## What this migration does

1. Creates a `riding_sessions` table to store temporary, anonymous matatu-sharing sessions.
   Each session records:
   - Which matatu the user is riding
   - A private user identifier (stored locally via localStorage, never displayed publicly)
   - The route/destination and stage/landmark the user reported
   - An optional short note
   - Location coordinates (latitude, longitude, accuracy) — only if the user grants permission
   - Session start time and expiry time (sessions auto-expire after 2 hours)
   - Sharing status: 'active', 'stopped', or 'expired'
   - Last location update timestamp

2. Privacy design:
   - The `user_identifier` column is NEVER exposed in public queries. The API layer
     strips it when fetching sessions for public display.
   - Only the user who created a session can stop or update it (matched by identifier).
   - No names, photos, phone numbers, or personal location history are stored.

3. RLS enabled with anon+authenticated access (no-auth app).

## New Tables
- `riding_sessions`
  - id (uuid, primary key)
  - matatu_id (uuid, references matatus, CASCADE on delete)
  - user_identifier (text, private — never displayed publicly)
  - route_or_destination (text, nullable — what the user reports riding)
  - stage_or_landmark (text, nullable — approximate location)
  - note (text, nullable — optional short note)
  - latitude (double precision, nullable — only if location permission granted)
  - longitude (double precision, nullable)
  - location_accuracy (double precision, nullable)
  - location_consent (boolean, default false — explicit consent flag)
  - started_at (timestamptz, default now)
  - expires_at (timestamptz — 2 hours from start)
  - last_location_update (timestamptz, nullable)
  - status (text: 'active', 'stopped', 'expired', default 'active')
  - created_at (timestamptz, default now)
  - updated_at (timestamptz, default now)

## Security
- RLS enabled, anon+authenticated CRUD (no-auth app, intentionally public data)
- The application layer is responsible for stripping user_identifier from public display
*/

CREATE TABLE IF NOT EXISTS riding_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  matatu_id uuid REFERENCES matatus(id) ON DELETE CASCADE,
  user_identifier text NOT NULL,
  route_or_destination text,
  stage_or_landmark text,
  note text,
  latitude double precision,
  longitude double precision,
  location_accuracy double precision,
  location_consent boolean NOT NULL DEFAULT false,
  started_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz NOT NULL DEFAULT (now() + interval '2 hours'),
  last_location_update timestamptz,
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'stopped', 'expired')),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE riding_sessions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_riding_sessions" ON riding_sessions;
CREATE POLICY "anon_select_riding_sessions" ON riding_sessions
  FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_riding_sessions" ON riding_sessions;
CREATE POLICY "anon_insert_riding_sessions" ON riding_sessions
  FOR INSERT TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_riding_sessions" ON riding_sessions;
CREATE POLICY "anon_update_riding_sessions" ON riding_sessions
  FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_riding_sessions" ON riding_sessions;
CREATE POLICY "anon_delete_riding_sessions" ON riding_sessions
  FOR DELETE TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_riding_sessions_active ON riding_sessions(status) WHERE status = 'active';
CREATE INDEX IF NOT EXISTS idx_riding_sessions_matatu_id ON riding_sessions(matatu_id);
