/*
# Matatu Directory Schema — Phase 3

## Overview
Creates the full database structure for the Matatu Directory and Matatu Profiles.
This is a no-auth (single-tenant) app for now — all data is public/shared.
Auth will be added in a future phase. Policies use `TO anon, authenticated`.

## New Tables
1. `routes` — Bus route numbers and their paths
2. `stages` — Pickup/dropoff stages along routes
3. `matatus` — Core matatu records (one per unique vehicle)
4. `matatu_aliases` — Alternative names for a matatu (prevents duplicates from spelling variants)
5. `matatu_photos` — Photos associated with a matatu
6. `matatu_followers` — Users following a matatu (visual follows for now, no auth yet)
7. `community_sightings` — Community-reported sightings of a matatu
8. `matatu_verifications` — Verification records (official vs community vs pending)
9. `matatu_reports` — User-submitted reports about incorrect info

## Key Design Decisions
- A matatu is unique by registration plate (where available) or by name + route.
- Aliases are stored separately so different spellings don't create duplicate matatus.
- Verification is a separate record, not a boolean flag, to support history.
- All tables have `created_at` and `updated_at` timestamps.
- Row Level Security enabled on every table with public read access.
- Insert/update allowed for anon (no auth yet); will be tightened when auth arrives.

## Security
- RLS enabled on all tables.
- SELECT: public (anon + authenticated) — directory is browsable by everyone.
- INSERT: public for now (Add Matatu form needs to work without auth).
- UPDATE/DELETE: public for now (will be restricted to admins/owners with auth).
*/

-- Routes table
CREATE TABLE IF NOT EXISTS routes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  route_number text NOT NULL,
  description text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);
ALTER TABLE routes ENABLE ROW LEVEL SECURITY;

-- Stages table
CREATE TABLE IF NOT EXISTS stages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  route_id uuid REFERENCES routes(id) ON DELETE CASCADE,
  name text NOT NULL,
  sequence int DEFAULT 0,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE stages ENABLE ROW LEVEL SECURITY;

-- Matatus table — core entity
CREATE TABLE IF NOT EXISTS matatus (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  route_id uuid REFERENCES routes(id) ON DELETE SET NULL,
  route_number text,
  destination text NOT NULL,
  sacco text,
  stage text,
  registration_number text,
  capacity text,
  description text,
  cover_image_url text,
  profile_image_url text,
  verification_status text NOT NULL DEFAULT 'pending',
  -- Values: 'verified', 'community_reported', 'pending', 'unverified'
  trending boolean DEFAULT false,
  follower_count int DEFAULT 0,
  sighting_count int DEFAULT 0,
  last_activity_at timestamptz DEFAULT now(),
  color text DEFAULT '#1d4ed8',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);
ALTER TABLE matatus ENABLE ROW LEVEL SECURITY;

-- Matatu aliases — alternative names to prevent duplicates
CREATE TABLE IF NOT EXISTS matatu_aliases (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  matatu_id uuid NOT NULL REFERENCES matatus(id) ON DELETE CASCADE,
  alias text NOT NULL,
  created_at timestamptz DEFAULT now(),
  UNIQUE(matatu_id, alias)
);
ALTER TABLE matatu_aliases ENABLE ROW LEVEL SECURITY;

-- Matatu photos
CREATE TABLE IF NOT EXISTS matatu_photos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  matatu_id uuid NOT NULL REFERENCES matatus(id) ON DELETE CASCADE,
  photo_url text NOT NULL,
  caption text,
  is_cover boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE matatu_photos ENABLE ROW LEVEL SECURITY;

-- Matatu followers (visual follows, no auth yet)
CREATE TABLE IF NOT EXISTS matatu_followers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  matatu_id uuid NOT NULL REFERENCES matatus(id) ON DELETE CASCADE,
  follower_identifier text NOT NULL,
  created_at timestamptz DEFAULT now(),
  UNIQUE(matatu_id, follower_identifier)
);
ALTER TABLE matatu_followers ENABLE ROW LEVEL SECURITY;

-- Community sightings
CREATE TABLE IF NOT EXISTS community_sightings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  matatu_id uuid NOT NULL REFERENCES matatus(id) ON DELETE CASCADE,
  location text,
  route_observed text,
  notes text,
  reporter_identifier text,
  sighting_time timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now()
);
ALTER TABLE community_sightings ENABLE ROW LEVEL SECURITY;

-- Matatu verifications — history of verification status changes
CREATE TABLE IF NOT EXISTS matatu_verifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  matatu_id uuid NOT NULL REFERENCES matatus(id) ON DELETE CASCADE,
  verification_type text NOT NULL,
  -- Values: 'official', 'community', 'self_claimed'
  status text NOT NULL DEFAULT 'pending',
  -- Values: 'verified', 'pending', 'rejected', 'expired'
  verified_by text,
  notes text,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE matatu_verifications ENABLE ROW LEVEL SECURITY;

-- Matatu reports — users reporting incorrect info
CREATE TABLE IF NOT EXISTS matatu_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  matatu_id uuid NOT NULL REFERENCES matatus(id) ON DELETE CASCADE,
  report_type text NOT NULL,
  -- Values: 'wrong_route', 'wrong_name', 'wrong_destination', 'inactive', 'duplicate', 'other'
  details text,
  reporter_identifier text,
  status text DEFAULT 'pending',
  -- Values: 'pending', 'reviewed', 'resolved'
  created_at timestamptz DEFAULT now()
);
ALTER TABLE matatu_reports ENABLE ROW LEVEL SECURITY;

-- Indexes for search performance
CREATE INDEX IF NOT EXISTS idx_matatus_name ON matatus (name);
CREATE INDEX IF NOT EXISTS idx_matatus_route_number ON matatus (route_number);
CREATE INDEX IF NOT EXISTS idx_matatus_destination ON matatus (destination);
CREATE INDEX IF NOT EXISTS idx_matatus_verification_status ON matatus (verification_status);
CREATE INDEX IF NOT EXISTS idx_matatus_trending ON matatus (trending);
CREATE INDEX IF NOT EXISTS idx_matatus_last_activity ON matatus (last_activity_at DESC);
CREATE INDEX IF NOT EXISTS idx_matatus_follower_count ON matatus (follower_count DESC);

CREATE INDEX IF NOT EXISTS idx_matatu_aliases_matatu_id ON matatu_aliases (matatu_id);
CREATE INDEX IF NOT EXISTS idx_matatu_aliases_alias ON matatu_aliases (alias);

CREATE INDEX IF NOT EXISTS idx_matatu_photos_matatu_id ON matatu_photos (matatu_id);
CREATE INDEX IF NOT EXISTS idx_matatu_followers_matatu_id ON matatu_followers (matatu_id);
CREATE INDEX IF NOT EXISTS idx_community_sightings_matatu_id ON community_sightings (matatu_id);
CREATE INDEX IF NOT EXISTS idx_matatu_verifications_matatu_id ON matatu_verifications (matatu_id);
CREATE INDEX IF NOT EXISTS idx_matatu_reports_matatu_id ON matatu_reports (matatu_id);

-- RLS Policies: SELECT (public read for all tables)
DROP POLICY IF EXISTS "public_select_routes" ON routes;
CREATE POLICY "public_select_routes" ON routes FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "public_select_stages" ON stages;
CREATE POLICY "public_select_stages" ON stages FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "public_select_matatus" ON matatus;
CREATE POLICY "public_select_matatus" ON matatus FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "public_select_matatu_aliases" ON matatu_aliases;
CREATE POLICY "public_select_matatu_aliases" ON matatu_aliases FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "public_select_matatu_photos" ON matatu_photos;
CREATE POLICY "public_select_matatu_photos" ON matatu_photos FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "public_select_matatu_followers" ON matatu_followers;
CREATE POLICY "public_select_matatu_followers" ON matatu_followers FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "public_select_community_sightings" ON community_sightings;
CREATE POLICY "public_select_community_sightings" ON community_sightings FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "public_select_matatu_verifications" ON matatu_verifications;
CREATE POLICY "public_select_matatu_verifications" ON matatu_verifications FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "public_select_matatu_reports" ON matatu_reports;
CREATE POLICY "public_select_matatu_reports" ON matatu_reports FOR SELECT TO anon, authenticated USING (true);

-- RLS Policies: INSERT (public for now — no auth yet)
DROP POLICY IF EXISTS "public_insert_matatus" ON matatus;
CREATE POLICY "public_insert_matatus" ON matatus FOR INSERT TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "public_insert_matatu_aliases" ON matatu_aliases;
CREATE POLICY "public_insert_matatu_aliases" ON matatu_aliases FOR INSERT TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "public_insert_matatu_photos" ON matatu_photos;
CREATE POLICY "public_insert_matatu_photos" ON matatu_photos FOR INSERT TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "public_insert_matatu_followers" ON matatu_followers;
CREATE POLICY "public_insert_matatu_followers" ON matatu_followers FOR INSERT TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "public_insert_community_sightings" ON community_sightings;
CREATE POLICY "public_insert_community_sightings" ON community_sightings FOR INSERT TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "public_insert_matatu_reports" ON matatu_reports;
CREATE POLICY "public_insert_matatu_reports" ON matatu_reports FOR INSERT TO anon, authenticated WITH CHECK (true);

-- RLS Policies: UPDATE (public for now — will be restricted with auth)
DROP POLICY IF EXISTS "public_update_matatus" ON matatus;
CREATE POLICY "public_update_matatus" ON matatus FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

-- RLS Policies: DELETE (public for now — will be restricted with auth)
DROP POLICY IF EXISTS "public_delete_matatu_followers" ON matatu_followers;
CREATE POLICY "public_delete_matatu_followers" ON matatu_followers FOR DELETE TO anon, authenticated USING (true);

-- updated_at trigger
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS matatus_updated_at ON matatus;
CREATE TRIGGER matatus_updated_at BEFORE UPDATE ON matatus
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

DROP TRIGGER IF EXISTS routes_updated_at ON routes;
CREATE TRIGGER routes_updated_at BEFORE UPDATE ON routes
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();
