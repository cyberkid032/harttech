import { RouterProvider, useRouter } from '@/router';
import AppNav from '@/components/AppNav';
import Landing from '@/pages/Landing';
import Home from '@/pages/Home';
import Explore from '@/pages/Explore';
import Map from '@/pages/Map';
import Create from '@/pages/Create';
import AddMatatu from '@/pages/AddMatatu';
import Notifications from '@/pages/Notifications';
import Profile from '@/pages/Profile';
import MatatuDetails from '@/pages/MatatuDetails';

function AppContent() {
  const { page } = useRouter();

  if (page === 'landing') {
    return <Landing />;
  }

  const pageMap = {
    home: <Home />,
    explore: <Explore />,
    map: <Map />,
    create: <Create />,
    'add-matatu': <AddMatatu />,
    notifications: <Notifications />,
    profile: <Profile />,
    details: <MatatuDetails />,
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <AppNav />
      <main className="md:ml-64 min-h-screen pb-20 md:pb-0">
        <div className="mx-auto max-w-5xl px-4 py-6 sm:px-6 sm:py-8">
          <div key={page} className="animate-fade-up">
            {pageMap[page]}
          </div>
        </div>
      </main>
    </div>
  );
}

export default function App() {
  return (
    <RouterProvider>
      <AppContent />
    </RouterProvider>
  );
}
