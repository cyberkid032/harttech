import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import type { PageId } from '@/types';

interface RouterContextValue {
  page: PageId;
  param: string | null;
  navigate: (page: PageId, param?: string) => void;
}

const RouterContext = createContext<RouterContextValue | undefined>(undefined);

function parseHash(): { page: PageId; param: string | null } {
  const raw = window.location.hash.replace('#/', '').replace('#', '');
  const [pagePart, paramPart] = raw.split('/');
  const valid: PageId[] = ['landing', 'home', 'explore', 'map', 'create', 'add-matatu', 'notifications', 'profile', 'details'];
  if (valid.includes(pagePart as PageId)) {
    return { page: pagePart as PageId, param: paramPart || null };
  }
  return { page: 'landing', param: null };
}

export function RouterProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState(() => parseHash());

  useEffect(() => {
    const handler = () => setState(parseHash());
    window.addEventListener('hashchange', handler);
    return () => window.removeEventListener('hashchange', handler);
  }, []);

  const navigate = (next: PageId, param?: string) => {
    if (param) {
      window.location.hash = `/${next}/${param}`;
    } else {
      window.location.hash = `/${next}`;
    }
    setState({ page: next, param: param || null });
    window.scrollTo({ top: 0, behavior: 'instant' });
  };

  return (
    <RouterContext.Provider value={{ page: state.page, param: state.param, navigate }}>
      {children}
    </RouterContext.Provider>
  );
}

export function useRouter() {
  const ctx = useContext(RouterContext);
  if (!ctx) throw new Error('useRouter must be used within RouterProvider');
  return ctx;
}
