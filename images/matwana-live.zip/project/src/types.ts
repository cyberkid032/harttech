export type PageId =
  | 'landing'
  | 'home'
  | 'explore'
  | 'map'
  | 'create'
  | 'add-matatu'
  | 'notifications'
  | 'profile'
  | 'details';

export interface Feature {
  id: string;
  title: string;
  description: string;
  icon: string;
  accent: boolean;
}

export interface CreateOption {
  id: string;
  title: string;
  description: string;
  icon: string;
  badge: string;
}

export interface Destination {
  id: string;
  name: string;
  icon: string;
}
