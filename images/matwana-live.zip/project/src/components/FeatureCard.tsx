import type { Feature } from '@/types';
import { Compass, Share2, Users, MapPin } from 'lucide-react';

const iconMap = { Compass, Share2, Users, MapPin };

interface FeatureCardProps {
  feature: Feature;
  index?: number;
}

export default function FeatureCard({ feature, index = 0 }: FeatureCardProps) {
  const Icon = iconMap[feature.icon as keyof typeof iconMap] ?? Compass;

  return (
    <div
      className="group relative rounded-2xl bg-white p-6 shadow-card transition-all duration-300 hover:shadow-card-hover hover:-translate-y-1 animate-fade-up border border-primary-100/40"
      style={{ animationDelay: `${index * 0.1}s` }}
    >
      {feature.accent && (
        <div className="absolute -top-3 -right-3 rounded-full bg-accent px-3 py-1 text-xs font-bold text-white shadow-card">
          Community
        </div>
      )}
      <div
        className={`mb-4 flex h-12 w-12 items-center justify-center rounded-xl transition-colors ${
          feature.accent
            ? 'bg-accent/15 text-accent-dark'
            : 'bg-primary-50 text-primary group-hover:bg-primary group-hover:text-white'
        }`}
      >
        <Icon className="h-6 w-6" />
      </div>
      <h3 className="font-display text-lg font-bold text-ink mb-2">{feature.title}</h3>
      <p className="text-sm leading-relaxed text-ink-muted">{feature.description}</p>
    </div>
  );
}
