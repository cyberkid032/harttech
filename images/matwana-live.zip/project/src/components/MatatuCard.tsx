import { useState } from 'react';
import type { MatatuRecord, RidingSession } from '@/lib/matatuApi';
import {
  MapPin, Users, Tag, Heart, ArrowRight, TrendingUp, Eye, Clock,
  Navigation, Radio,
} from 'lucide-react';
import VerificationBadge from './VerificationBadge';
import RouteLabel from './RouteLabel';
import Button from './Button';
import ImRidingModal from './ImRidingModal';

interface MatatuCardProps {
  matatu: MatatuRecord;
  onOpenDetails?: () => void;
  showTrending?: boolean;
  riderCount?: number;
  liveStatus?: 'live' | 'recent' | 'unverified' | null;
  isDemo?: boolean;
}

function timeAgo(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  return `${days}d ago`;
}

const liveStatusConfig = {
  live: { label: 'Live', color: 'bg-green-500', textColor: 'text-green-600', dot: 'animate-pulse' },
  recent: { label: 'Recent', color: 'bg-amber-500', textColor: 'text-amber-600', dot: '' },
  unverified: { label: 'Unverified', color: 'bg-gray-400', textColor: 'text-gray-500', dot: '' },
};

export default function MatatuCard({
  matatu,
  onOpenDetails,
  showTrending = false,
  riderCount = 0,
  liveStatus = null,
  isDemo = false,
}: MatatuCardProps) {
  const [favorited, setFavorited] = useState(false);
  const [showRidingModal, setShowRidingModal] = useState(false);
  const [mySession, setMySession] = useState<RidingSession | null>(null);

  const handleFavorite = (e: React.MouseEvent) => {
    e.stopPropagation();
    setFavorited(!favorited);
  };

  const coverImage = matatu.cover_image_url || matatu.profile_image_url;
  const status = liveStatus ? liveStatusConfig[liveStatus] : null;

  return (
    <>
      <div
        onClick={onOpenDetails}
        className="group cursor-pointer overflow-hidden rounded-2xl bg-white shadow-card transition-all duration-300 hover:shadow-card-hover hover:-translate-y-0.5 border border-primary-100/30"
      >
        <div
          className="relative h-28 flex items-end p-4"
          style={{
            background: coverImage
              ? `linear-gradient(135deg, ${matatu.color}99, ${matatu.color}cc), url(${coverImage}) center/cover`
              : `linear-gradient(135deg, ${matatu.color}, ${matatu.color}cc)`,
          }}
        >
          <div className="absolute inset-0 bg-grid opacity-30" />

          {showTrending && matatu.trending && (
            <div className="absolute top-3 left-3 flex items-center gap-1 rounded-full bg-accent px-2 py-0.5 text-[10px] font-bold text-white shadow-glow">
              <TrendingUp className="h-3 w-3" />
              Trending
            </div>
          )}

          {isDemo && (
            <div className="absolute top-3 left-3 flex items-center gap-1 rounded-full bg-amber-500 px-2 py-0.5 text-[10px] font-bold text-white">
              Demo
            </div>
          )}

          <div className="absolute top-3 right-3 flex items-center gap-1.5">
            {status && (
              <span className={`flex items-center gap-1 rounded-full bg-white/90 px-2 py-0.5 text-[9px] font-bold uppercase ${status.textColor}`}>
                <span className={`h-1.5 w-1.5 rounded-full ${status.color} ${status.dot}`} />
                {status.label}
              </span>
            )}
            <VerificationBadge status={matatu.verification_status} size="sm" />
          </div>

          <div className="relative z-10">
            <RouteLabel routeNumber={matatu.route_number || '—'} size="md" />
          </div>

          <button
            onClick={handleFavorite}
            aria-label="Favorite"
            className="absolute bottom-3 right-3 flex h-9 w-9 items-center justify-center rounded-full bg-white/20 backdrop-blur-sm transition-all hover:bg-white/30 active:scale-90"
          >
            <Heart
              className={`h-4 w-4 transition-all ${favorited ? 'fill-accent text-accent' : 'text-white'}`}
            />
          </button>
        </div>

        <div className="p-4">
          <h3 className="font-display text-base font-bold text-ink mb-1 group-hover:text-primary transition-colors">
            {matatu.name}
          </h3>

          {matatu.aliases && matatu.aliases.length > 0 && (
            <p className="text-[11px] text-ink-muted mb-1.5">
              Also known as: {matatu.aliases.join(', ')}
            </p>
          )}

          <div className="flex items-center gap-1.5 text-xs text-ink-muted mb-2">
            <MapPin className="h-3.5 w-3.5 text-primary" />
            <span className="truncate">{matatu.destination}</span>
          </div>

          {matatu.stage && (
            <div className="mb-2 text-[11px] text-ink-muted">
              Stage: <span className="font-medium text-ink-soft">{matatu.stage}</span>
            </div>
          )}

          {matatu.sacco && (
            <div className="mb-2 text-[11px] text-ink-muted">
              Sacco: <span className="font-medium text-ink-soft">{matatu.sacco}</span>
            </div>
          )}

          <div className="flex items-center justify-between border-t border-gray-100 pt-2.5 text-xs text-ink-muted">
            <span className="flex items-center gap-1">
              <Users className="h-3.5 w-3.5" />
              {matatu.follower_count.toLocaleString()}
            </span>
            {riderCount > 0 ? (
              <span className="flex items-center gap-1 text-green-600 font-semibold">
                <Radio className="h-3.5 w-3.5" />
                {riderCount} {riderCount === 1 ? 'rider' : 'riders'}
              </span>
            ) : (
              <span className="flex items-center gap-1">
                <Eye className="h-3.5 w-3.5" />
                {matatu.sighting_count}
              </span>
            )}
            <span className="flex items-center gap-1">
              <Clock className="h-3.5 w-3.5" />
              {timeAgo(matatu.last_activity_at)}
            </span>
          </div>

          {/* Action buttons */}
          <div className="mt-3 flex gap-2">
            <button
              onClick={(e) => { e.stopPropagation(); onOpenDetails?.(); }}
              className="flex-1 flex items-center justify-center gap-1.5 rounded-xl bg-primary-50 py-2.5 text-xs font-bold text-primary transition-all hover:bg-primary hover:text-white active:scale-[0.98]"
            >
              View Profile
              <ArrowRight className="h-3.5 w-3.5" />
            </button>
            <button
              onClick={(e) => { e.stopPropagation(); setShowRidingModal(true); }}
              className="flex items-center justify-center gap-1.5 rounded-xl bg-accent/10 px-3 py-2.5 text-xs font-bold text-accent transition-all hover:bg-accent hover:text-white active:scale-[0.98]"
            >
              <Navigation className="h-3.5 w-3.5" />
              Share
            </button>
          </div>
        </div>
      </div>

      <ImRidingModal
        open={showRidingModal}
        onClose={() => setShowRidingModal(false)}
        onStarted={(session) => { setMySession(session); setShowRidingModal(false); }}
        preselectedMatatu={matatu}
      />
    </>
  );
}
