import { useState, useEffect } from 'react';
import { Navigation, Clock, MapPin, Square, Info, ShieldCheck } from 'lucide-react';
import Button from '@/components/Button';
import RouteLabel from '@/components/RouteLabel';
import {
  stopRidingSession, getTimeRemaining,
  type RidingSession,
} from '@/lib/matatuApi';

interface SharingStatusCardProps {
  session: RidingSession;
  onStopped: () => void;
  onExpired: () => void;
}

export default function SharingStatusCard({ session, onStopped, onExpired }: SharingStatusCardProps) {
  const [timeRemaining, setTimeRemaining] = useState(getTimeRemaining(session.expires_at));
  const [stopping, setStopping] = useState(false);
  const [stopped, setStopped] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
      const remaining = getTimeRemaining(session.expires_at);
      setTimeRemaining(remaining);
      if (remaining.expired) {
        clearInterval(interval);
        setStopped(true);
        onExpired();
      }
    }, 1000);
    return () => clearInterval(interval);
  }, [session.expires_at, onExpired]);

  const handleStop = async () => {
    setStopping(true);
    await stopRidingSession(session.id);
    setStopping(false);
    setStopped(true);
    onStopped();
  };

  const lastUpdate = session.last_location_update
    ? new Date(session.last_location_update).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    : 'No location shared';

  if (stopped) {
    return (
      <div className="rounded-3xl bg-white p-6 shadow-card border border-primary-100/30 text-center">
        <div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-full bg-primary-50">
          <Info className="h-7 w-7 text-primary" />
        </div>
        <h3 className="font-display text-base font-bold text-ink">Your ride-sharing session has ended</h3>
        <p className="mt-1.5 text-sm text-ink-muted max-w-sm mx-auto">
          You are no longer sharing your location. Thank you for contributing to the community.
        </p>
        <div className="mt-4">
          <Button variant="outline" size="sm" onClick={onStopped}>
            Done
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="rounded-3xl bg-ink p-6 text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-grid opacity-20" />
        <div className="absolute inset-0 bg-gradient-to-br from-primary/30 to-transparent" />
        <div className="relative">
          {/* Header */}
          <div className="flex items-center gap-3 mb-4">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-accent">
              <Navigation className="h-5 w-5 text-white" />
            </div>
            <div className="flex-1">
              <h3 className="font-display text-base font-bold">You Are Sharing</h3>
              <p className="text-[11px] text-white/50">Sharing anonymously</p>
            </div>
            <div className="flex items-center gap-1.5 rounded-full bg-accent/20 px-3 py-1">
              <div className="h-2 w-2 rounded-full bg-accent animate-pulse" />
              <span className="text-[10px] font-bold uppercase tracking-wider text-accent">Live</span>
            </div>
          </div>

          {/* Matatu info */}
          <div className="rounded-xl bg-white/10 p-3 mb-4">
            <p className="font-display text-sm font-bold">{session.matatu_name || 'Matatu'}</p>
            <div className="mt-1 flex items-center gap-2">
              {session.matatu_route_number && (
                <RouteLabel routeNumber={session.matatu_route_number} size="sm" />
              )}
              {session.matatu_destination && (
                <span className="text-xs text-white/60 truncate">{session.matatu_destination}</span>
              )}
            </div>
          </div>

          {/* Details grid */}
          <div className="grid grid-cols-2 gap-3 mb-4">
            <div className="rounded-xl bg-white/5 p-3">
              <p className="text-[10px] font-semibold uppercase tracking-wider text-white/40">Time Remaining</p>
              <p className="mt-1 font-display text-lg font-extrabold tabular-nums">
                {timeRemaining.minutes}m {timeRemaining.seconds}s
              </p>
            </div>
            <div className="rounded-xl bg-white/5 p-3">
              <p className="text-[10px] font-semibold uppercase tracking-wider text-white/40">Last Update</p>
              <p className="mt-1 flex items-center gap-1.5 text-sm font-semibold">
                <Clock className="h-3.5 w-3.5 text-accent" />
                {lastUpdate}
              </p>
            </div>
            {session.stage_or_landmark && (
              <div className="rounded-xl bg-white/5 p-3 col-span-2">
                <p className="text-[10px] font-semibold uppercase tracking-wider text-white/40">Approximate Location</p>
                <p className="mt-1 flex items-center gap-1.5 text-sm font-medium">
                  <MapPin className="h-3.5 w-3.5 text-accent" />
                  {session.stage_or_landmark}
                </p>
              </div>
            )}
          </div>

          {/* Privacy reminder */}
          <div className="flex items-start gap-2 mb-4 rounded-xl bg-white/5 p-3">
            <ShieldCheck className="h-4 w-4 text-accent flex-shrink-0 mt-0.5" />
            <p className="text-[11px] text-white/60 leading-relaxed">
              You are sharing anonymously. Your session will expire automatically. You can stop at any time.
            </p>
          </div>

          {/* Stop button */}
          <button
            onClick={handleStop}
            disabled={stopping}
            className="w-full flex items-center justify-center gap-2 rounded-xl bg-red-500 py-3 text-sm font-bold text-white transition-all hover:bg-red-600 active:scale-[0.98] disabled:opacity-50"
          >
            <Square className="h-4 w-4 fill-white" />
            {stopping ? 'Stopping...' : 'Stop Sharing'}
          </button>
        </div>
      </div>
  );
}
