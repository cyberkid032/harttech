import { useState } from 'react';
import { Menu, X } from 'lucide-react';
import Logo from './Logo';
import Button from './Button';
import { useRouter } from '@/router';

export default function Navbar() {
  const { navigate } = useRouter();
  const [open, setOpen] = useState(false);

  const links = [
    { label: 'Home', page: 'home' as const },
    { label: 'Explore', page: 'explore' as const },
    { label: 'About', page: 'landing' as const },
  ];

  return (
    <header className="sticky top-0 z-50 border-b border-primary-100/30 bg-white/80 backdrop-blur-lg">
      <nav className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6">
        <button onClick={() => navigate('landing')} aria-label="Matwana Live home">
          <Logo size="md" />
        </button>

        <div className="hidden items-center gap-8 md:flex">
          {links.map((link) => (
            <button
              key={link.label}
              onClick={() => navigate(link.page)}
              className="text-sm font-medium text-ink-soft transition-colors hover:text-primary"
            >
              {link.label}
            </button>
          ))}
        </div>

        <div className="hidden md:flex items-center gap-3">
          <Button variant="ghost" size="sm" onClick={() => navigate('profile')}>
            Sign In
          </Button>
          <Button variant="primary" size="sm" onClick={() => navigate('home')}>
            Join Matwana Live
          </Button>
        </div>

        <button
          className="flex h-10 w-10 items-center justify-center rounded-lg text-ink md:hidden"
          onClick={() => setOpen(!open)}
          aria-label="Toggle menu"
        >
          {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </nav>

      {open && (
        <div className="border-t border-primary-100/30 bg-white px-4 py-4 md:hidden">
          <div className="flex flex-col gap-3">
            {links.map((link) => (
              <button
                key={link.label}
                onClick={() => {
                  navigate(link.page);
                  setOpen(false);
                }}
                className="rounded-lg px-4 py-2.5 text-left text-sm font-medium text-ink-soft hover:bg-primary-50"
              >
                {link.label}
              </button>
            ))}
            <div className="flex flex-col gap-2 pt-2">
              <Button variant="outline" size="sm" onClick={() => { navigate('profile'); setOpen(false); }}>
                Sign In
              </Button>
              <Button variant="primary" size="sm" onClick={() => { navigate('home'); setOpen(false); }}>
                Join Matwana Live
              </Button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
