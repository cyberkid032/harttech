import { Search, X } from 'lucide-react';

interface SearchFieldProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  onClear?: () => void;
  onFocus?: () => void;
}

export default function SearchField({
  value,
  onChange,
  placeholder = 'Search...',
  onClear,
  onFocus,
}: SearchFieldProps) {
  return (
    <div className="relative">
      <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-ink-muted pointer-events-none" />
      <input
        type="text"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        onFocus={onFocus}
        placeholder={placeholder}
        className="w-full rounded-full border-2 border-primary-100 bg-white py-3.5 pl-12 pr-12 text-sm text-ink shadow-card outline-none transition-all focus:border-primary focus:ring-2 focus:ring-primary/10"
      />
      {value && (
        <button
          onClick={() => {
            onChange('');
            onClear?.();
          }}
          className="absolute right-4 top-1/2 -translate-y-1/2 text-ink-muted hover:text-primary transition-colors"
          aria-label="Clear search"
        >
          <X className="h-5 w-5" />
        </button>
      )}
    </div>
  );
}
