import { Navigation } from 'lucide-react';

interface RouteLabelProps {
  routeNumber: string;
  size?: 'sm' | 'md' | 'lg';
}

export default function RouteLabel({ routeNumber, size = 'md' }: RouteLabelProps) {
  const sizeClasses = {
    sm: 'px-2 py-0.5 text-[10px]',
    md: 'px-2.5 py-1 text-xs',
    lg: 'px-3 py-1.5 text-sm',
  }[size];

  return (
    <span className={`inline-flex items-center gap-1 rounded-lg bg-ink font-display font-bold text-white ${sizeClasses}`}>
      <Navigation className={size === 'lg' ? 'h-3.5 w-3.5 text-accent' : 'h-3 w-3 text-accent'} />
      {routeNumber}
    </span>
  );
}
