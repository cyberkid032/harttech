import {
  Navigation, MapPin, Clock, Users, ArrowRight, Radio, Eye,
} from 'lucide-react';
import RouteLabel from '@/components/RouteLabel';
import Button from '@/components/Button';
import { getStatusConfig, type MapMarkerData } from '@/lib/googleMaps';

interface MapMarkerInfoCardProps {
  marker: MapMarkerData;
  onViewProfile: (matatuId: string) => void;
  onShare: (matatuId: string, matatuName: string) => void;
}

function timeAgo(iso: string | null): string {
  if (!iso) return 'Unknown';
  const diff = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'Just now';
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  return `${days}d ago`;
}

export default function MapMarkerInfoCard({ marker, onViewProfile, onShare }: MapMarkerInfoCardProps) {
  const statusCfg = getStatusConfig(marker.locationStatus);

  return (
    <div className="rounded-2xl bg-white p-4 shadow-card-hover border border-primary-100/40 max-w-sm">
      {/* Header: name + status */}
      <div className="flex items-start justify-between gap-2 mb-2">
        <div className="flex items-center gap-2 min-w-0">
          <div
            className="flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-lg text-white"
            style={{ background: marker.color || '#1d4ed8' }}
          >
            <Navigation className="h-4 w-4" />
          </div>
          <div className="min-w-0">
            <h3 className="font-display text-sm font-bold text-ink truncate">{marker.matatuName}</h3>
            {marker.routeNumber && (
              <div className="mt-0.5">
                <RouteLabel routeNumber={marker.routeNumber} size="sm" />
              </div>
            )}
          </div>
        </div>
        <span className={`flex items-center gap-1 rounded-full px-2 py-0.5 text-[9px] font-bold uppercase ${statusCfg.bgClass} ${statusCfg.textClass} flex-shrink-0`}>
          <span className={`h-1.5 w-1.5 rounded-full ${statusCfg.dotClass}`} style={{ backgroundColor: statusCfg.color }} />
          {statusCfg.label}
        </span>
      </div>

      {/* Destination */}
      {marker.destination && (
        <div className="flex items-center gap-1.5 text-xs text-ink-muted mb-2">
          <MapPin className="h-3.5 w-3.5 text-primary" />
          <span className="truncate">{marker.destination}</span>
        </div>
      )}

      {/* Stage/landmark */}
      {marker.stageOrLandmark && (
        <div className="text-[11px] text-ink-muted mb-2">
          Stage: <span className="font-medium text-ink-soft">{marker.stageOrLandmark}</span>
        </div>
      )}

      {/* Community report label */}
      {marker.isCommunityReport && (
        <div className="mb-2 inline-flex items-center gap-1 rounded-full bg-amber-50 px-2 py-0.5 text-[10px] font-semibold text-amber-600">
          <Eye className="h-2.5 w-2.5" />
          Community Reported
        </div>
      )}

      {/* Stats row */}
      <div className="flex items-center gap-3 text-[11px] text-ink-muted border-t border-gray-100 pt-2 mb-3">
        <span className="flex items-center gap-1">
          <Clock className="h-3 w-3" />
          {timeAgo(marker.lastUpdated)}
        </span>
        {marker.riderCount > 0 ? (
          <span className="flex items-center gap-1 text-green-600 font-semibold">
            <Radio className="h-3 w-3" />
            {marker.riderCount} {marker.riderCount === 1 ? 'rider' : 'riders'}
          </span>
        ) : (
          <span className="flex items-center gap-1">
            <Users className="h-3 w-3" />
            No active riders
          </span>
        )}
      </div>

      {/* Anonymous privacy note */}
      {marker.riderCount > 0 && !marker.isCommunityReport && (
        <p className="text-[10px] text-ink-muted leading-relaxed mb-3 italic">
          An anonymous rider is currently sharing this matatu.
        </p>
      )}

      {/* Actions */}
      <div className="flex gap-2">
        <button
          onClick={() => onViewProfile(marker.matatuId)}
          className="flex-1 flex items-center justify-center gap-1.5 rounded-xl bg-primary-50 py-2 text-xs font-bold text-primary transition-all hover:bg-primary hover:text-white active:scale-[0.98]"
        >
          View Profile
          <ArrowRight className="h-3 w-3" />
        </button>
        <button
          onClick={() => onShare(marker.matatuId, marker.matatuName)}
          className="flex items-center justify-center gap-1.5 rounded-xl bg-accent/10 px-3 py-2 text-xs font-bold text-accent transition-all hover:bg-accent hover:text-white active:scale-[0.98]"
        >
          <Navigation className="h-3.5 w-3.5" />
          Share
        </button>
      </div>
    </div>
  );
}
