import { useRouter } from '@/router';
import Logo from './Logo';

export default function Footer() {
  const { navigate } = useRouter();

  const sections = [
    {
      title: 'Platform',
      links: [
        { label: 'Explore Matatus', page: 'explore' as const },
        { label: 'Map View', page: 'map' as const },
        { label: 'Create', page: 'create' as const },
      ],
    },
    {
      title: 'Community',
      links: [
        { label: 'About', page: 'landing' as const },
        { label: 'Community Guidelines', page: 'landing' as const },
        { label: 'Home', page: 'home' as const },
      ],
    },
    {
      title: 'Legal',
      links: [
        { label: 'Privacy Policy', page: 'landing' as const },
        { label: 'Contact', page: 'landing' as const },
        { label: 'Terms', page: 'landing' as const },
      ],
    },
  ];

  return (
    <footer className="bg-ink text-white">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
        <div className="grid gap-8 md:grid-cols-4">
          <div className="md:col-span-1">
            <Logo size="md" variant="light" />
            <p className="mt-4 text-sm text-white/60 leading-relaxed">
              We Ride. We Share. We Connect. Kenya's matatu culture, together in one place.
            </p>
          </div>

          {sections.map((section) => (
            <div key={section.title}>
              <h4 className="font-display text-sm font-bold uppercase tracking-wider text-white/80 mb-3">
                {section.title}
              </h4>
              <ul className="space-y-2">
                {section.links.map((link) => (
                  <li key={link.label}>
                    <button
                      onClick={() => navigate(link.page)}
                      className="text-sm text-white/60 transition-colors hover:text-accent"
                    >
                      {link.label}
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-10 flex flex-col items-center justify-between gap-4 border-t border-white/10 pt-6 sm:flex-row">
          <p className="text-xs text-white/40">
            &copy; {new Date().getFullYear()} Matwana Live. Sacco-neutral. Community-first.
          </p>
          <p className="text-xs text-white/40">
            Built in Kenya for the matatu community.
          </p>
        </div>
      </div>
    </footer>
  );
}
