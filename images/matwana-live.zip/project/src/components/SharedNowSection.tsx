import { Navigation, Clock, MapPin, Users, ArrowRight, Radio, Info } from 'lucide-react';
import Button from '@/components/Button';
import RouteLabel from '@/components/RouteLabel';
import { getLocationStatus, type RidingSession } from '@/lib/matatuApi';

interface SharedNowSectionProps {
  sessions: RidingSession[];
  loading: boolean;
  onViewMap: () => void;
  onViewDetails: (matatuId: string) => void;
}

function timeAgo(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'Just now';
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.floor(mins / 60);
  return `${hours}h ago`;
}

const statusConfig = {
  live: { label: 'Live', color: 'bg-green-500', textColor: 'text-green-600', dot: 'animate-pulse' },
  recent: { label: 'Recent', color: 'bg-amber-500', textColor: 'text-amber-600', dot: '' },
  unverified: { label: 'Unverified', color: 'bg-gray-400', textColor: 'text-gray-500', dot: '' },
};

export default function SharedNowSection({ sessions, loading, onViewMap, onViewDetails }: SharedNowSectionProps) {
  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Radio className="h-5 w-5 text-primary" />
          <h2 className="font-display text-lg font-bold text-ink">Matatus Being Shared Now</h2>
        </div>
        {sessions.length > 0 && (
          <button
            onClick={onViewMap}
            className="text-xs font-semibold text-primary flex items-center gap-1 hover:gap-2 transition-all"
          >
            View on Map <ArrowRight className="h-3.5 w-3.5" />
          </button>
        )}
      </div>

      {loading ? (
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-24 rounded-2xl bg-white shadow-card animate-pulse border border-primary-100/30" />
          ))}
        </div>
      ) : sessions.length === 0 ? (
        <div className="rounded-2xl bg-white p-8 text-center shadow-card border border-primary-100/30">
          <Radio className="mx-auto h-8 w-8 text-primary/40 mb-3" />
          <h3 className="font-display text-base font-bold text-ink">No matatus are being shared right now</h3>
          <p className="mt-1.5 text-sm text-ink-muted max-w-sm mx-auto">
            Be the first to share your ride. Tap "I'm Riding" to let the community know which matatu you are on.
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {/* Group sessions by matatu to show rider counts */}
          {Object.entries(
            sessions.reduce((acc, s) => {
              if (!acc[s.matatu_id]) {
                acc[s.matatu_id] = { sessions: [], matatuName: s.matatu_name, routeNumber: s.matatu_route_number, destination: s.matatu_destination, color: s.matatu_color };
              }
              acc[s.matatu_id].sessions.push(s);
              return acc;
            }, {} as Record<string, { sessions: RidingSession[]; matatuName?: string; routeNumber?: string | null; destination?: string | null; color?: string }>)
          ).map(([matatuId, group]) => {
            const latest = group.sessions[0];
            const locStatus = getLocationStatus(latest);
            const status = statusConfig[locStatus];
            const riderCount = group.sessions.length;

            return (
              <button
                key={matatuId}
                onClick={() => onViewDetails(matatuId)}
                className="w-full flex items-center gap-3 rounded-2xl bg-white p-4 shadow-card transition-all hover:shadow-card-hover border border-primary-100/30 text-left"
              >
                <div
                  className="flex h-12 w-12 flex-shrink-0 items-center justify-center rounded-xl text-white"
                  style={{ background: group.color || '#1d4ed8' }}
                >
                  <Navigation className="h-5 w-5" />
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <h3 className="font-display text-sm font-bold text-ink truncate">{group.matatuName || 'Matatu'}</h3>
                    <span className={`flex items-center gap-1 rounded-full px-2 py-0.5 text-[9px] font-bold uppercase ${status.textColor} bg-current/10`}>
                      <span className={`h-1.5 w-1.5 rounded-full ${status.color} ${status.dot}`} />
                      {status.label}
                    </span>
                  </div>

                  <div className="mt-1 flex items-center gap-2 flex-wrap">
                    {group.routeNumber && <RouteLabel routeNumber={group.routeNumber} size="sm" />}
                    {group.destination && (
                      <span className="text-xs text-ink-muted truncate">{group.destination}</span>
                    )}
                  </div>

                  <div className="mt-1.5 flex items-center gap-3 text-[11px] text-ink-muted">
                    {latest.stage_or_landmark && (
                      <span className="flex items-center gap-1 truncate">
                        <MapPin className="h-3 w-3" />
                        {latest.stage_or_landmark}
                      </span>
                    )}
                    <span className="flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      {latest.last_location_update ? timeAgo(latest.last_location_update) : timeAgo(latest.started_at)}
                    </span>
                    <span className="flex items-center gap-1">
                      <Users className="h-3 w-3" />
                      {riderCount} {riderCount === 1 ? 'rider' : 'riders'}
                    </span>
                  </div>
                </div>

                <ArrowRight className="h-4 w-4 text-ink-muted flex-shrink-0" />
              </button>
            );
          })}

          {/* Privacy note */}
          <div className="mt-2 flex items-start gap-2 rounded-xl bg-primary-50 p-3">
            <Info className="h-4 w-4 text-primary flex-shrink-0 mt-0.5" />
            <p className="text-[11px] text-ink-muted leading-relaxed">
              All sharing is anonymous. "Someone is currently riding this matatu" — no names or personal details are shown.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
