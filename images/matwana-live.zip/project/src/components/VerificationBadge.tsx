import { BadgeCheck, Users, Clock, AlertCircle, HelpCircle } from 'lucide-react';
import type { VerificationStatus } from '@/lib/matatuApi';

interface VerificationBadgeProps {
  status: VerificationStatus;
  size?: 'sm' | 'md';
}

const config: Record<VerificationStatus, { label: string; icon: typeof BadgeCheck; classes: string }> = {
  verified: {
    label: 'Verified',
    icon: BadgeCheck,
    classes: 'bg-primary text-white',
  },
  community_reported: {
    label: 'Community Reported',
    icon: Users,
    classes: 'bg-accent/15 text-accent-dark',
  },
  pending: {
    label: 'Pending Verification',
    icon: Clock,
    classes: 'bg-amber-100 text-amber-700',
  },
  unverified: {
    label: 'Unverified',
    icon: HelpCircle,
    classes: 'bg-gray-200 text-ink-muted',
  },
};

export default function VerificationBadge({ status, size = 'sm' }: VerificationBadgeProps) {
  const c = config[status];
  const Icon = c.icon;
  const sizeClasses = size === 'sm' ? 'px-2 py-0.5 text-[10px]' : 'px-3 py-1 text-xs';

  return (
    <span className={`inline-flex items-center gap-1 rounded-full font-semibold ${c.classes} ${sizeClasses}`}>
      <Icon className={size === 'sm' ? 'h-3 w-3' : 'h-3.5 w-3.5'} />
      {c.label}
    </span>
  );
}

export function InfoStatusLabel({ label, type }: { label: string; type: 'official' | 'community' | 'old' | 'unverified' }) {
  const typeConfig = {
    official: { icon: BadgeCheck, classes: 'bg-primary-50 text-primary' },
    community: { icon: Users, classes: 'bg-accent/10 text-accent-dark' },
    old: { icon: AlertCircle, classes: 'bg-amber-50 text-amber-600' },
    unverified: { icon: HelpCircle, classes: 'bg-gray-100 text-ink-muted' },
  };
  const c = typeConfig[type];
  const Icon = c.icon;

  return (
    <span className={`inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-[10px] font-semibold ${c.classes}`}>
      <Icon className="h-3 w-3" />
      {label}
    </span>
  );
}
