import { Home, Compass, MapPin, Plus, Bell, User, type LucideIcon } from 'lucide-react';
import type { PageId } from '@/types';
import { useRouter } from '@/router';
import Logo from './Logo';

interface NavItem {
  id: PageId;
  label: string;
  icon: LucideIcon;
  activePages?: PageId[];
}

const navItems: NavItem[] = [
  { id: 'home', label: 'Home', icon: Home },
  { id: 'explore', label: 'Directory', icon: Compass, activePages: ['explore', 'details', 'add-matatu'] },
  { id: 'map', label: 'Map', icon: MapPin },
  { id: 'create', label: 'Create', icon: Plus },
  { id: 'notifications', label: 'Alerts', icon: Bell },
  { id: 'profile', label: 'Profile', icon: User },
];

const sidebarExtraItems: NavItem[] = [
  { id: 'add-matatu', label: 'Add Matatu', icon: Plus, activePages: ['add-matatu'] },
];

export default function AppNav() {
  const { page, navigate } = useRouter();

  const isActive = (item: NavItem) => {
    if (item.activePages) return item.activePages.includes(page);
    return page === item.id;
  };

  const bottomItems = navItems.slice(0, 5);

  return (
    <>
      {/* Desktop sidebar */}
      <aside className="fixed left-0 top-0 z-40 hidden h-screen w-64 flex-col border-r border-primary-100/30 bg-ink md:flex">
        <div className="px-5 py-5 border-b border-white/10">
          <button onClick={() => navigate('landing')}>
            <Logo size="md" variant="light" />
          </button>
        </div>
        <nav className="flex-1 px-3 py-4 overflow-y-auto">
          {navItems.map((item) => {
            const active = isActive(item);
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => navigate(item.id)}
                className={`mb-1 flex w-full items-center gap-3 rounded-xl px-4 py-3 text-sm font-medium transition-all ${
                  active
                    ? 'bg-primary text-white shadow-card'
                    : 'text-white/60 hover:bg-white/10 hover:text-white'
                }`}
              >
                <Icon className="h-5 w-5" />
                {item.label}
              </button>
            );
          })}

          <div className="my-3 border-t border-white/10" />

          {sidebarExtraItems.map((item) => {
            const active = isActive(item);
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => navigate(item.id)}
                className={`mb-1 flex w-full items-center gap-3 rounded-xl px-4 py-3 text-sm font-medium transition-all ${
                  active
                    ? 'bg-accent text-white shadow-card'
                    : 'text-white/60 hover:bg-white/10 hover:text-white'
                }`}
              >
                <Icon className="h-5 w-5" />
                {item.label}
              </button>
            );
          })}
        </nav>
        <div className="border-t border-white/10 p-4">
          <div className="rounded-xl bg-primary/20 p-3">
            <p className="text-xs font-semibold text-accent">Sacco-Neutral</p>
            <p className="text-[11px] text-white/50 mt-0.5">
              We celebrate all matatus equally.
            </p>
          </div>
        </div>
      </aside>

      {/* Mobile bottom nav */}
      <nav className="fixed bottom-0 left-0 right-0 z-50 border-t border-primary-100/30 bg-white/95 backdrop-blur-lg md:hidden">
        <div className="flex items-center justify-around px-2 py-1.5 pb-[env(safe-area-inset-bottom)]">
          {bottomItems.map((item) => {
            const active = isActive(item);
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => navigate(item.id)}
                className="flex flex-1 flex-col items-center gap-0.5 rounded-lg py-1.5 transition-colors"
              >
                <div
                  className={`flex h-8 w-8 items-center justify-center rounded-lg transition-all ${
                    active ? 'bg-primary text-white scale-110' : 'text-ink-muted'
                  }`}
                >
                  <Icon className="h-5 w-5" />
                </div>
                <span
                  className={`text-[10px] font-medium ${
                    active ? 'text-primary' : 'text-ink-muted'
                  }`}
                >
                  {item.label}
                </span>
              </button>
            );
          })}
        </div>
      </nav>
    </>
  );
}
