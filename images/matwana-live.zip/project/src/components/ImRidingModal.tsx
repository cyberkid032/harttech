import { useState, useEffect, useCallback } from 'react';
import {
  Navigation, MapPin, MapPinned, FileText, Search, Plus,
  AlertCircle, CheckCircle2, X, Loader2, ShieldCheck, Info,
} from 'lucide-react';
import Button from '@/components/Button';
import RouteLabel from '@/components/RouteLabel';
import {
  fetchMatatus, startRidingSession,
  type MatatuRecord, type RidingSession,
} from '@/lib/matatuApi';

interface ImRidingModalProps {
  open: boolean;
  onClose: () => void;
  onStarted: (session: RidingSession) => void;
  preselectedMatatu?: MatatuRecord | null;
}

export default function ImRidingModal({ open, onClose, onStarted, preselectedMatatu }: ImRidingModalProps) {
  const [step, setStep] = useState<'select' | 'details' | 'permission' | 'starting'>('select');
  const [search, setSearch] = useState('');
  const [matatus, setMatatus] = useState<MatatuRecord[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedMatatu, setSelectedMatatu] = useState<MatatuRecord | null>(null);
  const [routeOrDestination, setRouteOrDestination] = useState('');
  const [stageOrLandmark, setStageOrLandmark] = useState('');
  const [note, setNote] = useState('');
  const [locationConsent, setLocationConsent] = useState(false);
  const [locationStatus, setLocationStatus] = useState<'pending' | 'granted' | 'denied' | 'unavailable'>('pending');
  const [coords, setCoords] = useState<{ lat: number; lng: number; accuracy?: number } | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (open && preselectedMatatu) {
      setSelectedMatatu(preselectedMatatu);
      setRouteOrDestination(preselectedMatatu.destination || '');
      setStep('details');
    } else if (open && !preselectedMatatu) {
      setStep('select');
      setSelectedMatatu(null);
      setSearch('');
    }
  }, [open, preselectedMatatu]);

  useEffect(() => {
    if (!open) return;
    if (preselectedMatatu) return;
    setLoading(true);
    const timer = setTimeout(() => {
      fetchMatatus({ search: search || undefined, sort: 'popular' }).then((result) => {
        setMatatus(result.data);
        setLoading(false);
      });
    }, 300);
    return () => clearTimeout(timer);
  }, [open, search, preselectedMatatu]);

  const reset = () => {
    setStep('select');
    setSearch('');
    setSelectedMatatu(null);
    setRouteOrDestination('');
    setStageOrLandmark('');
    setNote('');
    setLocationConsent(false);
    setLocationStatus('pending');
    setCoords(null);
    setError(null);
  };

  const handleClose = () => {
    reset();
    onClose();
  };

  const handleSelectMatatu = (matatu: MatatuRecord) => {
    setSelectedMatatu(matatu);
    setRouteOrDestination(matatu.destination || '');
    setStep('details');
  };

  const requestLocation = useCallback(async () => {
    if (!navigator.geolocation) {
      setLocationStatus('unavailable');
      setLocationConsent(false);
      return;
    }

    setLocationStatus('pending');
    navigator.geolocation.getCurrentPosition(
      (position) => {
        setCoords({
          lat: position.coords.latitude,
          lng: position.coords.longitude,
          accuracy: position.coords.accuracy,
        });
        setLocationConsent(true);
        setLocationStatus('granted');
      },
      () => {
        setLocationStatus('denied');
        setLocationConsent(false);
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 30000 }
    );
  }, []);

  const handleStartSharing = async () => {
    if (!selectedMatatu) return;
    setStep('starting');
    setError(null);

    const result = await startRidingSession({
      matatuId: selectedMatatu.id,
      routeOrDestination: routeOrDestination.trim() || undefined,
      stageOrLandmark: stageOrLandmark.trim() || undefined,
      note: note.trim() || undefined,
      latitude: coords?.lat,
      longitude: coords?.lng,
      accuracy: coords?.accuracy,
      locationConsent,
    });

    if (result.error) {
      setError(result.error);
      setStep('permission');
    } else if (result.data) {
      onStarted(result.data);
      reset();
    }
  };

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-ink/50 backdrop-blur-sm p-4"
      onClick={handleClose}
    >
      <div
        className="w-full max-w-lg rounded-3xl bg-white shadow-card-hover animate-fade-up max-h-[90vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-gray-100">
          <div className="flex items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary text-white">
              <Navigation className="h-5 w-5" />
            </div>
            <div>
              <h3 className="font-display text-base font-bold text-ink">I'm Riding</h3>
              <p className="text-[11px] text-ink-muted">Share your ride with the community</p>
            </div>
          </div>
          <button
            onClick={handleClose}
            className="flex h-8 w-8 items-center justify-center rounded-full text-ink-muted hover:bg-gray-100 transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-5">

          {/* Step 1: Select matatu */}
          {step === 'select' && (
            <div>
              <p className="text-sm text-ink-muted mb-4">
                Search for the matatu you are currently riding. You can search by name, alias, route, or destination.
              </p>

              <div className="relative mb-4">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-ink-muted" />
                <input
                  type="text"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Search matatus..."
                  className="w-full rounded-xl border-2 border-primary-100 bg-white pl-10 pr-4 py-3 text-sm text-ink outline-none focus:border-primary"
                  autoFocus
                />
              </div>

              {loading ? (
                <div className="space-y-2">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="h-16 rounded-xl bg-gray-100 animate-pulse" />
                  ))}
                </div>
              ) : matatus.length === 0 ? (
                <div className="rounded-xl bg-primary-50 p-6 text-center">
                  <p className="text-sm text-ink-muted mb-3">
                    {search
                      ? 'No matatus found matching your search.'
                      : 'No matatus have been added to the directory yet.'}
                  </p>
                  <p className="text-xs text-ink-muted mb-4">
                    If the matatu you are riding is not listed, you can suggest it first.
                  </p>
                  <Button variant="outline" size="sm" onClick={handleClose}>
                    <Plus className="h-4 w-4" />
                    Suggest a matatu
                  </Button>
                </div>
              ) : (
                <div className="space-y-2">
                  {matatus.map((matatu) => (
                    <button
                      key={matatu.id}
                      onClick={() => handleSelectMatatu(matatu)}
                      className="w-full flex items-center gap-3 rounded-xl border border-primary-100/40 bg-white p-3 text-left transition-all hover:border-primary hover:shadow-card"
                    >
                      <div
                        className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-lg text-white"
                        style={{ background: matatu.color }}
                      >
                        <Navigation className="h-5 w-5" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-display text-sm font-bold text-ink truncate">{matatu.name}</p>
                        <div className="flex items-center gap-2 mt-0.5">
                          <RouteLabel routeNumber={matatu.route_number || '—'} size="sm" />
                          <span className="text-xs text-ink-muted truncate">{matatu.destination}</span>
                        </div>
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Step 2: Ride details */}
          {step === 'details' && selectedMatatu && (
            <div>
              {/* Selected matatu summary */}
              <div className="mb-5 flex items-center gap-3 rounded-xl bg-primary-50 p-4">
                <div
                  className="flex h-12 w-12 flex-shrink-0 items-center justify-center rounded-xl text-white"
                  style={{ background: selectedMatatu.color }}
                >
                  <Navigation className="h-6 w-6" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-display text-base font-bold text-ink">{selectedMatatu.name}</p>
                  <div className="flex items-center gap-2 mt-0.5">
                    <RouteLabel routeNumber={selectedMatatu.route_number || '—'} size="sm" />
                  </div>
                </div>
                {!preselectedMatatu && (
                  <button
                    onClick={() => { setStep('select'); setSelectedMatatu(null); }}
                    className="text-xs font-semibold text-primary hover:underline"
                  >
                    Change
                  </button>
                )}
              </div>

              <div className="space-y-4">
                <div>
                  <label className="flex items-center gap-1.5 text-sm font-semibold text-ink-soft mb-2">
                    <MapPin className="h-4 w-4 text-primary" />
                    Current Route or Destination
                  </label>
                  <input
                    type="text"
                    value={routeOrDestination}
                    onChange={(e) => setRouteOrDestination(e.target.value)}
                    placeholder="e.g. Thika Road → Town"
                    className="w-full rounded-xl border-2 border-primary-100 px-4 py-3 text-sm text-ink outline-none focus:border-primary"
                  />
                </div>

                <div>
                  <label className="flex items-center gap-1.5 text-sm font-semibold text-ink-soft mb-2">
                    <MapPinned className="h-4 w-4 text-primary" />
                    Current Stage or Nearby Landmark
                  </label>
                  <input
                    type="text"
                    value={stageOrLandmark}
                    onChange={(e) => setStageOrLandmark(e.target.value)}
                    placeholder="e.g. Roysambu, near TRM Mall"
                    className="w-full rounded-xl border-2 border-primary-100 px-4 py-3 text-sm text-ink outline-none focus:border-primary"
                  />
                  <p className="mt-1 text-[11px] text-ink-muted">
                    An approximate location helps the community. Do not share exact personal addresses.
                  </p>
                </div>

                <div>
                  <label className="flex items-center gap-1.5 text-sm font-semibold text-ink-soft mb-2">
                    <FileText className="h-4 w-4 text-primary" />
                    Short Note (optional)
                  </label>
                  <textarea
                    value={note}
                    onChange={(e) => setNote(e.target.value)}
                    placeholder="e.g. Heavy traffic near Kasarani, expect delays"
                    rows={2}
                    className="w-full rounded-xl border-2 border-primary-100 px-4 py-3 text-sm text-ink outline-none focus:border-primary resize-none"
                  />
                </div>
              </div>

              <div className="mt-6 flex gap-3">
                <Button variant="ghost" size="md" className="flex-1" onClick={() => setStep(preselectedMatatu ? 'select' : 'select')}>
                  Back
                </Button>
                <Button variant="primary" size="md" className="flex-1" onClick={() => setStep('permission')}>
                  Continue
                </Button>
              </div>
            </div>
          )}

          {/* Step 3: Location permission */}
          {step === 'permission' && (
            <div>
              <div className="mb-5 rounded-xl bg-primary-50 p-4">
                <div className="flex items-start gap-3">
                  <ShieldCheck className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                  <div>
                    <h4 className="font-display text-sm font-bold text-ink">Privacy First</h4>
                    <ul className="mt-2 space-y-1.5 text-xs text-ink-muted leading-relaxed">
                      <li>You are sharing <strong>anonymously</strong>. No name or profile is shown.</li>
                      <li>Your sharing session will <strong>expire automatically</strong> after 2 hours.</li>
                      <li>You can <strong>stop sharing at any time</strong>.</li>
                      <li>We never track you without permission.</li>
                    </ul>

                    <div className="mt-3 pt-3 border-t border-primary-100/50 space-y-1.5 text-xs text-ink-muted leading-relaxed">
                      <p><strong>What is shared:</strong> The matatu name, route, approximate location, and status.</p>
                      <p><strong>Who can see it:</strong> Anyone viewing the Matwana Live map or directory.</p>
                      <p><strong>How long:</strong> Your session expires after 2 hours or when you stop sharing.</p>
                      <p><strong>How to stop:</strong> Tap "Stop Sharing" on the sharing status card at any time.</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Location consent */}
              <div className="mb-5">
                <div className="flex items-start gap-3 rounded-xl border-2 border-primary-100 p-4">
                  <MapPinned className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                  <div className="flex-1">
                    <h4 className="font-display text-sm font-bold text-ink">Share Location (optional)</h4>
                    <p className="mt-1 text-xs text-ink-muted leading-relaxed">
                      Grant location permission so the community can see approximately where this matatu is.
                      Your exact personal location is not stored or displayed.
                    </p>
                    <div className="mt-3">
                      {locationStatus === 'pending' && (
                        <Button variant="outline" size="sm" onClick={requestLocation}>
                          <MapPinned className="h-4 w-4" />
                          Grant Location Permission
                        </Button>
                      )}
                      {locationStatus === 'granted' && (
                        <div className="flex items-center gap-2 text-sm font-semibold text-green-600">
                          <CheckCircle2 className="h-4 w-4" />
                          Location permission granted
                        </div>
                      )}
                      {locationStatus === 'denied' && (
                        <div className="flex items-center gap-2 text-sm text-amber-600">
                          <AlertCircle className="h-4 w-4" />
                          Location permission denied. You can still share without location.
                        </div>
                      )}
                      {locationStatus === 'unavailable' && (
                        <div className="flex items-center gap-2 text-sm text-amber-600">
                          <AlertCircle className="h-4 w-4" />
                          Location is not available on this device. You can still share without location.
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              {error && (
                <div className="mb-4 flex items-start gap-3 rounded-xl bg-red-50 p-4 border border-red-100">
                  <AlertCircle className="h-5 w-5 text-red-500 flex-shrink-0 mt-0.5" />
                  <p className="text-xs text-red-600">{error}</p>
                </div>
              )}

              <div className="mt-2 flex gap-3">
                <Button variant="ghost" size="md" className="flex-1" onClick={() => setStep('details')}>
                  Back
                </Button>
                <Button variant="accent" size="md" className="flex-1" onClick={handleStartSharing}>
                  <Navigation className="h-4 w-4" />
                  Start Sharing
                </Button>
              </div>
            </div>
          )}

          {/* Step 4: Starting */}
          {step === 'starting' && (
            <div className="flex flex-col items-center justify-center py-12">
              <Loader2 className="h-10 w-10 text-primary animate-spin mb-4" />
              <p className="text-sm text-ink-muted">Starting your sharing session...</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
