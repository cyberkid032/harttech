interface FilterChip {
  id: string;
  label: string;
}

interface FilterControlProps {
  chips: FilterChip[];
  activeId: string;
  onChange: (id: string) => void;
}

export default function FilterControl({ chips, activeId, onChange }: FilterControlProps) {
  return (
    <div className="flex items-center gap-2 overflow-x-auto scrollbar-hide">
      {chips.map((chip) => (
        <button
          key={chip.id}
          onClick={() => onChange(chip.id)}
          className={`flex-shrink-0 rounded-full px-4 py-1.5 text-xs font-semibold transition-all ${
            activeId === chip.id
              ? 'bg-primary text-white shadow-card'
              : 'bg-primary-50 text-ink-muted hover:bg-primary-100'
          }`}
        >
          {chip.label}
        </button>
      ))}
    </div>
  );
}

interface SortControlProps {
  value: string;
  onChange: (value: string) => void;
  options: { id: string; label: string }[];
}

export function SortControl({ value, onChange, options }: SortControlProps) {
  return (
    <div className="relative inline-block">
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="appearance-none rounded-full border-2 border-primary-100 bg-white py-2 pl-4 pr-9 text-xs font-semibold text-ink-soft outline-none transition-all focus:border-primary cursor-pointer"
      >
        {options.map((opt) => (
          <option key={opt.id} value={opt.id}>
            {opt.label}
          </option>
        ))}
      </select>
      <svg
        className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-ink-muted pointer-events-none"
        fill="none"
        viewBox="0 0 24 24"
        stroke="currentColor"
      >
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
      </svg>
    </div>
  );
}
