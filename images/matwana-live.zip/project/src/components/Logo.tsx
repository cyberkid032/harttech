interface LogoProps {
  size?: 'sm' | 'md' | 'lg';
  variant?: 'dark' | 'light';
  showText?: boolean;
}

export default function Logo({ size = 'md', variant = 'dark', showText = true }: LogoProps) {
  const dimensions = {
    sm: { box: 'w-8 h-8', text: 'text-lg' },
    md: { box: 'w-10 h-10', text: 'text-xl' },
    lg: { box: 'w-14 h-14', text: 'text-2xl' },
  }[size];

  const textColor = variant === 'light' ? 'text-white' : 'text-ink';

  return (
    <div className="flex items-center gap-2.5 select-none">
      <div
        className={`${dimensions.box} relative flex items-center justify-center rounded-xl bg-primary shadow-card`}
      >
        <svg viewBox="0 0 32 32" className="w-3/4 h-3/4" fill="none">
          <path
            d="M6 20V14C6 10 9 7 13 7H19C23 7 26 10 26 14V20"
            stroke="white"
            strokeWidth="2.5"
            strokeLinecap="round"
          />
          <rect x="4" y="20" width="24" height="4" rx="2" fill="white" />
          <circle cx="11" cy="24" r="2.5" fill="#38bdf8" />
          <circle cx="21" cy="24" r="2.5" fill="#38bdf8" />
          <path d="M11 13H21" stroke="#38bdf8" strokeWidth="2" strokeLinecap="round" />
        </svg>
        <div className="absolute -top-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-accent shadow-glow" />
      </div>
      {showText && (
        <div className="leading-none">
          <span className={`font-display font-extrabold ${dimensions.text} ${textColor} tracking-tight`}>
            Matwana
          </span>
          <span className={`font-display font-extrabold ${dimensions.text} tracking-tight`} style={{ color: '#0ea5e9' }}>
            {' '}Live
          </span>
        </div>
      )}
    </div>
  );
}
