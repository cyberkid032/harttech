import type { ButtonHTMLAttributes, ReactNode } from 'react';

type Variant = 'primary' | 'accent' | 'outline' | 'ghost' | 'dark';
type Size = 'sm' | 'md' | 'lg';

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  size?: Size;
  children: ReactNode;
}

const variantClasses: Record<Variant, string> = {
  primary:
    'bg-primary text-white hover:bg-primary-dark shadow-card hover:shadow-card-hover active:scale-[0.97]',
  accent:
    'bg-accent text-white hover:bg-accent-dark shadow-card hover:shadow-glow active:scale-[0.97] font-semibold',
  outline:
    'border-2 border-primary text-primary hover:bg-primary hover:text-white active:scale-[0.97]',
  ghost: 'text-ink-soft hover:bg-primary-50 active:scale-[0.97]',
  dark: 'bg-ink text-white hover:bg-ink-soft shadow-card active:scale-[0.97]',
};

const sizeClasses: Record<Size, string> = {
  sm: 'px-4 py-2 text-sm',
  md: 'px-6 py-3 text-sm',
  lg: 'px-8 py-4 text-base',
};

export default function Button({
  variant = 'primary',
  size = 'md',
  children,
  className = '',
  ...props
}: ButtonProps) {
  return (
    <button
      className={`inline-flex items-center justify-center gap-2 rounded-full font-display font-semibold transition-all duration-200 disabled:opacity-50 disabled:pointer-events-none ${variantClasses[variant]} ${sizeClasses[size]} ${className}`}
      {...props}
    >
      {children}
    </button>
  );
}
