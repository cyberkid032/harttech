import { useState, useEffect, useCallback, useRef } from 'react';
import {
  MapPin, Info, Navigation, ArrowRight, Search as SearchIcon,
  FlaskConical, ZapOff, Locate, X, Radio, Eye, Clock,
  WifiOff, AlertCircle, Plus, MapPinned, ShieldCheck,
} from 'lucide-react';
import Button from '@/components/Button';
import SearchField from '@/components/SearchField';
import FilterControl from '@/components/FilterControl';
import MapMarkerInfoCard from '@/components/MapMarkerInfoCard';
import ImRidingModal from '@/components/ImRidingModal';
import { useRouter } from '@/router';
import {
  loadGoogleMaps, hasGoogleMapsKey, getMapsLoadError,
  getStatusConfig, type MapMarkerData, type MarkerLocationStatus,
} from '@/lib/googleMaps';
import {
  fetchActiveRidingSessions, fetchMatatus,
  submitManualSighting, getMyActiveSession, getLocationStatus,
  type RidingSession, type MatatuRecord,
} from '@/lib/matatuApi';
import {
  isDemoMode, setDemoMode, demoMapMarkers,
  type DemoMapMarker,
} from '@/lib/demoMode';

type StatusFilter = 'all' | 'live' | 'recent' | 'verified' | 'unverified' | 'expired';

const statusChips: { id: StatusFilter; label: string }[] = [
  { id: 'all', label: 'All' },
  { id: 'live', label: 'Live' },
  { id: 'recent', label: 'Recent' },
  { id: 'verified', label: 'Verified' },
  { id: 'unverified', label: 'Unverified' },
  { id: 'expired', label: 'Expired' },
];

const legendItems: { status: MarkerLocationStatus; desc: string }[] = [
  { status: 'live', desc: 'Active location update received recently (within 5 min)' },
  { status: 'recent', desc: 'Location reported recently but not actively updating (5–30 min)' },
  { status: 'verified', desc: 'Information confirmed by approved verification' },
  { status: 'unverified', desc: 'Information not yet confirmed' },
  { status: 'expired', desc: 'Sharing session has ended' },
];

function timeAgo(iso: string | null): string {
  if (!iso) return 'Unknown';
  const diff = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'Just now';
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.floor(mins / 60);
  return `${hours}h ago`;
}

function ridingSessionToMarker(session: RidingSession): MapMarkerData | null {
  if (!session.latitude || !session.longitude) return null;
  const locStatus = getLocationStatus(session);
  return {
    id: `session-${session.id}`,
    matatuId: session.matatu_id,
    matatuName: session.matatu_name || 'Matatu',
    routeNumber: session.matatu_route_number || null,
    destination: session.matatu_destination || null,
    latitude: session.latitude,
    longitude: session.longitude,
    locationStatus: locStatus as MarkerLocationStatus,
    lastUpdated: session.last_location_update,
    riderCount: session.active_rider_count || 1,
    stageOrLandmark: session.stage_or_landmark,
    isCommunityReport: false,
    color: session.matatu_color,
  };
}

function demoMarkerToMapMarker(dm: DemoMapMarker): MapMarkerData {
  return {
    id: dm.id,
    matatuId: dm.matatuId,
    matatuName: dm.matatuName,
    routeNumber: dm.routeNumber,
    destination: dm.destination,
    latitude: dm.latitude,
    longitude: dm.longitude,
    locationStatus: dm.locationStatus,
    lastUpdated: dm.lastUpdated,
    riderCount: dm.riderCount,
    stageOrLandmark: dm.stageOrLandmark,
    isCommunityReport: dm.isCommunityReport,
    color: dm.color,
  };
}

export default function Map() {
  const { navigate } = useRouter();

  const [mapsLoaded, setMapsLoaded] = useState(false);
  const [mapsError, setMapsError] = useState<string | null>(null);
  const [markers, setMarkers] = useState<MapMarkerData[]>([]);
  const [loading, setLoading] = useState(true);
  const [offline, setOffline] = useState(!navigator.onLine);
  const [demoActive, setDemoActive] = useState(isDemoMode());
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<StatusFilter>('all');
  const [selectedMarker, setSelectedMarker] = useState<MapMarkerData | null>(null);
  const [showLegend, setShowLegend] = useState(false);
  const [showRidingModal, setShowRidingModal] = useState(false);
  const [showSightingForm, setShowSightingForm] = useState(false);
  const [mySession, setMySession] = useState<RidingSession | null>(null);

  const mapContainerRef = useRef<HTMLDivElement>(null);
  const googleMapRef = useRef<google.maps.Map | null>(null);
  const googleMarkersRef = useRef<google.maps.Marker[]>([]);
  const infoWindowRef = useRef<google.maps.InfoWindow | null>(null);

  // Load Google Maps
  useEffect(() => {
    if (!hasGoogleMapsKey()) {
      setMapsError('Google Maps API key is not configured. Set VITE_GOOGLE_MAPS_API_KEY in your environment variables to enable the map.');
      setLoading(false);
      return;
    }

    loadGoogleMaps().then((maps) => {
      if (!maps) {
        setMapsError(getMapsLoadError() || 'Failed to load Google Maps.');
        setLoading(false);
        return;
      }

      if (mapContainerRef.current && !googleMapRef.current) {
        googleMapRef.current = new maps.Map(mapContainerRef.current, {
          center: { lat: -1.2864, lng: 36.8172 },
          zoom: 12,
          mapTypeControl: false,
          streetViewControl: false,
          fullscreenControl: true,
          styles: [
            { featureType: 'poi', stylers: [{ visibility: 'simplified' }] },
          ],
        });
        infoWindowRef.current = new maps.InfoWindow();
      }
      setMapsLoaded(true);
      setLoading(false);
    });
  }, []);

  // Online/offline
  useEffect(() => {
    const onOnline = () => setOffline(false);
    const onOffline = () => setOffline(true);
    window.addEventListener('online', onOnline);
    window.addEventListener('offline', onOffline);
    return () => {
      window.removeEventListener('online', onOnline);
      window.removeEventListener('offline', onOffline);
    };
  }, []);

  // Demo mode listener
  useEffect(() => {
    const onDemoChange = () => setDemoActive(isDemoMode());
    window.addEventListener('demo-mode-change', onDemoChange);
    return () => window.removeEventListener('demo-mode-change', onDemoChange);
  }, []);

  // Load markers data
  const loadMarkers = useCallback(async () => {
    if (offline && !demoActive) {
      setLoading(false);
      return;
    }

    if (demoActive) {
      const filtered = search
        ? demoMapMarkers.filter((m) => {
            const q = search.toLowerCase();
            return (
              m.matatuName.toLowerCase().includes(q) ||
              m.routeNumber?.toLowerCase().includes(q) ||
              m.destination?.toLowerCase().includes(q) ||
              m.stageOrLandmark?.toLowerCase().includes(q)
            );
          })
        : demoMapMarkers;
      setMarkers(filtered.map(demoMarkerToMapMarker));
      setLoading(false);
      return;
    }

    setLoading(true);

    const [sessionsResult, mySessionResult] = await Promise.all([
      fetchActiveRidingSessions(),
      getMyActiveSession(),
    ]);

    setMySession(mySessionResult.data);

    const sessionMarkers: MapMarkerData[] = [];
    if (!sessionsResult.error) {
      const grouped = new globalThis.Map<string, RidingSession[]>();
      for (const s of sessionsResult.data) {
        if (!s.latitude || !s.longitude) continue;
        const existing = grouped.get(s.matatu_id) || [];
        existing.push(s);
        grouped.set(s.matatu_id, existing);
      }
      for (const [, group] of grouped) {
        const latest = group[0];
        const marker = ridingSessionToMarker(latest);
        if (marker) {
          marker.riderCount = group.length;
          sessionMarkers.push(marker);
        }
      }
    }

    setMarkers(sessionMarkers);
    setLoading(false);
  }, [search, demoActive, offline]);

  useEffect(() => {
    const timer = setTimeout(() => loadMarkers(), 300);
    return () => clearTimeout(timer);
  }, [loadMarkers]);

  // Filter markers by status
  const filteredMarkers = markers.filter((m) => {
    if (statusFilter === 'all') return true;
    return m.locationStatus === statusFilter;
  });

  // Render Google Maps markers
  useEffect(() => {
    if (!mapsLoaded || !googleMapRef.current || !infoWindowRef.current) return;
    const maps = google.maps;
    if (!maps) return;

    googleMarkersRef.current.forEach((m) => m.setMap(null));
    googleMarkersRef.current = [];

    const bounds = new maps.LatLngBounds();

    for (const markerData of filteredMarkers) {
      const statusCfg = getStatusConfig(markerData.locationStatus);
      const position = { lat: markerData.latitude, lng: markerData.longitude };

      const gMarker = new maps.Marker({
        position,
        map: googleMapRef.current,
        title: markerData.matatuName,
        icon: {
          path: maps.SymbolPath.CIRCLE,
          scale: 10,
          fillColor: statusCfg.color,
          fillOpacity: 1,
          strokeColor: '#ffffff',
          strokeWeight: 2,
        },
      });

      gMarker.addListener('click', () => {
        setSelectedMarker(markerData);
        if (infoWindowRef.current && googleMapRef.current) {
          const content = `
            <div style="font-family: inherit; padding: 4px;">
              <strong>${markerData.matatuName}</strong><br/>
              <span style="font-size: 11px; color: #666;">${markerData.destination || ''}</span><br/>
              <span style="font-size: 10px; font-weight: bold; color: ${statusCfg.color};">${statusCfg.label}</span>
            </div>
          `;
          infoWindowRef.current.setContent(content);
          infoWindowRef.current.open(googleMapRef.current, gMarker);
        }
      });

      googleMarkersRef.current.push(gMarker);
      bounds.extend(position);
    }

    if (filteredMarkers.length > 0 && googleMapRef.current) {
      googleMapRef.current.fitBounds(bounds, 60);
    }
  }, [filteredMarkers, mapsLoaded]);

  // Cleanup
  useEffect(() => {
    return () => {
      googleMarkersRef.current.forEach((m) => m.setMap(null));
      googleMarkersRef.current = [];
    };
  }, []);

  const handleShare = (_matatuId: string, _matatuName: string) => {
    setShowRidingModal(true);
  };

  const handleResetView = () => {
    if (googleMapRef.current) {
      googleMapRef.current.setCenter({ lat: -1.2864, lng: 36.8172 });
      googleMapRef.current.setZoom(12);
    }
    setSelectedMarker(null);
  };

  // ─── Google Maps not available / no key ───

  if (mapsError) {
    return (
      <div>
        <div className="mb-6">
          <h1 className="font-display text-2xl font-extrabold text-ink">Map</h1>
          <p className="mt-1 text-sm text-ink-muted">
            Matatu tracking and community-shared locations.
          </p>
        </div>

        {/* Demo banner */}
        {demoActive && (
          <div className="mb-4 flex items-center gap-2 rounded-xl bg-amber-50 px-4 py-2.5 border border-amber-100">
            <FlaskConical className="h-4 w-4 text-amber-600 flex-shrink-0" />
            <span className="text-xs font-medium text-amber-800">
              Demo Mode — locations are fictional and not live.
            </span>
            <button
              onClick={() => { setDemoMode(false); setDemoActive(false); }}
              className="ml-auto flex items-center gap-1 text-xs font-semibold text-amber-700 hover:underline"
            >
              <ZapOff className="h-3 w-3" />
              Exit Demo
            </button>
          </div>
        )}

        {/* Google Maps setup message */}
        <div className="rounded-2xl bg-white p-8 shadow-card border border-primary-100/30 text-center">
          <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-primary-50">
            <MapPin className="h-7 w-7 text-primary" />
          </div>
          <h3 className="font-display text-base font-bold text-ink">Google Maps Setup Required</h3>
          <p className="mt-2 text-sm text-ink-muted max-w-md mx-auto leading-relaxed">
            The Matwana Live map requires a Google Maps API key to display the interactive map,
            matatu markers, and location data. Without it, the map cannot load.
          </p>

          <div className="mt-4 rounded-xl bg-primary-50 p-4 text-left max-w-md mx-auto">
            <h4 className="font-display text-sm font-bold text-ink mb-2">How to configure:</h4>
            <ol className="space-y-1.5 text-xs text-ink-muted leading-relaxed list-decimal pl-4">
              <li>Go to the Google Cloud Console and enable the Maps JavaScript API.</li>
              <li>Create an API key with Maps JavaScript API permissions.</li>
              <li>Add it to your environment as <code className="text-primary font-mono">VITE_GOOGLE_MAPS_API_KEY</code></li>
              <li>Restart the application.</li>
            </ol>
          </div>

          <p className="mt-3 text-xs text-ink-muted max-w-sm mx-auto">
            The app will not crash. You can still browse the directory and use all other features.
          </p>

          <div className="mt-6 flex flex-col gap-2 sm:flex-row sm:justify-center">
            <Button variant="primary" size="sm" onClick={() => navigate('explore')}>
              Browse Directory
              <ArrowRight className="h-4 w-4" />
            </Button>
            <Button variant="outline" size="sm" onClick={() => navigate('home')}>
              Back to Home
            </Button>
          </div>
        </div>

        <PrivacyNote />
      </div>
    );
  }

  // ─── Offline state ───

  if (offline && !demoActive) {
    return (
      <div>
        <div className="mb-6">
          <h1 className="font-display text-2xl font-extrabold text-ink">Map</h1>
        </div>
        <div className="rounded-2xl bg-white p-12 text-center shadow-card border border-primary-100/30">
          <div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-amber-50">
            <WifiOff className="h-6 w-6 text-amber-500" />
          </div>
          <h3 className="font-display text-base font-bold text-ink">No connection</h3>
          <p className="mt-1.5 text-sm text-ink-muted max-w-sm mx-auto">
            No connection. Please reconnect to view the map and current matatu locations.
          </p>
          <div className="mt-4">
            <Button variant="primary" size="sm" onClick={() => { setOffline(false); loadMarkers(); }}>
              Try again
            </Button>
          </div>
        </div>
      </div>
    );
  }

  // ─── Main Map view ───

  return (
    <div>
      <div className="mb-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="font-display text-2xl font-extrabold text-ink">Map</h1>
            <p className="mt-1 text-sm text-ink-muted">
              {demoActive
                ? 'Demo Mode — locations are fictional and not live.'
                : 'Matatu tracking and community-shared locations.'}
            </p>
          </div>
          {demoActive && (
            <button
              onClick={() => { setDemoMode(false); setDemoActive(false); }}
              className="flex items-center gap-1 rounded-full bg-amber-100 px-3 py-1.5 text-xs font-semibold text-amber-700 hover:bg-amber-200 transition-colors"
            >
              <ZapOff className="h-3 w-3" />
              Exit Demo
            </button>
          )}
        </div>
      </div>

      {/* Demo banner */}
      {demoActive && (
        <div className="mb-4 flex items-center gap-2 rounded-xl bg-amber-50 px-4 py-2.5 border border-amber-100">
          <FlaskConical className="h-4 w-4 text-amber-600 flex-shrink-0" />
          <span className="text-xs font-medium text-amber-800">
            Demo Mode — locations are fictional and not live.
          </span>
        </div>
      )}

      {/* Search + filters */}
      <div className="mb-4 space-y-3">
        <SearchField
          value={search}
          onChange={setSearch}
          onClear={() => setSearch('')}
          placeholder="Search matatu name, route, or destination"
        />

        <div>
          <p className="text-[11px] font-semibold uppercase tracking-wider text-ink-muted mb-2">Status</p>
          <FilterControl
            chips={statusChips}
            activeId={statusFilter}
            onChange={(v) => setStatusFilter(v as StatusFilter)}
          />
        </div>

        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={handleResetView}>
            <Locate className="h-4 w-4" />
            Reset View
          </Button>
          <Button variant="ghost" size="sm" onClick={() => setShowLegend(!showLegend)}>
            <Info className="h-4 w-4" />
            Legend
          </Button>
          <Button variant="ghost" size="sm" onClick={() => setShowSightingForm(true)}>
            <Plus className="h-4 w-4" />
            Report Sighting
          </Button>
        </div>
      </div>

      {/* Legend */}
      {showLegend && (
        <div className="mb-4 rounded-2xl bg-white p-4 shadow-card border border-primary-100/30">
          <h3 className="font-display text-sm font-bold text-ink mb-3">Marker Status Legend</h3>
          <div className="space-y-2">
            {legendItems.map((item) => {
              const cfg = getStatusConfig(item.status);
              return (
                <div key={item.status} className="flex items-start gap-3">
                  <span
                    className={`mt-0.5 flex h-3 w-3 flex-shrink-0 rounded-full ${cfg.dotClass}`}
                    style={{ backgroundColor: cfg.color }}
                  />
                  <div>
                    <span className={`text-xs font-bold ${cfg.textClass}`}>{cfg.label}</span>
                    <p className="text-[11px] text-ink-muted">{item.desc}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Map container */}
      <div className="relative overflow-hidden rounded-3xl border border-primary-100/30 shadow-card">
        <div
          ref={mapContainerRef}
          className="w-full h-[400px] sm:h-[500px] bg-gray-100"
        />

        {/* Loading overlay */}
        {loading && (
          <div className="absolute inset-0 flex items-center justify-center bg-white/80 backdrop-blur-sm">
            <div className="flex flex-col items-center">
              <div className="h-8 w-8 border-3 border-primary border-t-transparent rounded-full animate-spin mb-2" />
              <p className="text-xs text-ink-muted">Loading map...</p>
            </div>
          </div>
        )}

        {/* No markers overlay */}
        {!loading && filteredMarkers.length === 0 && !demoActive && (
          <div className="absolute inset-0 flex items-center justify-center bg-white/90 backdrop-blur-sm p-4">
            <div className="text-center max-w-xs">
              <MapPin className="mx-auto h-10 w-10 text-primary/30 mb-3" />
              <h3 className="font-display text-sm font-bold text-ink">No matatus on the map</h3>
              <p className="mt-1.5 text-xs text-ink-muted leading-relaxed">
                No current location is available. You can still view the matatu profile or share a sighting.
              </p>
              <div className="mt-3 flex flex-col gap-2">
                <Button variant="primary" size="sm" onClick={() => navigate('explore')}>
                  Browse Directory
                </Button>
                <Button variant="outline" size="sm" onClick={() => setShowSightingForm(true)}>
                  <Plus className="h-3.5 w-3.5" />
                  Report a Sighting
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Selected marker info card overlay */}
        {selectedMarker && (
          <div className="absolute bottom-4 left-4 right-4 z-10">
            <div className="relative">
              <button
                onClick={() => setSelectedMarker(null)}
                className="absolute -top-2 -right-2 z-20 flex h-7 w-7 items-center justify-center rounded-full bg-white shadow-card border border-gray-100 text-ink-muted hover:text-primary transition-colors"
              >
                <X className="h-4 w-4" />
              </button>
              <MapMarkerInfoCard
                marker={selectedMarker}
                onViewProfile={(matatuId) => navigate('details', matatuId)}
                onShare={(matatuId) => handleShare(matatuId, selectedMarker.matatuName)}
              />
            </div>
          </div>
        )}
      </div>

      {/* My active session card */}
      {mySession && !demoActive && (
        <div className="mt-4">
          <div className="rounded-2xl bg-ink p-4 text-white">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-accent">
                <Radio className="h-5 w-5" />
              </div>
              <div className="flex-1">
                <h3 className="font-display text-sm font-bold">You Are Sharing</h3>
                <p className="text-[11px] text-white/60">
                  An anonymous rider is currently sharing this matatu.
                </p>
              </div>
              <div className="flex items-center gap-1.5 rounded-full bg-accent/20 px-3 py-1">
                <div className="h-2 w-2 rounded-full bg-accent animate-pulse" />
                <span className="text-[10px] font-bold uppercase tracking-wider text-accent">Live</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Markers list (for accessibility / when map doesn't show all) */}
      {filteredMarkers.length > 0 && (
        <div className="mt-6">
          <h2 className="font-display text-lg font-bold text-ink mb-4">
            Visible Matatus ({filteredMarkers.length})
          </h2>
          <div className="space-y-3">
            {filteredMarkers.map((marker) => (
              <button
                key={marker.id}
                onClick={() => setSelectedMarker(marker)}
                className="w-full flex items-center gap-3 rounded-2xl bg-white p-4 shadow-card transition-all hover:shadow-card-hover border border-primary-100/30 text-left"
              >
                <div
                  className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-xl text-white"
                  style={{ background: marker.color || '#1d4ed8' }}
                >
                  <Navigation className="h-5 w-5" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <h3 className="font-display text-sm font-bold text-ink truncate">{marker.matatuName}</h3>
                    {(() => {
                      const cfg = getStatusConfig(marker.locationStatus);
                      return (
                        <span className={`flex items-center gap-1 rounded-full px-2 py-0.5 text-[9px] font-bold uppercase ${cfg.bgClass} ${cfg.textClass}`}>
                          <span className={`h-1.5 w-1.5 rounded-full ${cfg.dotClass}`} style={{ backgroundColor: cfg.color }} />
                          {cfg.label}
                        </span>
                      );
                    })()}
                  </div>
                  <div className="mt-1 flex items-center gap-3 text-[11px] text-ink-muted">
                    {marker.destination && <span className="truncate">{marker.destination}</span>}
                    <span className="flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      {timeAgo(marker.lastUpdated)}
                    </span>
                    {marker.riderCount > 0 && (
                      <span className="flex items-center gap-1 text-green-600 font-semibold">
                        <Radio className="h-3 w-3" />
                        {marker.riderCount}
                      </span>
                    )}
                    {marker.isCommunityReport && (
                      <span className="flex items-center gap-1 text-amber-600">
                        <Eye className="h-3 w-3" />
                        Reported
                      </span>
                    )}
                  </div>
                </div>
                <ArrowRight className="h-4 w-4 text-ink-muted flex-shrink-0" />
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Privacy note */}
      <PrivacyNote />

      {/* I'm Riding Modal */}
      <ImRidingModal
        open={showRidingModal}
        onClose={() => setShowRidingModal(false)}
        onStarted={() => {
          setShowRidingModal(false);
          loadMarkers();
        }}
      />

      {/* Manual Sighting Form */}
      {showSightingForm && (
        <ManualSightingForm
          open={showSightingForm}
          onClose={() => setShowSightingForm(false)}
          onSubmitted={() => {
            setShowSightingForm(false);
            loadMarkers();
          }}
        />
      )}
    </div>
  );
}

// ─── Privacy Note ──────────────────────────────────────────

function PrivacyNote() {
  return (
    <div className="mt-6 rounded-2xl bg-primary-50 p-5">
      <div className="flex items-start gap-3">
        <ShieldCheck className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
        <div>
          <h3 className="font-display text-sm font-bold text-ink">Privacy First</h3>
          <p className="mt-1 text-xs text-ink-muted leading-relaxed">
            Matwana Live never tracks location without clear user consent. All location sharing
            is opt-in, temporary, and anonymous. No names, photos, phone numbers, or personal
            location history are shown. You can stop sharing at any time. Sharing sessions
            expire automatically.
          </p>
        </div>
      </div>
    </div>
  );
}

// ─── Manual Sighting Form ──────────────────────────────────

interface ManualSightingFormProps {
  open: boolean;
  onClose: () => void;
  onSubmitted: () => void;
}

function ManualSightingForm({ open, onClose, onSubmitted }: ManualSightingFormProps) {
  const { navigate } = useRouter();
  const [search, setSearch] = useState('');
  const [matatus, setMatatus] = useState<MatatuRecord[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedMatatu, setSelectedMatatu] = useState<MatatuRecord | null>(null);
  const [location, setLocation] = useState('');
  const [routeObserved, setRouteObserved] = useState('');
  const [notes, setNotes] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  useEffect(() => {
    if (!open) return;
    setLoading(true);
    const timer = setTimeout(() => {
      fetchMatatus({ search: search || undefined, sort: 'popular' }).then((result) => {
        setMatatus(result.data);
        setLoading(false);
      });
    }, 300);
    return () => clearTimeout(timer);
  }, [open, search]);

  if (!open) return null;

  const handleSubmit = async () => {
    if (!selectedMatatu || !location.trim()) return;
    setSubmitting(true);
    setError(null);

    const result = await submitManualSighting({
      matatuId: selectedMatatu.id,
      location: location.trim(),
      routeObserved: routeObserved.trim() || undefined,
      notes: notes.trim() || undefined,
    });

    setSubmitting(false);

    if (result.error) {
      setError(result.error);
    } else {
      setSuccess(true);
      setTimeout(() => {
        onSubmitted();
        setSuccess(false);
        setSelectedMatatu(null);
        setLocation('');
        setRouteObserved('');
        setNotes('');
      }, 1500);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-ink/50 backdrop-blur-sm p-4"
      onClick={onClose}
    >
      <div
        className="w-full max-w-lg rounded-3xl bg-white shadow-card-hover animate-fade-up max-h-[90vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-gray-100">
          <div className="flex items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary text-white">
              <Eye className="h-5 w-5" />
            </div>
            <div>
              <h3 className="font-display text-base font-bold text-ink">Report a Sighting</h3>
              <p className="text-[11px] text-ink-muted">Share where you spotted a matatu</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="flex h-8 w-8 items-center justify-center rounded-full text-ink-muted hover:bg-gray-100 transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-5">
          {success ? (
            <div className="flex flex-col items-center justify-center py-12">
              <div className="flex h-14 w-14 items-center justify-center rounded-full bg-green-100 mb-3">
                <MapPin className="h-7 w-7 text-green-600" />
              </div>
              <h3 className="font-display text-base font-bold text-ink">Sighting Submitted!</h3>
              <p className="mt-1.5 text-sm text-ink-muted text-center">
                Your community report has been recorded. It will appear as "Community Reported" on the map.
              </p>
            </div>
          ) : (
            <>
              {/* Matatu selection */}
              {!selectedMatatu ? (
                <div>
                  <p className="text-sm text-ink-muted mb-4">
                    Search for the matatu you spotted.
                  </p>
                  <div className="relative mb-4">
                    <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-ink-muted" />
                    <input
                      type="text"
                      value={search}
                      onChange={(e) => setSearch(e.target.value)}
                      placeholder="Search matatus..."
                      className="w-full rounded-xl border-2 border-primary-100 bg-white pl-10 pr-4 py-3 text-sm text-ink outline-none focus:border-primary"
                      autoFocus
                    />
                  </div>

                  {loading ? (
                    <div className="space-y-2">
                      {[1, 2, 3].map((i) => (
                        <div key={i} className="h-16 rounded-xl bg-gray-100 animate-pulse" />
                      ))}
                    </div>
                  ) : matatus.length === 0 ? (
                    <div className="rounded-xl bg-primary-50 p-6 text-center">
                      <p className="text-sm text-ink-muted mb-3">
                        {search ? 'No matatus found matching your search.' : 'No matatus have been added yet.'}
                      </p>
                      <Button variant="outline" size="sm" onClick={() => { onClose(); navigate('add-matatu'); }}>
                        <Plus className="h-4 w-4" />
                        Suggest a matatu
                      </Button>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {matatus.map((matatu) => (
                        <button
                          key={matatu.id}
                          onClick={() => {
                            setSelectedMatatu(matatu);
                            setRouteObserved(matatu.route_number || matatu.destination || '');
                          }}
                          className="w-full flex items-center gap-3 rounded-xl border border-primary-100/40 bg-white p-3 text-left transition-all hover:border-primary hover:shadow-card"
                        >
                          <div
                            className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-lg text-white"
                            style={{ background: matatu.color }}
                          >
                            <Navigation className="h-5 w-5" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="font-display text-sm font-bold text-ink truncate">{matatu.name}</p>
                            <span className="text-xs text-ink-muted truncate">{matatu.destination}</span>
                          </div>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              ) : (
                <div>
                  {/* Selected matatu */}
                  <div className="mb-5 flex items-center gap-3 rounded-xl bg-primary-50 p-4">
                    <div
                      className="flex h-12 w-12 flex-shrink-0 items-center justify-center rounded-xl text-white"
                      style={{ background: selectedMatatu.color }}
                    >
                      <Navigation className="h-6 w-6" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-display text-base font-bold text-ink">{selectedMatatu.name}</p>
                      <span className="text-xs text-ink-muted">{selectedMatatu.destination}</span>
                    </div>
                    <button
                      onClick={() => setSelectedMatatu(null)}
                      className="text-xs font-semibold text-primary hover:underline"
                    >
                      Change
                    </button>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <label className="flex items-center gap-1.5 text-sm font-semibold text-ink-soft mb-2">
                        <MapPinned className="h-4 w-4 text-primary" />
                        Approximate Location or Stage *
                      </label>
                      <input
                        type="text"
                        value={location}
                        onChange={(e) => setLocation(e.target.value)}
                        placeholder="e.g. Roysambu, near TRM Mall"
                        className="w-full rounded-xl border-2 border-primary-100 px-4 py-3 text-sm text-ink outline-none focus:border-primary"
                      />
                      <p className="mt-1 text-[11px] text-ink-muted">
                        Do not share exact personal addresses. An approximate stage or landmark is enough.
                      </p>
                    </div>

                    <div>
                      <label className="flex items-center gap-1.5 text-sm font-semibold text-ink-soft mb-2">
                        <Navigation className="h-4 w-4 text-primary" />
                        Route or Destination
                      </label>
                      <input
                        type="text"
                        value={routeObserved}
                        onChange={(e) => setRouteObserved(e.target.value)}
                        placeholder="e.g. Route 33, Thika Road → Town"
                        className="w-full rounded-xl border-2 border-primary-100 px-4 py-3 text-sm text-ink outline-none focus:border-primary"
                      />
                    </div>

                    <div>
                      <label className="text-sm font-semibold text-ink-soft mb-2 block">Optional Note</label>
                      <textarea
                        value={notes}
                        onChange={(e) => setNotes(e.target.value)}
                        placeholder="e.g. Matatu was full, heading towards town"
                        rows={2}
                        className="w-full rounded-xl border-2 border-primary-100 px-4 py-3 text-sm text-ink outline-none focus:border-primary resize-none"
                      />
                    </div>
                  </div>

                  {error && (
                    <div className="mt-4 flex items-start gap-3 rounded-xl bg-red-50 p-4 border border-red-100">
                      <AlertCircle className="h-5 w-5 text-red-500 flex-shrink-0 mt-0.5" />
                      <p className="text-xs text-red-600">{error}</p>
                    </div>
                  )}

                  <div className="mt-4 rounded-xl bg-amber-50 p-3 border border-amber-100">
                    <p className="text-[11px] text-amber-800 leading-relaxed">
                      Your sighting will be marked as "Community Reported". It will not be labeled as live
                      unless an active location sharing session exists for this matatu.
                    </p>
                  </div>

                  <div className="mt-6 flex gap-3">
                    <Button variant="ghost" size="md" className="flex-1" onClick={() => setSelectedMatatu(null)}>
                      Back
                    </Button>
                    <Button
                      variant="primary"
                      size="md"
                      className="flex-1"
                      onClick={handleSubmit}
                      disabled={submitting || !location.trim()}
                    >
                      {submitting ? 'Submitting...' : 'Submit Sighting'}
                    </Button>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}
