import { useState } from 'react';
import {
  ArrowLeft, CheckCircle2, AlertCircle, Info, Plus,
  Navigation, MapPin, Building, Tag, FileText, Type,
} from 'lucide-react';
import { useRouter } from '@/router';
import Button from '@/components/Button';
import { submitNewMatatu, type NewMatatuInput } from '@/lib/matatuApi';

interface FormErrors {
  name?: string;
  route_number?: string;
  destination?: string;
  [key: string]: string | undefined;
}

export default function AddMatatu() {
  const { navigate } = useRouter();
  const [form, setForm] = useState<NewMatatuInput>({
    name: '',
    alias: '',
    route_number: '',
    destination: '',
    sacco: '',
    registration_number: '',
    description: '',
  });
  const [errors, setErrors] = useState<FormErrors>({});
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);

  const validate = (): boolean => {
    const e: FormErrors = {};
    if (!form.name.trim()) e.name = 'Matatu name is required';
    else if (form.name.trim().length < 2) e.name = 'Name must be at least 2 characters';
    if (!form.route_number.trim()) e.route_number = 'Route number is required';
    if (!form.destination.trim()) e.destination = 'Main destination is required';
    else if (form.destination.trim().length < 2) e.destination = 'Destination must be at least 2 characters';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = async () => {
    if (!validate()) return;
    setSubmitting(true);
    setSubmitError(null);

    const result = await submitNewMatatu({
      name: form.name.trim(),
      alias: form.alias.trim(),
      route_number: form.route_number.trim(),
      destination: form.destination.trim(),
      sacco: form.sacco.trim(),
      registration_number: form.registration_number.trim(),
      description: form.description.trim(),
    });

    setSubmitting(false);

    if (result.error) {
      setSubmitError(result.error);
    } else {
      setSuccess(true);
    }
  };

  const handleChange = (field: keyof NewMatatuInput, value: string) => {
    setForm({ ...form, [field]: value });
    if (errors[field]) {
      setErrors({ ...errors, [field]: undefined });
    }
  };

  if (success) {
    return (
      <div>
        <button
          onClick={() => navigate('explore')}
          className="mb-4 flex items-center gap-2 rounded-full bg-white px-4 py-2 text-sm font-semibold text-ink-soft shadow-card hover:text-primary transition-colors"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to Directory
        </button>
        <div className="rounded-3xl bg-white p-8 sm:p-12 text-center shadow-card border border-primary-100/30">
          <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-primary">
            <CheckCircle2 className="h-8 w-8 text-white" />
          </div>
          <h2 className="font-display text-xl font-extrabold text-ink">Matatu Submitted!</h2>
          <p className="mt-2 text-sm text-ink-muted max-w-sm mx-auto">
            Your matatu suggestion has been submitted with a <strong>Pending Verification</strong> status.
            Our team will review it before it appears as verified in the directory.
          </p>
          <div className="mt-6 flex flex-col gap-2 sm:flex-row sm:justify-center">
            <Button variant="primary" size="md" onClick={() => navigate('explore')}>
              Back to Directory
            </Button>
            <Button
              variant="outline"
              size="md"
              onClick={() => {
                setSuccess(false);
                setForm({
                  name: '', alias: '', route_number: '', destination: '',
                  sacco: '', registration_number: '', description: '',
                });
              }}
            >
              <Plus className="h-4 w-4" />
              Add Another
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div>
      <button
        onClick={() => navigate('explore')}
        className="mb-4 flex items-center gap-2 rounded-full bg-white px-4 py-2 text-sm font-semibold text-ink-soft shadow-card hover:text-primary transition-colors"
      >
        <ArrowLeft className="h-4 w-4" />
        Back to Directory
      </button>

      <div className="mb-6">
        <h1 className="font-display text-2xl font-extrabold text-ink">Add a Matatu</h1>
        <p className="mt-1 text-sm text-ink-muted">
          Suggest a new matatu for the directory. All submissions start as pending verification.
        </p>
      </div>

      {/* Pending verification notice */}
      <div className="mb-6 flex items-start gap-3 rounded-2xl bg-amber-50 p-4 border border-amber-100">
        <Info className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
        <div>
          <h3 className="font-display text-sm font-bold text-amber-800">Pending Verification</h3>
          <p className="mt-1 text-xs text-amber-700 leading-relaxed">
            New matatus are not automatically verified. They will be reviewed by our team before
            receiving a verified status. This helps prevent duplicates and inaccurate listings.
          </p>
        </div>
      </div>

      {submitError && (
        <div className="mb-4 flex items-start gap-3 rounded-2xl bg-red-50 p-4 border border-red-100">
          <AlertCircle className="h-5 w-5 text-red-500 flex-shrink-0 mt-0.5" />
          <div>
            <h3 className="font-display text-sm font-bold text-red-800">Submission Failed</h3>
            <p className="mt-1 text-xs text-red-600">{submitError}</p>
          </div>
        </div>
      )}

      {/* Form */}
      <div className="rounded-3xl bg-white p-6 sm:p-8 shadow-card border border-primary-100/30">
        <div className="space-y-5">
          {/* Matatu name */}
          <div>
            <label className="flex items-center gap-1.5 text-sm font-semibold text-ink-soft mb-2">
              <Type className="h-4 w-4 text-primary" />
              Popular Matatu Name *
            </label>
            <input
              type="text"
              value={form.name}
              onChange={(e) => handleChange('name', e.target.value)}
              placeholder="e.g. Nganya Supreme"
              className={`w-full rounded-xl border-2 px-4 py-3 text-sm text-ink outline-none transition-all ${
                errors.name
                  ? 'border-red-300 focus:border-red-400'
                  : 'border-primary-100 focus:border-primary'
              }`}
            />
            {errors.name && <p className="mt-1 text-xs text-red-500">{errors.name}</p>}
          </div>

          {/* Alternative name */}
          <div>
            <label className="flex items-center gap-1.5 text-sm font-semibold text-ink-soft mb-2">
              <Type className="h-4 w-4 text-primary" />
              Alternative Name or Alias
            </label>
            <input
              type="text"
              value={form.alias}
              onChange={(e) => handleChange('alias', e.target.value)}
              placeholder="e.g. Supreme, Nganya 33"
              className="w-full rounded-xl border-2 border-primary-100 px-4 py-3 text-sm text-ink outline-none transition-all focus:border-primary"
            />
            <p className="mt-1 text-[11px] text-ink-muted">
              Helps prevent duplicates if people search by a different spelling or nickname.
            </p>
          </div>

          {/* Route + Destination */}
          <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
            <div>
              <label className="flex items-center gap-1.5 text-sm font-semibold text-ink-soft mb-2">
                <Navigation className="h-4 w-4 text-primary" />
                Route Number *
              </label>
              <input
                type="text"
                value={form.route_number}
                onChange={(e) => handleChange('route_number', e.target.value)}
                placeholder="e.g. 33, 46, 125"
                className={`w-full rounded-xl border-2 px-4 py-3 text-sm text-ink outline-none transition-all ${
                  errors.route_number
                    ? 'border-red-300 focus:border-red-400'
                    : 'border-primary-100 focus:border-primary'
                }`}
              />
              {errors.route_number && <p className="mt-1 text-xs text-red-500">{errors.route_number}</p>}
            </div>

            <div>
              <label className="flex items-center gap-1.5 text-sm font-semibold text-ink-soft mb-2">
                <MapPin className="h-4 w-4 text-primary" />
                Main Destination *
              </label>
              <input
                type="text"
                value={form.destination}
                onChange={(e) => handleChange('destination', e.target.value)}
                placeholder="e.g. Thika Road → Town"
                className={`w-full rounded-xl border-2 px-4 py-3 text-sm text-ink outline-none transition-all ${
                  errors.destination
                    ? 'border-red-300 focus:border-red-400'
                    : 'border-primary-100 focus:border-primary'
                }`}
              />
              {errors.destination && <p className="mt-1 text-xs text-red-500">{errors.destination}</p>}
            </div>
          </div>

          {/* Sacco + Registration */}
          <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
            <div>
              <label className="flex items-center gap-1.5 text-sm font-semibold text-ink-soft mb-2">
                <Building className="h-4 w-4 text-primary" />
                Sacco
              </label>
              <input
                type="text"
                value={form.sacco}
                onChange={(e) => handleChange('sacco', e.target.value)}
                placeholder="e.g. Bungoma Express"
                className="w-full rounded-xl border-2 border-primary-100 px-4 py-3 text-sm text-ink outline-none transition-all focus:border-primary"
              />
            </div>

            <div>
              <label className="flex items-center gap-1.5 text-sm font-semibold text-ink-soft mb-2">
                <Tag className="h-4 w-4 text-primary" />
                Registration Number (optional)
              </label>
              <input
                type="text"
                value={form.registration_number}
                onChange={(e) => handleChange('registration_number', e.target.value)}
                placeholder="e.g. KDA 287X"
                className="w-full rounded-xl border-2 border-primary-100 px-4 py-3 text-sm text-ink outline-none transition-all focus:border-primary"
              />
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="flex items-center gap-1.5 text-sm font-semibold text-ink-soft mb-2">
              <FileText className="h-4 w-4 text-primary" />
              Description
            </label>
            <textarea
              value={form.description}
              onChange={(e) => handleChange('description', e.target.value)}
              placeholder="Tell the community about this matatu — its art, music, crew, or what makes it special."
              rows={4}
              className="w-full rounded-xl border-2 border-primary-100 px-4 py-3 text-sm text-ink outline-none transition-all focus:border-primary resize-none"
            />
          </div>

          {/* Photo placeholder */}
          <div>
            <label className="flex items-center gap-1.5 text-sm font-semibold text-ink-soft mb-2">
              <Plus className="h-4 w-4 text-primary" />
              Photo (optional)
            </label>
            <div className="rounded-xl border-2 border-dashed border-primary-100 p-8 text-center">
              <Plus className="mx-auto h-6 w-6 text-primary/40 mb-2" />
              <p className="text-xs text-ink-muted">
                Photo upload is coming soon. For now, submissions are text-only.
              </p>
            </div>
          </div>
        </div>

        {/* Submit */}
        <div className="mt-6 flex gap-3">
          <Button variant="ghost" size="md" className="flex-1" onClick={() => navigate('explore')}>
            Cancel
          </Button>
          <Button
            variant="primary"
            size="md"
            className="flex-1"
            onClick={handleSubmit}
            disabled={submitting}
          >
            {submitting ? 'Submitting...' : 'Submit for Review'}
          </Button>
        </div>
      </div>
    </div>
  );
}
