import { useState, useEffect, useCallback } from 'react';
import {
  ArrowLeft, Heart, Share2, Flag, MapPin, Users, Tag, Navigation,
  Eye, Clock, Image as ImageIcon, MessageCircle, TrendingUp,
  AlertCircle, Circle, Info, Camera, ArrowRight,
} from 'lucide-react';
import { useRouter } from '@/router';
import Button from '@/components/Button';
import VerificationBadge, { InfoStatusLabel } from '@/components/VerificationBadge';
import RouteLabel from '@/components/RouteLabel';
import { LoadingDetail, ErrorState } from '@/components/EmptyState';
import {
  fetchMatatuById, toggleFollow, submitMatatuReport,
  type MatatuRecord, type RidingSession,
} from '@/lib/matatuApi';
import ImRidingModal from '@/components/ImRidingModal';
import SharingStatusCard from '@/components/SharingStatusCard';

function timeAgo(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  return `${days}d ago`;
}

export default function MatatuDetails() {
  const { param, navigate } = useRouter();
  const [matatu, setMatatu] = useState<MatatuRecord | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [following, setFollowing] = useState(false);
  const [followLoading, setFollowLoading] = useState(false);
  const [showReportModal, setShowReportModal] = useState(false);
  const [showRidingModal, setShowRidingModal] = useState(false);
  const [mySession, setMySession] = useState<RidingSession | null>(null);
  const [reportType, setReportType] = useState('wrong_route');
  const [reportDetails, setReportDetails] = useState('');
  const [reportSubmitted, setReportSubmitted] = useState(false);

  const load = useCallback(async () => {
    if (!param) {
      setError('No matatu ID provided');
      setLoading(false);
      return;
    }
    setLoading(true);
    const result = await fetchMatatuById(param);
    if (result.error || !result.data) {
      setError(result.error || 'Matatu not found');
    } else {
      setMatatu(result.data);
    }
    setLoading(false);
  }, [param]);

  useEffect(() => {
    load();
  }, [load]);

  const handleFollow = async () => {
    if (!matatu) return;
    setFollowLoading(true);
    const result = await toggleFollow(matatu.id, following);
    if (!result.error) {
      setFollowing(!following);
      setMatatu({
        ...matatu,
        follower_count: following ? matatu.follower_count - 1 : matatu.follower_count + 1,
      });
    }
    setFollowLoading(false);
  };

  const handleReport = async () => {
    if (!matatu || !reportDetails.trim()) return;
    const result = await submitMatatuReport(matatu.id, reportType, reportDetails);
    if (!result.error) {
      setReportSubmitted(true);
      setTimeout(() => {
        setShowReportModal(false);
        setReportSubmitted(false);
        setReportDetails('');
      }, 2000);
    }
  };

  const handleRidingStarted = (session: RidingSession) => {
    setShowRidingModal(false);
    setMySession(session);
  };

  const handleSessionStopped = () => {
    setMySession(null);
  };

  const handleShare = async () => {
    if (navigator.share && matatu) {
      try {
        await navigator.share({
          title: `${matatu.name} — Matwana Live`,
          text: `Check out ${matatu.name} on Matwana Live`,
          url: window.location.href,
        });
      } catch {
        // User cancelled share
      }
    } else if (matatu) {
      try {
        await navigator.clipboard.writeText(window.location.href);
      } catch {
        // Clipboard not available
      }
    }
  };

  if (loading) return (
    <div>
      <div className="mb-4 h-10 w-32 bg-gray-200 rounded-full animate-pulse" />
      <LoadingDetail />
    </div>
  );

  if (error || !matatu) {
    return (
      <div>
        <button
          onClick={() => navigate('explore')}
          className="mb-4 flex items-center gap-2 rounded-full bg-white px-4 py-2 text-sm font-semibold text-ink-soft shadow-card hover:text-primary transition-colors"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to Directory
        </button>
        <ErrorState
          message={error || 'This matatu could not be found.'}
          onRetry={() => navigate('explore')}
        />
      </div>
    );
  }

  const coverImage = matatu.cover_image_url;
  const profileImage = matatu.profile_image_url;
  const hasOfficialVerification = matatu.verifications?.some(
    (v) => v.verification_type === 'official' && v.status === 'verified'
  );
  const isOutdated = Date.now() - new Date(matatu.last_activity_at).getTime() > 7 * 24 * 60 * 60 * 1000;

  return (
    <div>
      {/* Back button */}
      <button
        onClick={() => navigate('explore')}
        className="mb-4 flex items-center gap-2 rounded-full bg-white px-4 py-2 text-sm font-semibold text-ink-soft shadow-card transition-all hover:shadow-card-hover hover:text-primary active:scale-95"
      >
        <ArrowLeft className="h-4 w-4" />
        Back to Directory
      </button>

      {/* Cover image */}
      <div className="relative overflow-hidden rounded-3xl h-40 sm:h-56 shadow-card">
        {coverImage ? (
          <img src={coverImage} alt={matatu.name} className="h-full w-full object-cover" />
        ) : (
          <div
            className="h-full w-full"
            style={{ background: `linear-gradient(135deg, ${matatu.color}, ${matatu.color}aa)` }}
          />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-ink/80 via-ink/20 to-transparent" />
        <div className="absolute inset-0 bg-grid opacity-20" />

        {matatu.trending && (
          <div className="absolute top-4 left-4 flex items-center gap-1 rounded-full bg-accent px-2.5 py-1 text-[10px] font-bold text-white shadow-glow">
            <TrendingUp className="h-3 w-3" />
            Trending
          </div>
        )}

        <div className="absolute bottom-4 left-4 right-4 flex items-end justify-between">
          <div className="flex items-end gap-3">
            {/* Profile image */}
            <div className="h-16 w-16 sm:h-20 sm:w-20 rounded-2xl overflow-hidden border-2 border-white shadow-card flex-shrink-0">
              {profileImage ? (
                <img src={profileImage} alt={matatu.name} className="h-full w-full object-cover" />
              ) : (
                <div
                  className="h-full w-full flex items-center justify-center"
                  style={{ background: matatu.color }}
                >
                  <Navigation className="h-8 w-8 text-white" />
                </div>
              )}
            </div>
            <div className="text-white pb-1">
              <h1 className="font-display text-xl font-extrabold sm:text-2xl drop-shadow">{matatu.name}</h1>
              <div className="mt-1">
                <RouteLabel routeNumber={matatu.route_number || '—'} size="sm" />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Verification + action buttons */}
      <div className="mt-4 flex flex-wrap items-center gap-2">
        <VerificationBadge status={matatu.verification_status} size="md" />
        {isOutdated && (
          <InfoStatusLabel label="Info may be outdated" type="old" />
        )}
      </div>

      {/* Share This Matatu — prominent action */}
      <div className="mt-4">
        {mySession ? (
          <SharingStatusCard
            session={mySession}
            onStopped={handleSessionStopped}
            onExpired={handleSessionStopped}
          />
        ) : (
          <button
            onClick={() => setShowRidingModal(true)}
            className="w-full group relative overflow-hidden rounded-2xl bg-gradient-to-br from-primary to-primary-dark p-4 text-white shadow-card-hover transition-all hover:scale-[1.01] active:scale-[0.99]"
          >
            <div className="absolute inset-0 bg-grid opacity-20" />
            <div className="relative flex items-center gap-3">
              <div className="flex h-11 w-11 flex-shrink-0 items-center justify-center rounded-xl bg-accent shadow-glow">
                <Navigation className="h-5 w-5 text-white" />
              </div>
              <div className="flex-1 text-left">
                <p className="font-display text-base font-extrabold">Share This Matatu</p>
                <p className="text-xs text-white/70">Let the community know you are riding this matatu</p>
              </div>
              <ArrowRight className="h-5 w-5" />
            </div>
          </button>
        )}
      </div>

      <div className="mt-3 flex flex-wrap gap-2">
        <Button
          variant={following ? 'accent' : 'primary'}
          size="sm"
          onClick={handleFollow}
          disabled={followLoading}
        >
          <Heart className={`h-4 w-4 ${following ? 'fill-white' : ''}`} />
          {following ? 'Following' : 'Follow'}
        </Button>
        <Button variant="outline" size="sm" onClick={handleShare}>
          <Share2 className="h-4 w-4" />
          Share Link
        </Button>
        <Button variant="ghost" size="sm" onClick={() => setShowReportModal(true)}>
          <Flag className="h-4 w-4" />
          Report
        </Button>
        <Button variant="ghost" size="sm" onClick={() => navigate('create')}>
          <MessageCircle className="h-4 w-4" />
          Ask Community
        </Button>
      </div>

      {/* Stats grid */}
      <div className="mt-5 grid grid-cols-3 gap-3">
        <div className="rounded-2xl bg-white p-4 text-center shadow-card border border-primary-100/30">
          <Users className="mx-auto h-5 w-5 text-primary mb-1.5" />
          <p className="font-display text-lg font-extrabold text-ink">{matatu.follower_count.toLocaleString()}</p>
          <p className="text-[10px] text-ink-muted">Followers</p>
        </div>
        <div className="rounded-2xl bg-white p-4 text-center shadow-card border border-primary-100/30">
          <Eye className="mx-auto h-5 w-5 text-primary mb-1.5" />
          <p className="font-display text-lg font-extrabold text-ink">{matatu.sighting_count}</p>
          <p className="text-[10px] text-ink-muted">Sightings</p>
        </div>
        <div className="rounded-2xl bg-white p-4 text-center shadow-card border border-primary-100/30">
          <Clock className="mx-auto h-5 w-5 text-primary mb-1.5" />
          <p className="font-display text-sm font-extrabold text-ink">{timeAgo(matatu.last_activity_at)}</p>
          <p className="text-[10px] text-ink-muted">Last Activity</p>
        </div>
      </div>

      {/* Route and stage section */}
      <div className="mt-6 rounded-2xl bg-white p-6 shadow-card border border-primary-100/30">
        <h2 className="font-display text-lg font-bold text-ink mb-4 flex items-center gap-2">
          <Navigation className="h-5 w-5 text-primary" />
          Route & Stage
        </h2>
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <div className="rounded-xl bg-primary-50 px-4 py-3">
            <p className="text-[10px] font-semibold uppercase tracking-wider text-ink-muted">Route</p>
            <p className="mt-1 flex items-center gap-2">
              <RouteLabel routeNumber={matatu.route_number || 'Unknown'} size="sm" />
            </p>
          </div>
          <div className="rounded-xl bg-primary-50 px-4 py-3">
            <p className="text-[10px] font-semibold uppercase tracking-wider text-ink-muted">Main Destination</p>
            <p className="mt-1 text-sm font-medium text-ink flex items-center gap-1.5">
              <MapPin className="h-4 w-4 text-primary" />
              {matatu.destination}
            </p>
          </div>
          {matatu.stage && (
            <div className="rounded-xl bg-primary-50 px-4 py-3">
              <p className="text-[10px] font-semibold uppercase tracking-wider text-ink-muted">Stage</p>
              <p className="mt-1 text-sm font-medium text-ink flex items-center gap-1.5">
                <MapPin className="h-4 w-4 text-primary" />
                {matatu.stage}
              </p>
            </div>
          )}
          {matatu.sacco && (
            <div className="rounded-xl bg-primary-50 px-4 py-3">
              <p className="text-[10px] font-semibold uppercase tracking-wider text-ink-muted">Sacco</p>
              <p className="mt-1 text-sm font-medium text-ink">{matatu.sacco}</p>
            </div>
          )}
          {matatu.registration_number && (
            <div className="rounded-xl bg-primary-50 px-4 py-3">
              <p className="text-[10px] font-semibold uppercase tracking-wider text-ink-muted">Registration</p>
              <p className="mt-1 text-sm font-medium text-ink flex items-center gap-1.5">
                <Tag className="h-4 w-4 text-primary" />
                {matatu.registration_number}
              </p>
            </div>
          )}
          {matatu.capacity && (
            <div className="rounded-xl bg-primary-50 px-4 py-3">
              <p className="text-[10px] font-semibold uppercase tracking-wider text-ink-muted">Capacity</p>
              <p className="mt-1 text-sm font-medium text-ink flex items-center gap-1.5">
                <Users className="h-4 w-4 text-primary" />
                {matatu.capacity}
              </p>
            </div>
          )}
        </div>

        {/* Info source labels */}
        <div className="mt-4 flex flex-wrap gap-2">
          {hasOfficialVerification ? (
            <InfoStatusLabel label="Officially verified" type="official" />
          ) : matatu.verification_status === 'community_reported' ? (
            <InfoStatusLabel label="Community-provided info" type="community" />
          ) : matatu.verification_status === 'pending' ? (
            <InfoStatusLabel label="Pending verification" type="unverified" />
          ) : (
            <InfoStatusLabel label="Unverified info" type="unverified" />
          )}
          {isOutdated && (
            <InfoStatusLabel label="Information may be outdated" type="old" />
          )}
        </div>

        {matatu.description && (
          <p className="mt-4 text-sm text-ink-muted leading-relaxed">{matatu.description}</p>
        )}
      </div>

      {/* Aliases */}
      {matatu.aliases && matatu.aliases.length > 0 && (
        <div className="mt-6 rounded-2xl bg-white p-6 shadow-card border border-primary-100/30">
          <h2 className="font-display text-lg font-bold text-ink mb-3">Also Known As</h2>
          <div className="flex flex-wrap gap-2">
            {matatu.aliases.map((alias) => (
              <span
                key={alias}
                className="rounded-full bg-primary-50 px-3 py-1.5 text-xs font-medium text-primary"
              >
                {alias}
              </span>
            ))}
          </div>
        </div>
      )}

      {/* Photos section */}
      <div className="mt-6 rounded-2xl bg-white p-6 shadow-card border border-primary-100/30">
        <h2 className="font-display text-lg font-bold text-ink mb-4 flex items-center gap-2">
          <Camera className="h-5 w-5 text-primary" />
          Photos
        </h2>
        {matatu.photos && matatu.photos.length > 0 ? (
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
            {matatu.photos.map((photo) => (
              <div key={photo.id} className="relative overflow-hidden rounded-xl aspect-video group">
                <img
                  src={photo.photo_url}
                  alt={photo.caption || matatu.name}
                  className="h-full w-full object-cover transition-transform group-hover:scale-105"
                />
                {photo.caption && (
                  <div className="absolute inset-x-0 bottom-0 bg-ink/70 px-2 py-1">
                    <p className="text-[10px] text-white truncate">{photo.caption}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-8 text-center">
            <ImageIcon className="h-8 w-8 text-ink-muted/30 mb-2" />
            <p className="text-sm text-ink-muted">No photos yet. Community photos will appear here.</p>
          </div>
        )}
      </div>

      {/* Recent activity / sightings */}
      <div className="mt-6 rounded-2xl bg-white p-6 shadow-card border border-primary-100/30">
        <h2 className="font-display text-lg font-bold text-ink mb-4 flex items-center gap-2">
          <Eye className="h-5 w-5 text-primary" />
          Recent Activity
        </h2>
        {matatu.sightings && matatu.sightings.length > 0 ? (
          <div className="space-y-3">
            {matatu.sightings.map((sighting) => (
              <div key={sighting.id} className="flex items-start gap-3 rounded-xl bg-primary-50/50 p-3">
                <div className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-lg bg-primary text-white">
                  <MapPin className="h-4 w-4" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-ink">
                    {sighting.location || 'Location not specified'}
                  </p>
                  {sighting.notes && (
                    <p className="text-xs text-ink-muted mt-0.5">{sighting.notes}</p>
                  )}
                  <div className="mt-1 flex items-center gap-2">
                    <span className="text-[10px] text-ink-muted flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      {timeAgo(sighting.sighting_time)}
                    </span>
                    <InfoStatusLabel label="Community reported" type="community" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-8 text-center">
            <Clock className="h-8 w-8 text-ink-muted/30 mb-2" />
            <p className="text-sm text-ink-muted">No recent activity reported. Community sightings will appear here.</p>
          </div>
        )}
      </div>

      {/* Verification details */}
      {matatu.verifications && matatu.verifications.length > 0 && (
        <div className="mt-6 rounded-2xl bg-white p-6 shadow-card border border-primary-100/30">
          <h2 className="font-display text-lg font-bold text-ink mb-4 flex items-center gap-2">
            <Info className="h-5 w-5 text-primary" />
            Verification History
          </h2>
          <div className="space-y-2">
            {matatu.verifications.map((v) => (
              <div key={v.id} className="flex items-center justify-between rounded-xl bg-gray-50 p-3">
                <div>
                  <p className="text-xs font-semibold text-ink capitalize">
                    {v.verification_type.replace(/_/g, ' ')}
                  </p>
                  {v.notes && <p className="text-[11px] text-ink-muted mt-0.5">{v.notes}</p>}
                </div>
                <span className={`rounded-full px-2.5 py-1 text-[10px] font-semibold capitalize ${
                  v.status === 'verified' ? 'bg-primary-50 text-primary' :
                  v.status === 'pending' ? 'bg-amber-100 text-amber-700' :
                  v.status === 'rejected' ? 'bg-red-50 text-red-600' :
                  'bg-gray-100 text-ink-muted'
                }`}>
                  {v.status}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Live location placeholder */}
      <div className="mt-6 rounded-2xl bg-ink p-6 text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-grid opacity-20" />
        <div className="absolute inset-0 bg-gradient-to-br from-primary/30 to-transparent" />
        <div className="relative">
          <div className="flex items-center gap-2 mb-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary">
              <MapPin className="h-5 w-5 text-white" />
            </div>
            <div>
              <h2 className="font-display text-lg font-bold">Live Location</h2>
              <p className="text-xs text-white/50">Coming in a future version</p>
            </div>
          </div>
          <p className="text-sm text-white/60 leading-relaxed">
            Real-time GPS tracking is not yet available. We do not show fake coordinates or simulate
            live movement. Live location tracking will be introduced in a future step with user consent
            and privacy controls.
          </p>
          <div className="mt-3 flex items-center gap-1.5">
            <Circle className="h-2 w-2 fill-accent text-accent" />
            <span className="text-[10px] font-semibold uppercase tracking-wider text-accent">Not Live</span>
          </div>
        </div>
      </div>

      {/* Report modal */}
      {showReportModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-ink/50 backdrop-blur-sm p-4"
          onClick={() => setShowReportModal(false)}
        >
          <div
            className="w-full max-w-md rounded-3xl bg-white p-6 shadow-card-hover animate-fade-up"
            onClick={(e) => e.stopPropagation()}
          >
            {reportSubmitted ? (
              <div className="text-center py-6">
                <div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-primary">
                  <Info className="h-6 w-6 text-white" />
                </div>
                <h3 className="font-display text-base font-bold text-ink">Report Submitted</h3>
                <p className="mt-1 text-sm text-ink-muted">Thank you. Our team will review this report.</p>
              </div>
            ) : (
              <>
                <div className="flex items-center gap-2 mb-4">
                  <AlertCircle className="h-5 w-5 text-primary" />
                  <h3 className="font-display text-lg font-bold text-ink">Report Information</h3>
                </div>
                <p className="text-sm text-ink-muted mb-4">
                  Help us keep the directory accurate. Tell us what is wrong with this matatu listing.
                </p>
                <div className="space-y-3">
                  <div>
                    <label className="text-xs font-semibold text-ink-soft mb-1.5 block">Report type</label>
                    <select
                      value={reportType}
                      onChange={(e) => setReportType(e.target.value)}
                      className="w-full rounded-xl border-2 border-primary-100 bg-white px-3 py-2.5 text-sm text-ink outline-none focus:border-primary"
                    >
                      <option value="wrong_route">Wrong route</option>
                      <option value="wrong_name">Wrong name</option>
                      <option value="wrong_destination">Wrong destination</option>
                      <option value="inactive">Matatu no longer active</option>
                      <option value="duplicate">Duplicate listing</option>
                      <option value="other">Other</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-ink-soft mb-1.5 block">Details</label>
                    <textarea
                      value={reportDetails}
                      onChange={(e) => setReportDetails(e.target.value)}
                      placeholder="Describe what is incorrect..."
                      rows={3}
                      className="w-full rounded-xl border-2 border-primary-100 bg-white px-3 py-2.5 text-sm text-ink outline-none focus:border-primary resize-none"
                    />
                  </div>
                  <div className="flex gap-2 pt-2">
                    <Button variant="ghost" size="sm" className="flex-1" onClick={() => setShowReportModal(false)}>
                      Cancel
                    </Button>
                    <Button
                      variant="primary"
                      size="sm"
                      className="flex-1"
                      onClick={handleReport}
                      disabled={!reportDetails.trim()}
                    >
                      Submit Report
                    </Button>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {/* I'm Riding Modal */}
      <ImRidingModal
        open={showRidingModal}
        onClose={() => setShowRidingModal(false)}
        onStarted={handleRidingStarted}
        preselectedMatatu={matatu}
      />
    </div>
  );
}
