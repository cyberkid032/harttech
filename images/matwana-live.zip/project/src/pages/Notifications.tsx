import { Bell, Circle, Eye, Video, MessageCircleQuestion, Info } from 'lucide-react';
import { demoNotifications } from '@/data/demoData';

const typeIcons = {
  system: Info,
  matatu: Eye,
  video: Video,
  question: MessageCircleQuestion,
};

export default function Notifications() {
  return (
    <div>
      <div className="mb-6">
        <div className="flex items-center gap-2">
          <Bell className="h-6 w-6 text-primary" />
          <h1 className="font-display text-2xl font-extrabold text-ink">Notifications</h1>
        </div>
        <p className="mt-1 text-sm text-ink-muted">
          Demo notifications. Real alerts arrive with authentication.
        </p>
      </div>

      {/* Demo banner */}
      <div className="mb-4 flex items-center gap-2 rounded-xl bg-primary-50 px-4 py-2.5">
        <Circle className="h-2 w-2 fill-accent text-accent" />
        <span className="text-xs font-medium text-ink-soft">
          {demoNotifications.filter(n => n.unread).length} unread demo notifications
        </span>
      </div>

      <div className="space-y-3">
        {demoNotifications.map((notif) => {
          const Icon = typeIcons[notif.type] ?? Info;
          return (
            <div
              key={notif.id}
              className={`flex items-start gap-4 rounded-2xl p-4 shadow-card transition-all hover:shadow-card-hover border border-primary-100/20 ${
                notif.unread ? 'bg-white' : 'bg-gray-50'
              }`}
            >
              <div
                className={`flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-xl ${
                  notif.unread ? 'bg-primary text-white' : 'bg-gray-200 text-ink-muted'
                }`}
              >
                <Icon className="h-5 w-5" />
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <h3 className="font-display text-sm font-bold text-ink truncate">
                    {notif.title}
                  </h3>
                  {notif.unread && (
                    <div className="h-2 w-2 flex-shrink-0 rounded-full bg-accent" />
                  )}
                </div>
                <p className="mt-1 text-xs text-ink-muted leading-relaxed">
                  {notif.message}
                </p>
                <p className="mt-1.5 text-[10px] text-ink-muted/70">{notif.time}</p>
              </div>
            </div>
          );
        })}
      </div>

      <div className="mt-6 rounded-2xl bg-primary-50 p-5">
        <div className="flex items-start gap-3">
          <Info className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
          <div>
            <h3 className="font-display text-sm font-bold text-ink">About these notifications</h3>
            <p className="mt-1 text-xs text-ink-muted leading-relaxed">
              These are demo notifications to show how the system will look. When authentication
              is added, you will receive real alerts for sightings, community replies, and
              matatu updates.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
