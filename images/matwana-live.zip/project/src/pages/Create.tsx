import { Eye, Video, MessageCircleQuestion, ArrowRight, Circle, Plus, CheckCircle2 } from 'lucide-react';
import { useRouter } from '@/router';
import { createOptions } from '@/data/demoData';

const iconMap = { Eye, Video, MessageCircleQuestion };

export default function Create() {
  const { navigate } = useRouter();

  return (
    <div>
      <div className="mb-6">
        <h1 className="font-display text-2xl font-extrabold text-ink">Create</h1>
        <p className="mt-1 text-sm text-ink-muted">
          Share matatu sightings, videos, and questions with the community.
        </p>
      </div>

      {/* Available now: Add Matatu */}
      <div className="mb-6 rounded-3xl bg-gradient-to-br from-primary to-primary-dark p-6 text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-grid opacity-20" />
        <div className="relative flex items-center gap-4">
          <div className="flex h-14 w-14 flex-shrink-0 items-center justify-center rounded-2xl bg-white/20">
            <Plus className="h-7 w-7" />
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-1">
              <h2 className="font-display text-lg font-bold">Add a Matatu</h2>
              <span className="rounded-full bg-accent px-2 py-0.5 text-[10px] font-bold text-white">
                Available Now
              </span>
            </div>
            <p className="text-sm text-white/70">
              Suggest a new matatu for the directory. Submissions are reviewed before going live.
            </p>
          </div>
          <button
            onClick={() => navigate('add-matatu')}
            className="flex-shrink-0 rounded-full bg-white px-4 py-2 text-sm font-bold text-primary transition-all hover:scale-105 active:scale-95"
          >
            Get Started
            <ArrowRight className="inline h-3.5 w-3.5 ml-1" />
          </button>
        </div>
      </div>

      {/* Coming soon options */}
      <div className="mb-4">
        <p className="text-xs font-semibold uppercase tracking-wider text-ink-muted mb-3">Coming Soon</p>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
          {createOptions.map((option) => {
            const Icon = iconMap[option.icon as keyof typeof iconMap] ?? Eye;
            return (
              <div
                key={option.id}
                className="group relative overflow-hidden rounded-2xl bg-white p-6 shadow-card transition-all hover:shadow-card-hover hover:-translate-y-1 border border-primary-100/30"
              >
                <div className="absolute top-4 right-4">
                  <span className="rounded-full bg-primary-50 px-2.5 py-1 text-[10px] font-bold text-primary">
                    {option.badge}
                  </span>
                </div>

                <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-primary text-white transition-transform group-hover:scale-110">
                  <Icon className="h-6 w-6" />
                </div>

                <h3 className="font-display text-base font-bold text-ink mb-2 pr-16">
                  {option.title}
                </h3>
                <p className="text-sm text-ink-muted leading-relaxed">
                  {option.description}
                </p>

                <div className="mt-4 flex items-center gap-1 text-xs font-semibold text-primary opacity-50">
                  <span>Coming soon</span>
                  <ArrowRight className="h-3.5 w-3.5" />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Future vision */}
      <div className="mt-8 rounded-3xl bg-ink p-6 sm:p-8 text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-grid opacity-30" />
        <div className="absolute inset-0 bg-gradient-to-br from-primary/30 to-transparent" />
        <div className="relative">
          <h2 className="font-display text-xl font-bold mb-3">What is coming next</h2>
          <p className="text-sm text-white/60 leading-relaxed max-w-2xl">
            In future steps, you will be able to post a matatu sighting with photos, upload short
            videos of your rides, ask the community about routes and timings, and build your
            reputation with Trust Points. Authentication will power all of this.
          </p>
          <div className="mt-5 flex flex-wrap gap-3">
            {['Photo Sightings', 'Short Videos', 'Community Q&A', 'Trust Points', 'Route Tips'].map((tag) => (
              <span
                key={tag}
                className="rounded-full border border-white/15 px-3 py-1.5 text-xs font-medium text-white/70"
              >
                {tag}
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
