import { useState, useEffect, useCallback } from 'react';
import {
  SlidersHorizontal, TrendingUp, Plus, ArrowRight, SearchX,
  Navigation, MapPin, Clock, X, History, Trash2, WifiOff,
  FlaskConical, Radio, Search as SearchIcon,
} from 'lucide-react';
import MatatuCard from '@/components/MatatuCard';
import SearchField from '@/components/SearchField';
import FilterControl, { SortControl } from '@/components/FilterControl';
import EmptyState, { LoadingGrid, ErrorState } from '@/components/EmptyState';
import Button from '@/components/Button';
import { useRouter } from '@/router';
import {
  fetchMatatus, fetchRouteNumbers, searchByAlias,
  fetchRiderCounts, parseDestinationSearch, fetchDestinations,
  type MatatuRecord, type SortOption, type VerificationFilter,
} from '@/lib/matatuApi';
import {
  isDemoMode, searchDemoMatatus, demoMatatus, getDemoDestinations,
} from '@/lib/demoMode';
import {
  getSearchHistory, addSearchHistory, clearSearchHistory,
} from '@/lib/searchHistory';

const verificationChips: { id: VerificationFilter; label: string }[] = [
  { id: 'all', label: 'All' },
  { id: 'verified', label: 'Verified' },
  { id: 'community_reported', label: 'Community' },
  { id: 'pending', label: 'Pending' },
  { id: 'unverified', label: 'Unverified' },
];

const sortOptions = [
  { id: 'popular' as SortOption, label: 'Popular' },
  { id: 'recent' as SortOption, label: 'Recently Active' },
  { id: 'most_followed' as SortOption, label: 'Most Followed' },
];

export default function Explore() {
  const { navigate } = useRouter();

  const [search, setSearch] = useState('');
  const [routeFilter, setRouteFilter] = useState('all');
  const [verificationFilter, setVerificationFilter] = useState<VerificationFilter>('all');
  const [sort, setSort] = useState<SortOption>('popular');

  const [matatus, setMatatus] = useState<MatatuRecord[]>([]);
  const [routeNumbers, setRouteNumbers] = useState<string[]>([]);
  const [riderCounts, setRiderCounts] = useState<Map<string, number>>(new Map());
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [offline, setOffline] = useState(!navigator.onLine);
  const [demoMode, setDemoMode] = useState(isDemoMode());
  const [searchHistory, setSearchHistory] = useState<string[]>([]);
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [showHistory, setShowHistory] = useState(false);
  const [hasSearched, setHasSearched] = useState(false);

  const destSearch = parseDestinationSearch(search);
  const isDestinationSearch = destSearch.isDestinationSearch && destSearch.destination;

  useEffect(() => {
    const onOnline = () => setOffline(false);
    const onOffline = () => setOffline(true);
    window.addEventListener('online', onOnline);
    window.addEventListener('offline', onOffline);
    return () => {
      window.removeEventListener('online', onOnline);
      window.removeEventListener('offline', onOffline);
    };
  }, []);

  useEffect(() => {
    const onDemoChange = () => setDemoMode(isDemoMode());
    window.addEventListener('demo-mode-change', onDemoChange);
    return () => window.removeEventListener('demo-mode-change', onDemoChange);
  }, []);

  useEffect(() => {
    if (demoMode) {
      setRouteNumbers([...new Set(demoMatatus.map((m) => m.route_number).filter(Boolean))] as string[]);
    } else {
      fetchRouteNumbers().then(setRouteNumbers);
    }
  }, [demoMode]);

  useEffect(() => {
    setSearchHistory(getSearchHistory());

    if (demoMode) {
      setSuggestions(getDemoDestinations().slice(0, 5));
    } else {
      fetchDestinations().then((dests) => setSuggestions(dests.slice(0, 5)));
    }
  }, [demoMode]);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);

    if (!navigator.onLine && !demoMode) {
      setOffline(true);
      setLoading(false);
      return;
    }

    if (demoMode) {
      const results = searchDemoMatatus(search);
      let filtered = results;
      if (routeFilter !== 'all') {
        filtered = filtered.filter((m) => m.route_number === routeFilter);
      }
      if (verificationFilter !== 'all') {
        filtered = filtered.filter((m) => m.verification_status === verificationFilter);
      }
      setMatatus(filtered);
      setRiderCounts(new Map());
      setLoading(false);
      return;
    }

    let results = await fetchMatatus({
      search: search || undefined,
      routeFilter,
      verificationFilter,
      sort,
    });

    if (!results.error && search) {
      const aliasIds = await searchByAlias(search);
      if (aliasIds.length > 0) {
        const existingIds = new Set(results.data.map((m) => m.id));
        const aliasMatatus = await fetchMatatus({ sort });
        const extra = aliasMatatus.data.filter(
          (m) => aliasIds.includes(m.id) && !existingIds.has(m.id)
        );
        results = { data: [...results.data, ...extra], error: null };
      }
    }

    if (results.error) {
      setError(results.error);
      setMatatus([]);
    } else {
      setMatatus(results.data);

      if (results.data.length > 0) {
        const counts = await fetchRiderCounts(results.data.map((m) => m.id));
        setRiderCounts(counts);
      } else {
        setRiderCounts(new Map());
      }
    }
    setLoading(false);
  }, [search, routeFilter, verificationFilter, sort, demoMode]);

  useEffect(() => {
    const timer = setTimeout(() => {
      load();
      if (search.trim()) {
        setHasSearched(true);
        setShowHistory(false);
      } else {
        setHasSearched(false);
      }
    }, 300);
    return () => clearTimeout(timer);
  }, [load, search]);

  const handleSearchSubmit = () => {
    if (search.trim()) {
      addSearchHistory(search.trim());
      setSearchHistory(getSearchHistory());
      setShowHistory(false);
    }
  };

  const handleSuggestionClick = (term: string) => {
    setSearch(term);
    addSearchHistory(term);
    setSearchHistory(getSearchHistory());
    setShowHistory(false);
  };

  const handleClearHistory = () => {
    clearSearchHistory();
    setSearchHistory([]);
  };

  const routeChips = [
    { id: 'all', label: 'All Routes' },
    ...routeNumbers.map((r) => ({ id: r, label: `Route ${r}` })),
  ];

  const trendingMatatus = matatus.filter((m) => m.trending);
  const showTrending = !search && routeFilter === 'all' && verificationFilter === 'all';

  const clearFilters = () => {
    setSearch('');
    setRouteFilter('all');
    setVerificationFilter('all');
    setSort('popular');
  };

  return (
    <div>
      <div className="mb-6">
        <h1 className="font-display text-2xl font-extrabold text-ink">Find a Matatu</h1>
        <p className="mt-1 text-sm text-ink-muted">
          Search by name, alias, route, destination, Sacco, or stage.
        </p>
      </div>

      {/* Demo Mode banner */}
      {demoMode && (
        <div className="mb-4 flex items-center gap-2 rounded-xl bg-amber-50 px-4 py-2.5 border border-amber-100">
          <FlaskConical className="h-4 w-4 text-amber-600 flex-shrink-0" />
          <span className="text-xs font-medium text-amber-800">
            Demo Mode — information is fictional and not live.
          </span>
          <button
            onClick={() => { setDemoMode(false); }}
            className="ml-auto text-xs font-semibold text-amber-700 hover:underline"
          >
            Exit Demo
          </button>
        </div>
      )}

      {/* Search bar */}
      <div className="mb-4 relative">
        <SearchField
          value={search}
          onChange={setSearch}
          onClear={clearFilters}
          onFocus={() => setShowHistory(true)}
          placeholder="Search matatu name, route, or destination"
        />

        {/* Search history & suggestions dropdown */}
        {showHistory && !search && (searchHistory.length > 0 || suggestions.length > 0) && (
          <div className="absolute z-20 mt-2 w-full rounded-2xl bg-white shadow-card-hover border border-primary-100/40 overflow-hidden">
            {searchHistory.length > 0 && (
              <div className="p-3">
                <div className="flex items-center justify-between mb-2">
                  <span className="flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wider text-ink-muted">
                    <History className="h-3 w-3" />
                    Recent Searches
                  </span>
                  <button
                    onClick={handleClearHistory}
                    className="flex items-center gap-1 text-[11px] text-ink-muted hover:text-red-500 transition-colors"
                  >
                    <Trash2 className="h-3 w-3" />
                    Clear
                  </button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {searchHistory.slice(0, 5).map((term, i) => (
                    <button
                      key={i}
                      onClick={() => handleSuggestionClick(term)}
                      className="flex items-center gap-1.5 rounded-full bg-primary-50 px-3 py-1.5 text-xs font-medium text-primary transition-all hover:bg-primary hover:text-white"
                    >
                      <Clock className="h-3 w-3" />
                      {term}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {suggestions.length > 0 && (
              <div className="p-3 border-t border-gray-100">
                <span className="flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wider text-ink-muted mb-2">
                  <SearchIcon className="h-3 w-3" />
                  Suggested Searches
                </span>
                <div className="flex flex-wrap gap-2">
                  {suggestions.map((term, i) => (
                    <button
                      key={i}
                      onClick={() => handleSuggestionClick(term)}
                      className="rounded-full bg-gray-100 px-3 py-1.5 text-xs font-medium text-ink-soft transition-all hover:bg-primary-50 hover:text-primary"
                    >
                      {term}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Add Matatu button */}
      <div className="mb-4 flex justify-end">
        <Button variant="accent" size="sm" onClick={() => navigate('add-matatu')}>
          <Plus className="h-4 w-4" />
          Add Matatu
        </Button>
      </div>

      {/* Destination search heading */}
      {isDestinationSearch && destSearch.destination && !loading && !error && (
        <div className="mb-4 rounded-2xl bg-primary-50 p-4 border border-primary-100/40">
          <h2 className="font-display text-base font-bold text-ink flex items-center gap-2">
            <MapPin className="h-5 w-5 text-primary" />
            Matatus to {destSearch.destination}
          </h2>
          <p className="mt-1 text-xs text-ink-muted">
            {matatus.length > 0
              ? `${matatus.length} matatu${matatus.length !== 1 ? 's' : ''} found for this destination.`
              : 'No matatus found for this destination yet.'}
            {!demoMode && ' Only community-submitted and verified matatus are shown.'}
          </p>
        </div>
      )}

      {/* Route filter */}
      <div className="mb-3">
        <p className="text-[11px] font-semibold uppercase tracking-wider text-ink-muted mb-2">Route</p>
        <FilterControl
          chips={routeChips}
          activeId={routeFilter}
          onChange={setRouteFilter}
        />
      </div>

      {/* Verification filter + Sort */}
      <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex-1">
          <p className="text-[11px] font-semibold uppercase tracking-wider text-ink-muted mb-2">Verification</p>
          <FilterControl
            chips={verificationChips}
            activeId={verificationFilter}
            onChange={(v) => setVerificationFilter(v as VerificationFilter)}
          />
        </div>
        <div className="flex items-center gap-2">
          <SlidersHorizontal className="h-4 w-4 text-ink-muted" />
          <SortControl
            value={sort}
            onChange={(v) => setSort(v as SortOption)}
            options={sortOptions}
          />
        </div>
      </div>

      {/* Content */}
      {offline && !demoMode ? (
        <div className="rounded-2xl bg-white p-12 text-center shadow-card border border-primary-100/30">
          <div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-amber-50">
            <WifiOff className="h-6 w-6 text-amber-500" />
          </div>
          <h3 className="font-display text-base font-bold text-ink">No connection</h3>
          <p className="mt-1.5 text-sm text-ink-muted max-w-sm mx-auto">
            No connection. Please reconnect to search for current information.
          </p>
          <div className="mt-4">
            <Button variant="primary" size="sm" onClick={() => { setOffline(false); load(); }}>
              Try again
            </Button>
          </div>
        </div>
      ) : error ? (
        <ErrorState message={error} onRetry={load} />
      ) : loading ? (
        <LoadingGrid />
      ) : matatus.length === 0 ? (
        <EmptyState
          icon={<SearchX className="h-6 w-6 text-primary/50" />}
          title={hasSearched ? 'No matching matatus found' : 'No matatus yet'}
          message={
            hasSearched
              ? 'No matching matatus found. Try a different search term, or suggest a new matatu.'
              : 'No matatus have been added yet. Be the first person to add one.'
          }
          action={
            <div className="flex flex-col gap-2 sm:flex-row sm:justify-center">
              {hasSearched && (
                <Button variant="primary" size="sm" onClick={clearFilters}>
                  Clear filters
                  <ArrowRight className="h-3.5 w-3.5" />
                </Button>
              )}
              <Button variant="outline" size="sm" onClick={() => navigate('add-matatu')}>
                <Plus className="h-4 w-4" />
                Can't find the matatu? Suggest a new one
              </Button>
            </div>
          }
        />
      ) : (
        <>
          {/* Trending section — only when no search/filter active */}
          {showTrending && trendingMatatus.length > 0 && (
            <div className="mb-8">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-primary" />
                  <h2 className="font-display text-lg font-bold text-ink">Trending Matatus</h2>
                </div>
              </div>
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3">
                {trendingMatatus.map((matatu) => (
                  <MatatuCard
                    key={matatu.id}
                    matatu={matatu}
                    onOpenDetails={() => navigate('details', matatu.id)}
                    showTrending
                    riderCount={riderCounts.get(matatu.id) || 0}
                    isDemo={demoMode}
                  />
                ))}
              </div>
            </div>
          )}

          {/* All results */}
          <div>
            <div className="mb-4 flex items-center justify-between">
              <h2 className="font-display text-lg font-bold text-ink">
                {search || routeFilter !== 'all' || verificationFilter !== 'all'
                  ? `${matatus.length} result${matatus.length !== 1 ? 's' : ''}`
                  : 'All Matatus'}
              </h2>
              {(search || routeFilter !== 'all' || verificationFilter !== 'all') && (
                <button
                  onClick={clearFilters}
                  className="text-xs font-semibold text-primary hover:text-primary-dark transition-colors"
                >
                  Clear all
                </button>
              )}
            </div>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3">
              {matatus.map((matatu) => (
                <MatatuCard
                  key={matatu.id}
                  matatu={matatu}
                  onOpenDetails={() => navigate('details', matatu.id)}
                  riderCount={riderCounts.get(matatu.id) || 0}
                  isDemo={demoMode}
                />
              ))}
            </div>
          </div>
        </>
      )}

      {/* Click-away handler for history dropdown */}
      {showHistory && (
        <div
          className="fixed inset-0 z-10"
          onClick={() => setShowHistory(false)}
        />
      )}
    </div>
  );
}
