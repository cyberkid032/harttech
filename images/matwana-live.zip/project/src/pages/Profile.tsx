import { useState, useEffect } from 'react';
import {
  Settings, MapPin, Calendar, Users, Star, Circle, Pencil,
  FlaskConical, WifiOff, ChevronRight, Zap, ZapOff,
} from 'lucide-react';
import Button from '@/components/Button';
import { isDemoMode, setDemoMode } from '@/lib/demoMode';

export default function Profile() {
  const [demoActive, setDemoActive] = useState(isDemoMode());

  useEffect(() => {
    const onDemoChange = () => setDemoActive(isDemoMode());
    window.addEventListener('demo-mode-change', onDemoChange);
    return () => window.removeEventListener('demo-mode-change', onDemoChange);
  }, []);

  const handleToggleDemo = () => {
    const next = !demoActive;
    setDemoMode(next);
    setDemoActive(next);
  };

  const stats = [
    { label: 'Followers', value: '1,248', icon: Users },
    { label: 'Following', value: '342', icon: Star },
    { label: 'Trust Points', value: '850', icon: Star },
  ];

  const recentActivity = [
    { action: 'Explored Route 33 matatus', time: '2 hours ago' },
    { action: 'Viewed Nganya Supreme', time: '5 hours ago' },
    { action: 'Joined Matwana Live', time: '1 day ago' },
  ];

  return (
    <div>
      {/* Profile header */}
      <div className="relative overflow-hidden rounded-3xl bg-ink text-white">
        <div className="absolute inset-0 bg-grid opacity-30" />
        <div className="absolute inset-0 bg-gradient-to-br from-primary/40 to-transparent" />

        <div className="relative p-6 sm:p-8">
          <div className="flex flex-col items-center text-center sm:flex-row sm:text-left gap-4">
            {/* Avatar placeholder */}
            <div className="relative">
              <div className="flex h-20 w-20 items-center justify-center rounded-full bg-primary text-white font-display text-2xl font-extrabold shadow-glow sm:h-24 sm:w-24 border-2 border-accent/30">
                ML
              </div>
              <div className="absolute bottom-0 right-0 h-5 w-5 rounded-full border-2 border-ink bg-accent" />
            </div>

            <div className="flex-1">
              <div className="flex items-center justify-center gap-2 sm:justify-start">
                <h1 className="font-display text-xl font-extrabold sm:text-2xl">@matwana_rider</h1>
                <span className="rounded-full bg-primary/30 px-2 py-0.5 text-[10px] font-bold text-accent">
                  Demo
                </span>
              </div>
              <p className="mt-1 text-sm text-white/60">
                Matatu enthusiast & community member
              </p>
              <div className="mt-2 flex items-center justify-center gap-3 text-xs text-white/50 sm:justify-start">
                <span className="flex items-center gap-1">
                  <MapPin className="h-3.5 w-3.5" /> Nairobi, Kenya
                </span>
                <span className="flex items-center gap-1">
                  <Calendar className="h-3.5 w-3.5" /> Joined 2026
                </span>
              </div>
            </div>

            <div className="hidden sm:block">
              <Button variant="ghost" size="sm" className="text-white border border-white/20 hover:bg-white/10">
                <Pencil className="h-4 w-4" />
                Edit Profile
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Demo notice */}
      <div className="mt-4 flex items-center gap-2 rounded-xl bg-primary-50 px-4 py-2.5">
        <Circle className="h-2 w-2 fill-accent text-accent" />
        <span className="text-xs font-medium text-ink-soft">
          Profile data is demo only. Real accounts come with authentication.
        </span>
      </div>

      {/* Stats */}
      <div className="mt-6 grid grid-cols-3 gap-3">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <div
              key={stat.label}
              className="rounded-2xl bg-white p-4 text-center shadow-card sm:p-5 border border-primary-100/30"
            >
              <Icon className="mx-auto h-5 w-5 text-primary mb-2" />
              <p className="font-display text-xl font-extrabold text-ink sm:text-2xl">
                {stat.value}
              </p>
              <p className="text-[10px] font-medium text-ink-muted sm:text-xs">{stat.label}</p>
            </div>
          );
        })}
      </div>

      {/* Trust points info */}
      <div className="mt-6 rounded-2xl bg-primary-50 p-5">
        <div className="flex items-start gap-3">
          <Star className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
          <div>
            <h3 className="font-display text-sm font-bold text-ink">Trust Points</h3>
            <p className="mt-1 text-xs text-ink-muted leading-relaxed">
              Trust Points are a future reputation system. You will earn them by sharing accurate
              sightings, helping the community, and contributing quality content. The value shown
              here is a demo placeholder.
            </p>
          </div>
        </div>
      </div>

      {/* Recent activity */}
      <div className="mt-6">
        <h2 className="font-display text-lg font-bold text-ink mb-4">Recent Activity</h2>
        <div className="space-y-2">
          {recentActivity.map((activity, i) => (
            <div
              key={i}
              className="flex items-center justify-between rounded-xl bg-white p-4 shadow-card border border-primary-100/20"
            >
              <div className="flex items-center gap-3">
                <div className="h-2 w-2 rounded-full bg-accent" />
                <span className="text-sm text-ink-soft">{activity.action}</span>
              </div>
              <span className="text-xs text-ink-muted">{activity.time}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Developer / Admin Settings */}
      <div className="mt-6">
        <h2 className="font-display text-lg font-bold text-ink mb-4">Developer Settings</h2>

        {/* Demo Mode toggle */}
        <div className="rounded-2xl bg-white p-5 shadow-card border border-primary-100/30">
          <div className="flex items-start gap-4">
            <div className={`flex h-11 w-11 flex-shrink-0 items-center justify-center rounded-xl ${demoActive ? 'bg-amber-100 text-amber-600' : 'bg-primary-50 text-primary'}`}>
              <FlaskConical className="h-5 w-5" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between">
                <h3 className="font-display text-sm font-bold text-ink">Demo Mode</h3>
                <span className={`rounded-full px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wide ${demoActive ? 'bg-amber-100 text-amber-700' : 'bg-gray-100 text-ink-muted'}`}>
                  {demoActive ? 'Active' : 'Inactive'}
                </span>
              </div>
              <p className="mt-1 text-xs text-ink-muted leading-relaxed">
                {demoActive
                  ? 'Demo Mode is ON. All search results, directory cards, and matatu profiles use fictional test data. Real user data is hidden.'
                  : 'Demo Mode is OFF. Only real user-submitted data from the community is shown. No fictional matatus appear.'}
              </p>
              <div className="mt-3">
                <button
                  onClick={handleToggleDemo}
                  className={`flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-bold transition-all active:scale-[0.98] ${
                    demoActive
                      ? 'bg-gray-100 text-ink-soft hover:bg-gray-200'
                      : 'bg-amber-500 text-white hover:bg-amber-600'
                  }`}
                >
                  {demoActive ? (
                    <>
                      <ZapOff className="h-4 w-4" />
                      Disable Demo Mode
                    </>
                  ) : (
                    <>
                      <Zap className="h-4 w-4" />
                      Enable Demo Mode
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>

          {/* Demo Mode explanation */}
          <div className="mt-4 rounded-xl bg-amber-50 p-3 border border-amber-100">
            <p className="text-[11px] text-amber-800 leading-relaxed">
              Demo Mode is a developer and testing tool. When enabled, fictional matatus appear
              in the search, directory, and profiles so you can test the app without real data.
              Demo data is <strong>never</strong> shown as live, verified, or official. When
              disabled, only real community submissions appear.
            </p>
          </div>
        </div>

        {/* Offline mode info */}
        <div className="mt-3 rounded-2xl bg-white p-4 shadow-card border border-primary-100/30">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-xl bg-primary-50 text-primary">
              <WifiOff className="h-5 w-5" />
            </div>
            <div className="flex-1">
              <h3 className="font-display text-sm font-bold text-ink">Offline Mode</h3>
              <p className="text-xs text-ink-muted mt-0.5">
                When you lose connection, the search page shows a clear message. No old data is shown as live.
              </p>
            </div>
          </div>
        </div>

        {/* General settings (placeholder) */}
        <div className="mt-3">
          <button className="flex w-full items-center gap-3 rounded-2xl bg-white p-4 shadow-card transition-all hover:shadow-card-hover border border-primary-100/30">
            <Settings className="h-5 w-5 text-ink-muted" />
            <span className="flex-1 text-left text-sm font-medium text-ink">General Settings</span>
            <span className="text-xs text-ink-muted">Coming soon</span>
            <ChevronRight className="h-4 w-4 text-ink-muted" />
          </button>
        </div>
      </div>
    </div>
  );
}
