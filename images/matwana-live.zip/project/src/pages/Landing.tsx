import { useState, useEffect } from 'react';
import { Compass, Share2, Users, MapPin, ArrowRight, Sparkles, ShieldCheck, Heart, Plus } from 'lucide-react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import Button from '@/components/Button';
import FeatureCard from '@/components/FeatureCard';
import MatatuCard from '@/components/MatatuCard';
import { useRouter } from '@/router';
import { features } from '@/data/demoData';
import { fetchMatatus, type MatatuRecord } from '@/lib/matatuApi';

export default function Landing() {
  const { navigate } = useRouter();
  const [previewMatatus, setPreviewMatatus] = useState<MatatuRecord[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchMatatus({ sort: 'most_followed' }).then((result) => {
      if (!result.error) {
        setPreviewMatatus(result.data.slice(0, 4));
      }
      setLoading(false);
    });
  }, []);

  return (
    <div className="min-h-screen bg-white">
      <Navbar />

      {/* Hero */}
      <section className="relative overflow-hidden bg-ink text-white">
        <div className="absolute inset-0">
          <img
            src="https://images.pexels.com/photos/31102079/pexels-photo-31102079.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
            alt="Vibrant matatu in Kenya"
            className="h-full w-full object-cover opacity-30"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-ink via-ink/90 to-ink/40" />
        </div>
        <div className="absolute inset-0 bg-grid opacity-50" />

        <div className="relative mx-auto max-w-7xl px-4 py-20 sm:px-6 md:py-32">
          <div className="max-w-2xl">
            <div className="mb-6 inline-flex items-center gap-2 rounded-full bg-white/10 px-4 py-1.5 backdrop-blur-sm animate-fade-up">
              <Sparkles className="h-4 w-4 text-accent" />
              <span className="text-xs font-medium text-white/90">Kenya's matatu culture, together</span>
            </div>

            <h1 className="font-display text-4xl font-extrabold leading-tight tracking-tight text-balance sm:text-5xl md:text-6xl animate-fade-up" style={{ animationDelay: '0.1s' }}>
              Your Matatu. Your Route.{' '}
              <span className="text-accent">Your Community.</span>
            </h1>

            <p className="mt-6 text-lg leading-relaxed text-white/70 max-w-xl animate-fade-up" style={{ animationDelay: '0.2s' }}>
              Discover matatus across Kenya, share sightings from the road, and connect with
              fellow riders and creators. Matwana Live brings the nganya culture to your fingertips.
            </p>

            <div className="mt-8 flex flex-col gap-3 sm:flex-row animate-fade-up" style={{ animationDelay: '0.3s' }}>
              <Button
                variant="accent"
                size="lg"
                onClick={() => navigate('explore')}
              >
                Explore Matatus
                <ArrowRight className="h-5 w-5" />
              </Button>
              <Button
                variant="primary"
                size="lg"
                onClick={() => navigate('home')}
                className="border border-white/20"
              >
                Join Matwana Live
              </Button>
            </div>

            <p className="mt-6 font-display text-sm font-semibold uppercase tracking-[0.2em] text-accent animate-fade-up" style={{ animationDelay: '0.4s' }}>
              We Ride. We Share. We Connect.
            </p>
          </div>
        </div>

        {/* Marquee */}
        <div className="relative border-t border-white/10 py-4 overflow-hidden">
          <div className="flex animate-marquee whitespace-nowrap">
            {[...Array(2)].map((_, i) => (
              <div key={i} className="flex items-center gap-8 px-4">
                {['Route 33', 'Route 46', 'Route 42', 'Route 125', 'Route 23/24', 'Route 100', 'Route 111', 'Route 44'].map((route) => (
                  <span key={route} className="font-display text-sm font-bold uppercase tracking-wider text-white/30">
                    {route} <span className="text-accent mx-2">/</span>
                  </span>
                ))}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Directory preview */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 md:py-24">
        <div className="mb-10 text-center">
          <span className="text-xs font-bold uppercase tracking-[0.2em] text-primary">Directory Preview</span>
          <h2 className="mt-2 font-display text-3xl font-bold text-ink sm:text-4xl">
            The matatu discovery experience
          </h2>
          <p className="mt-3 text-ink-muted max-w-xl mx-auto">
            Browse matatus by name, route, and destination. Every entry is community-submitted
            and reviewed before verification.
          </p>
        </div>

        {loading ? (
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="rounded-2xl bg-white shadow-card overflow-hidden animate-pulse border border-primary-100/30">
                <div className="h-28 bg-primary-100/40" />
                <div className="p-4 space-y-3">
                  <div className="h-4 bg-gray-200 rounded w-2/3" />
                  <div className="h-3 bg-gray-200 rounded w-1/2" />
                  <div className="h-8 bg-gray-200 rounded-xl" />
                </div>
              </div>
            ))}
          </div>
        ) : previewMatatus.length > 0 ? (
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {previewMatatus.map((matatu) => (
              <MatatuCard
                key={matatu.id}
                matatu={matatu}
                onOpenDetails={() => navigate('details', matatu.id)}
              />
            ))}
          </div>
        ) : (
          <div className="rounded-2xl bg-white p-12 text-center shadow-card border border-primary-100/30">
            <h3 className="font-display text-base font-bold text-ink">No matatus yet</h3>
            <p className="mt-1.5 text-sm text-ink-muted max-w-sm mx-auto">
              The directory is empty. Be the first to add a matatu and start building the community.
            </p>
            <div className="mt-4">
              <Button variant="primary" size="md" onClick={() => navigate('add-matatu')}>
                <Plus className="h-4 w-4" />
                Add a Matatu
              </Button>
            </div>
          </div>
        )}

        <div className="mt-8 text-center">
          <Button variant="outline" size="md" onClick={() => navigate('explore')}>
            Browse full directory
            <ArrowRight className="h-4 w-4" />
          </Button>
        </div>
      </section>

      {/* Features */}
      <section className="bg-primary-50/50 py-16 md:py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <div className="mb-12 text-center">
            <span className="text-xs font-bold uppercase tracking-[0.2em] text-primary">What you can do</span>
            <h2 className="mt-2 font-display text-3xl font-bold text-ink sm:text-4xl">
              Four ways to ride with Matwana
            </h2>
          </div>

          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {features.map((feature, i) => (
              <FeatureCard key={feature.id} feature={feature} index={i} />
            ))}
          </div>
        </div>
      </section>

      {/* Community-first section */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 md:py-24">
        <div className="grid items-center gap-10 md:grid-cols-2">
          <div>
            <div className="mb-4 inline-flex items-center gap-2 rounded-full bg-primary-50 px-4 py-1.5">
              <ShieldCheck className="h-4 w-4 text-primary" />
              <span className="text-xs font-semibold text-primary">Sacco-Neutral & Community-First</span>
            </div>
            <h2 className="font-display text-3xl font-bold text-ink sm:text-4xl leading-tight">
              Built for the culture, not for any single Sacco
            </h2>
            <p className="mt-4 text-ink-muted leading-relaxed">
              Matwana Live is a Sacco-neutral platform. We do not favour any matatu Sacco over
              another. Whether you ride Bungoma Express, Rongai Line, or your local neighbourhood
              crew — every matatu gets the same stage here.
            </p>
            <p className="mt-3 text-ink-muted leading-relaxed">
              Our community-first approach means passengers, enthusiasts, and content creators
              shape the platform together. No bias. No gatekeeping. Just matatu culture, celebrated
              openly.
            </p>

            <div className="mt-6 flex gap-6">
              <div>
                <p className="font-display text-2xl font-extrabold text-primary">100%</p>
                <p className="text-xs text-ink-muted">Sacco-Neutral</p>
              </div>
              <div>
                <p className="font-display text-2xl font-extrabold text-primary">0</p>
                <p className="text-xs text-ink-muted">Bias. Ever.</p>
              </div>
              <div>
                <p className="font-display text-2xl font-extrabold text-primary">All</p>
                <p className="text-xs text-ink-muted">Matatus Welcome</p>
              </div>
            </div>
          </div>

          <div className="relative">
            <img
              src="https://images.pexels.com/photos/30661414/pexels-photo-30661414.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
              alt="Vibrant matatu with artwork in Nairobi"
              className="rounded-3xl shadow-card-hover object-cover w-full h-[400px]"
            />
            <div className="absolute -bottom-4 -left-4 rounded-2xl bg-white p-4 shadow-card-hover max-w-[200px] hidden sm:block animate-float border border-primary-100/40">
              <div className="flex items-center gap-2 mb-1">
                <Heart className="h-4 w-4 text-primary" />
                <span className="font-display text-sm font-bold text-ink">Community Built</span>
              </div>
              <p className="text-xs text-ink-muted">By riders, for riders. Every voice matters.</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="bg-primary py-16 md:py-20">
        <div className="mx-auto max-w-3xl px-4 text-center sm:px-6">
          <h2 className="font-display text-3xl font-extrabold text-white sm:text-4xl text-balance">
            Ready to join the matatu community?
          </h2>
          <p className="mt-4 text-white/70 max-w-xl mx-auto">
            Start exploring matatus, discover new routes, and connect with fellow riders today.
          </p>
          <div className="mt-8 flex flex-col gap-3 sm:flex-row justify-center">
            <Button variant="accent" size="lg" onClick={() => navigate('home')}>
              Join Matwana Live
              <ArrowRight className="h-5 w-5" />
            </Button>
            <Button
              variant="ghost"
              size="lg"
              onClick={() => navigate('explore')}
              className="text-white border border-white/30 hover:bg-white/10"
            >
              Explore Matatus
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
