import { useState, useEffect, useCallback } from 'react';
import {
  TrendingUp, Compass, MapPin, ArrowRight, Sparkles, Plus,
  Navigation, Search, Radio, FlaskConical, ZapOff,
} from 'lucide-react';
import MatatuCard from '@/components/MatatuCard';
import Button from '@/components/Button';
import ImRidingModal from '@/components/ImRidingModal';
import SharingStatusCard from '@/components/SharingStatusCard';
import SharedNowSection from '@/components/SharedNowSection';
import { useRouter } from '@/router';
import {
  fetchMatatus, fetchActiveRidingSessions, getMyActiveSession,
  type MatatuRecord, type RidingSession,
} from '@/lib/matatuApi';
import { isDemoMode, demoMatatus, setDemoMode } from '@/lib/demoMode';

export default function Home() {
  const { navigate } = useRouter();
  const [trending, setTrending] = useState<MatatuRecord[]>([]);
  const [trendingLoading, setTrendingLoading] = useState(true);
  const [sharedSessions, setSharedSessions] = useState<RidingSession[]>([]);
  const [sharedLoading, setSharedLoading] = useState(true);
  const [mySession, setMySession] = useState<RidingSession | null>(null);
  const [sessionLoading, setSessionLoading] = useState(true);
  const [showRidingModal, setShowRidingModal] = useState(false);
  const [demoActive, setDemoActive] = useState(isDemoMode());

  useEffect(() => {
    const onDemoChange = () => setDemoActive(isDemoMode());
    window.addEventListener('demo-mode-change', onDemoChange);
    return () => window.removeEventListener('demo-mode-change', onDemoChange);
  }, []);

  const loadData = useCallback(async () => {
    if (isDemoMode()) {
      setTrending(demoMatatus.slice(0, 4));
      setTrendingLoading(false);
      setSharedSessions([]);
      setSharedLoading(false);
      setMySession(null);
      setSessionLoading(false);
      return;
    }

    fetchMatatus({ sort: 'most_followed' }).then((result) => {
      if (!result.error) setTrending(result.data.slice(0, 4));
      setTrendingLoading(false);
    });

    fetchActiveRidingSessions().then((result) => {
      if (!result.error) setSharedSessions(result.data);
      setSharedLoading(false);
    });

    getMyActiveSession().then((result) => {
      setMySession(result.data);
      setSessionLoading(false);
    });
  }, []);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const handleRidingStarted = (session: RidingSession) => {
    setShowRidingModal(false);
    setMySession(session);
    fetchActiveRidingSessions().then((result) => {
      if (!result.error) setSharedSessions(result.data);
    });
  };

  const handleSessionStopped = () => {
    setMySession(null);
    fetchActiveRidingSessions().then((result) => {
      if (!result.error) setSharedSessions(result.data);
    });
  };

  const primaryActions = [
    { label: 'Find a Matatu', icon: Search, desc: 'Search the directory', page: 'explore' as const },
    { label: 'Share a Matatu', icon: Navigation, desc: 'Share your ride', action: 'riding' as const },
    { label: 'Browse Directory', icon: Compass, desc: 'Browse all matatus', page: 'explore' as const },
    { label: 'Add a Matatu', icon: Plus, desc: 'Suggest a new one', page: 'add-matatu' as const },
    { label: 'Map', icon: MapPin, desc: 'View routes', page: 'map' as const },
  ];

  return (
    <div>
      {/* Demo Mode banner */}
      {demoActive && (
        <div className="mb-4 flex items-center gap-2 rounded-xl bg-amber-50 px-4 py-2.5 border border-amber-100">
          <FlaskConical className="h-4 w-4 text-amber-600 flex-shrink-0" />
          <span className="text-xs font-medium text-amber-800">
            Demo Mode — information is fictional and not live.
          </span>
          <button
            onClick={() => { setDemoMode(false); setDemoActive(false); }}
            className="ml-auto flex items-center gap-1 text-xs font-semibold text-amber-700 hover:underline"
          >
            <ZapOff className="h-3 w-3" />
            Exit Demo
          </button>
        </div>
      )}

      {/* Welcome banner */}
      <div className="relative overflow-hidden rounded-3xl bg-ink p-6 sm:p-8 text-white">
        <div className="absolute inset-0 bg-grid opacity-40" />
        <div className="absolute inset-0 bg-gradient-to-br from-primary/40 to-transparent" />
        <div className="relative">
          <div className="inline-flex items-center gap-2 rounded-full bg-white/10 px-3 py-1 mb-3">
            <Sparkles className="h-3 w-3 text-accent" />
            <span className="text-[10px] font-bold uppercase tracking-wider text-accent">Community-Powered</span>
          </div>
          <h1 className="font-display text-2xl font-extrabold sm:text-3xl">
            Karibu Matwana Live
          </h1>
          <p className="mt-2 text-white/60 text-sm max-w-md">
            Discover and share matatus in real time. Let the community know which matatu you are riding right now.
          </p>
        </div>
      </div>

      {/* I'm Riding — Primary Action */}
      {!sessionLoading && !mySession && (
        <div className="mt-4">
          <button
            onClick={() => setShowRidingModal(true)}
            className="w-full group relative overflow-hidden rounded-3xl bg-gradient-to-br from-primary to-primary-dark p-5 sm:p-6 text-white shadow-card-hover transition-all hover:scale-[1.01] active:scale-[0.99]"
          >
            <div className="absolute inset-0 bg-grid opacity-20" />
            <div className="absolute -right-8 -top-8 h-32 w-32 rounded-full bg-accent/20 blur-2xl group-hover:bg-accent/30 transition-all" />
            <div className="relative flex items-center gap-4">
              <div className="flex h-14 w-14 sm:h-16 sm:w-16 flex-shrink-0 items-center justify-center rounded-2xl bg-accent shadow-glow">
                <Navigation className="h-7 w-7 sm:h-8 sm:w-8 text-white" />
              </div>
              <div className="flex-1 text-left">
                <h2 className="font-display text-xl sm:text-2xl font-extrabold">I'm Riding</h2>
                <p className="mt-0.5 text-sm text-white/70">
                  Share the matatu you're currently riding with the community.
                </p>
              </div>
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-white/15 group-hover:bg-white/25 transition-all">
                <ArrowRight className="h-5 w-5" />
              </div>
            </div>
          </button>
        </div>
      )}

      {/* Active Sharing Status */}
      {!sessionLoading && mySession && (
        <div className="mt-4">
          <SharingStatusCard
            session={mySession}
            onStopped={handleSessionStopped}
            onExpired={handleSessionStopped}
          />
        </div>
      )}

      {/* Matatus Being Shared Now */}
      <div className="mt-6">
        <SharedNowSection
          sessions={sharedSessions}
          loading={sharedLoading}
          onViewMap={() => navigate('map')}
          onViewDetails={(matatuId) => navigate('details', matatuId)}
        />
      </div>

      {/* Primary Actions Grid */}
      <div className="mt-6">
        <p className="text-[11px] font-semibold uppercase tracking-wider text-ink-muted mb-3">Quick Actions</p>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
          {primaryActions.map((action) => {
            const Icon = action.icon;
            const handleClick = () => {
              if (action.action === 'riding') {
                setShowRidingModal(true);
              } else if (action.page) {
                navigate(action.page);
              }
            };
            return (
              <button
                key={action.label}
                onClick={handleClick}
                className="group flex flex-col items-center gap-2 rounded-2xl bg-white p-4 shadow-card transition-all hover:shadow-card-hover hover:-translate-y-0.5 border border-primary-100/30"
              >
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary-50 text-primary transition-colors group-hover:bg-primary group-hover:text-white">
                  <Icon className="h-5 w-5" />
                </div>
                <span className="font-display text-xs font-bold text-ink">{action.label}</span>
                <span className="text-[10px] text-ink-muted text-center">{action.desc}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Trending matatus */}
      <div className="mt-8">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-primary" />
            <h2 className="font-display text-lg font-bold text-ink">Trending Matatus</h2>
          </div>
          <button
            onClick={() => navigate('explore')}
            className="text-xs font-semibold text-primary flex items-center gap-1 hover:gap-2 transition-all"
          >
            See all <ArrowRight className="h-3.5 w-3.5" />
          </button>
        </div>
        {trendingLoading ? (
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="rounded-2xl bg-white shadow-card overflow-hidden animate-pulse">
                <div className="h-28 bg-primary-100/40" />
                <div className="p-4 space-y-3">
                  <div className="h-4 bg-gray-200 rounded w-2/3" />
                  <div className="h-3 bg-gray-200 rounded w-1/2" />
                  <div className="h-8 bg-gray-200 rounded-xl" />
                </div>
              </div>
            ))}
          </div>
        ) : trending.length > 0 ? (
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            {trending.map((matatu) => (
              <MatatuCard
                key={matatu.id}
                matatu={matatu}
                onOpenDetails={() => navigate('details', matatu.id)}
                showTrending
                isDemo={demoActive}
              />
            ))}
          </div>
        ) : (
          <div className="rounded-2xl bg-white p-8 text-center shadow-card border border-primary-100/30">
            <Compass className="mx-auto h-8 w-8 text-primary/40 mb-3" />
            <h3 className="font-display text-base font-bold text-ink">No matatus yet</h3>
            <p className="mt-1.5 text-sm text-ink-muted max-w-sm mx-auto">
              No matatus have been added yet. Be the first person to add one.
            </p>
            <div className="mt-4">
              <Button variant="primary" size="sm" onClick={() => navigate('add-matatu')}>
                <Plus className="h-4 w-4" />
                Add a Matatu
              </Button>
            </div>
          </div>
        )}
      </div>

      {/* Community note */}
      <div className="mt-8 rounded-2xl bg-primary-50 p-5">
        <div className="flex items-start gap-3">
          <Sparkles className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
          <div>
            <h3 className="font-display text-sm font-bold text-ink">Sacco-Neutral Community</h3>
            <p className="mt-1 text-xs text-ink-muted leading-relaxed">
              Matwana Live celebrates all matatus equally. No favouritism, no bias. Every Sacco
              gets the same stage. All matatus are added by the community and reviewed before verification.
            </p>
          </div>
        </div>
      </div>

      {/* I'm Riding Modal */}
      <ImRidingModal
        open={showRidingModal}
        onClose={() => setShowRidingModal(false)}
        onStarted={handleRidingStarted}
      />
    </div>
  );
}
