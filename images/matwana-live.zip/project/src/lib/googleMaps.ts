/// <reference types="google.maps" />

let mapsLoaded = false;
let mapsLoadPromise: Promise<typeof google.maps | null> | null = null;
let loadError: string | null = null;

export function getGoogleMapsApiKey(): string | undefined {
  return import.meta.env.VITE_GOOGLE_MAPS_API_KEY as string | undefined;
}

export function hasGoogleMapsKey(): boolean {
  return !!getGoogleMapsApiKey();
}

export function loadGoogleMaps(): Promise<typeof google.maps | null> {
  const apiKey = getGoogleMapsApiKey();

  if (!apiKey) {
    loadError = 'Google Maps API key is not configured. Set VITE_GOOGLE_MAPS_API_KEY in your environment variables.';
    return Promise.resolve(null);
  }

  if (typeof google !== 'undefined' && google.maps) {
    return Promise.resolve(google.maps);
  }

  if (mapsLoaded && mapsLoadPromise) {
    return mapsLoadPromise;
  }

  mapsLoadPromise = new Promise((resolve) => {
    const callbackName = `__googleMapsInit_${Date.now()}`;
    (window as unknown as Record<string, unknown>)[callbackName] = () => {
      mapsLoaded = true;
      delete (window as unknown as Record<string, unknown>)[callbackName];
      resolve(google.maps);
    };

    const script = document.createElement('script');
    script.src = `https://maps.googleapis.com/maps/api/js?key=${apiKey}&libraries=places&callback=${callbackName}`;
    script.async = true;
    script.defer = true;
    script.onerror = () => {
      loadError = 'Failed to load Google Maps. Check your API key and network connection.';
      mapsLoaded = false;
      mapsLoadPromise = null;
      delete (window as unknown as Record<string, unknown>)[callbackName];
      resolve(null);
    };

    document.head.appendChild(script);
  });

  return mapsLoadPromise;
}

export function getMapsLoadError(): string | null {
  return loadError;
}

export type MarkerLocationStatus = 'live' | 'recent' | 'verified' | 'unverified' | 'expired';

export interface MapMarkerData {
  id: string;
  matatuId: string;
  matatuName: string;
  routeNumber: string | null;
  destination: string | null;
  latitude: number;
  longitude: number;
  locationStatus: MarkerLocationStatus;
  lastUpdated: string | null;
  riderCount: number;
  stageOrLandmark?: string | null;
  isCommunityReport?: boolean;
  color?: string;
}

export function getStatusConfig(status: MarkerLocationStatus): {
  label: string;
  color: string;
  dotClass: string;
  bgClass: string;
  textClass: string;
} {
  switch (status) {
    case 'live':
      return {
        label: 'LIVE',
        color: '#22c55e',
        dotClass: 'animate-pulse',
        bgClass: 'bg-green-100',
        textClass: 'text-green-700',
      };
    case 'recent':
      return {
        label: 'RECENT',
        color: '#f59e0b',
        dotClass: '',
        bgClass: 'bg-amber-100',
        textClass: 'text-amber-700',
      };
    case 'verified':
      return {
        label: 'VERIFIED',
        color: '#2563eb',
        dotClass: '',
        bgClass: 'bg-primary-100',
        textClass: 'text-primary',
      };
    case 'unverified':
      return {
        label: 'UNVERIFIED',
        color: '#9ca3af',
        dotClass: '',
        bgClass: 'bg-gray-100',
        textClass: 'text-gray-500',
      };
    case 'expired':
      return {
        label: 'EXPIRED',
        color: '#ef4444',
        dotClass: '',
        bgClass: 'bg-red-100',
        textClass: 'text-red-600',
      };
  }
}
