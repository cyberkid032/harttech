import { supabase } from '@/lib/supabase';

export type VerificationStatus = 'verified' | 'community_reported' | 'pending' | 'unverified';

export interface MatatuRecord {
  id: string;
  name: string;
  route_number: string | null;
  destination: string;
  sacco: string | null;
  stage: string | null;
  registration_number: string | null;
  capacity: string | null;
  description: string | null;
  cover_image_url: string | null;
  profile_image_url: string | null;
  verification_status: VerificationStatus;
  trending: boolean;
  follower_count: number;
  sighting_count: number;
  last_activity_at: string;
  color: string;
  created_at: string;
  updated_at: string;
  aliases?: string[];
  photos?: MatatuPhoto[];
  sightings?: CommunitySighting[];
  verifications?: VerificationRecord[];
}

export interface MatatuPhoto {
  id: string;
  matatu_id: string;
  photo_url: string;
  caption: string | null;
  is_cover: boolean;
  created_at: string;
}

export interface CommunitySighting {
  id: string;
  matatu_id: string;
  location: string | null;
  route_observed: string | null;
  notes: string | null;
  reporter_identifier: string | null;
  sighting_time: string;
  created_at: string;
}

export interface VerificationRecord {
  id: string;
  matatu_id: string;
  verification_type: string;
  status: string;
  verified_by: string | null;
  notes: string | null;
  created_at: string;
}

export interface NewMatatuInput {
  name: string;
  alias: string;
  route_number: string;
  destination: string;
  sacco: string;
  registration_number: string;
  description: string;
}

export type SortOption = 'popular' | 'recent' | 'most_followed';
export type VerificationFilter = 'all' | 'verified' | 'community_reported' | 'pending' | 'unverified';

export async function fetchMatatus(opts?: {
  search?: string;
  routeFilter?: string;
  verificationFilter?: VerificationFilter;
  sort?: SortOption;
}): Promise<{ data: MatatuRecord[]; error: string | null }> {
  let query = supabase
    .from('matatus')
    .select('*');

  if (opts?.search) {
    const s = opts.search.trim();
    const isDestinationSearch = /^(any\s+matatu\s+to\s+|matatus?\s+to\s+)/i.test(s);
    const searchTerm = isDestinationSearch
      ? s.replace(/^(any\s+matatu\s+to\s+|matatus?\s+to\s+)/i, '').trim()
      : s;
    query = query.or(
      `name.ilike.%${searchTerm}%,destination.ilike.%${searchTerm}%,route_number.ilike.%${searchTerm}%,sacco.ilike.%${searchTerm}%,stage.ilike.%${searchTerm}%`
    );
  }

  if (opts?.routeFilter && opts.routeFilter !== 'all') {
    query = query.eq('route_number', opts.routeFilter);
  }

  if (opts?.verificationFilter && opts.verificationFilter !== 'all') {
    query = query.eq('verification_status', opts.verificationFilter);
  }

  switch (opts?.sort) {
    case 'recent':
      query = query.order('last_activity_at', { ascending: false });
      break;
    case 'most_followed':
      query = query.order('follower_count', { ascending: false });
      break;
    default:
      query = query.order('follower_count', { ascending: false, nullsFirst: false })
        .order('name', { ascending: true });
  }

  const { data, error } = await query.limit(50);

  if (error) return { data: [], error: error.message };

  const matatus = data as MatatuRecord[];

  if (matatus.length > 0) {
    const ids = matatus.map((m) => m.id);
    const [{ data: aliasData }, { data: photoData }] = await Promise.all([
      supabase.from('matatu_aliases').select('matatu_id, alias').in('matatu_id', ids),
      supabase.from('matatu_photos').select('*').in('matatu_id', ids),
    ]);

    const aliasMap = new Map<string, string[]>();
    for (const a of aliasData || []) {
      const existing = aliasMap.get(a.matatu_id) || [];
      existing.push(a.alias);
      aliasMap.set(a.matatu_id, existing);
    }

    const photoMap = new Map<string, MatatuPhoto[]>();
    for (const p of photoData || []) {
      const existing = photoMap.get(p.matatu_id) || [];
      existing.push(p as MatatuPhoto);
      photoMap.set(p.matatu_id, existing);
    }

    matatus.forEach((m) => {
      m.aliases = aliasMap.get(m.id) || [];
      m.photos = photoMap.get(m.id) || [];
    });
  }

  return { data: matatus, error: null };
}

export async function fetchMatatuById(id: string): Promise<{ data: MatatuRecord | null; error: string | null }> {
  const { data, error } = await supabase
    .from('matatus')
    .select('*')
    .eq('id', id)
    .maybeSingle();

  if (error) return { data: null, error: error.message };
  if (!data) return { data: null, error: 'Matatu not found' };

  const matatu = data as MatatuRecord;

  const [{ data: aliases }, { data: photos }, { data: sightings }, { data: verifications }] = await Promise.all([
    supabase.from('matatu_aliases').select('alias').eq('matatu_id', id),
    supabase.from('matatu_photos').select('*').eq('matatu_id', id),
    supabase.from('community_sightings').select('*').eq('matatu_id', id).order('sighting_time', { ascending: false }).limit(10),
    supabase.from('matatu_verifications').select('*').eq('matatu_id', id).order('created_at', { ascending: false }),
  ]);

  matatu.aliases = (aliases || []).map((a: { alias: string }) => a.alias);
  matatu.photos = (photos || []) as MatatuPhoto[];
  matatu.sightings = (sightings || []) as CommunitySighting[];
  matatu.verifications = (verifications || []) as VerificationRecord[];

  return { data: matatu, error: null };
}

export async function fetchRouteNumbers(): Promise<string[]> {
  const { data, error } = await supabase
    .from('matatus')
    .select('route_number')
    .not('route_number', 'is', null)
    .order('route_number');

  if (error || !data) return [];

  const unique = [...new Set(data.map((d: { route_number: string }) => d.route_number).filter(Boolean))] as string[];
  return unique;
}

export async function searchByAlias(search: string): Promise<string[]> {
  const { data, error } = await supabase
    .from('matatu_aliases')
    .select('matatu_id')
    .ilike('alias', `%${search}%`);

  if (error || !data) return [];
  return data.map((d: { matatu_id: string }) => d.matatu_id);
}

export async function toggleFollow(matatuId: string, following: boolean): Promise<{ error: string | null }> {
  const identifier = getOrCreateIdentifier();

  if (following) {
    const { error } = await supabase
      .from('matatu_followers')
      .delete()
      .eq('matatu_id', matatuId)
      .eq('follower_identifier', identifier);
    if (error) return { error: error.message };

    try { await supabase.rpc('decrement_follower_count', { matatu_id: matatuId }); } catch {}
  } else {
    const { error } = await supabase
      .from('matatu_followers')
      .insert({ matatu_id: matatuId, follower_identifier: identifier });
    if (error) return { error: error.message };

    try { await supabase.rpc('increment_follower_count', { matatu_id: matatuId }); } catch {}
  }

  return { error: null };
}

export async function submitMatatuReport(
  matatuId: string,
  reportType: string,
  details: string
): Promise<{ error: string | null }> {
  const { error } = await supabase
    .from('matatu_reports')
    .insert({
      matatu_id: matatuId,
      report_type: reportType,
      details,
      reporter_identifier: getOrCreateIdentifier(),
    });

  return { error: error?.message || null };
}

export async function submitNewMatatu(input: NewMatatuInput): Promise<{ data: MatatuRecord | null; error: string | null }> {
  const { data, error } = await supabase
    .from('matatus')
    .insert({
      name: input.name,
      route_number: input.route_number,
      destination: input.destination,
      sacco: input.sacco || null,
      registration_number: input.registration_number || null,
      description: input.description || null,
      verification_status: 'pending',
      color: '#1d4ed8',
    })
    .select('*')
    .maybeSingle();

  if (error) return { data: null, error: error.message };
  if (!data) return { data: null, error: 'Failed to create matatu' };

  const matatu = data as MatatuRecord;

  if (input.alias) {
    await supabase.from('matatu_aliases').insert({
      matatu_id: matatu.id,
      alias: input.alias,
    });
  }

  await supabase.from('matatu_verifications').insert({
    matatu_id: matatu.id,
    verification_type: 'self_claimed',
    status: 'pending',
    notes: 'Submitted via Add Matatu form',
  });

  return { data: matatu, error: null };
}

export function getOrCreateIdentifier(): string {
  const key = 'matwana_user_id';
  let id = localStorage.getItem(key);
  if (!id) {
    id = `local_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`;
    localStorage.setItem(key, id);
  }
  return id;
}


// ─── Riding Sessions ───────────────────────────────────────────────

export type RidingSessionStatus = 'active' | 'stopped' | 'expired';

export interface RidingSession {
  id: string;
  matatu_id: string;
  route_or_destination: string | null;
  stage_or_landmark: string | null;
  note: string | null;
  latitude: number | null;
  longitude: number | null;
  location_accuracy: number | null;
  location_consent: boolean;
  started_at: string;
  expires_at: string;
  last_location_update: string | null;
  status: RidingSessionStatus;
  matatu_name?: string;
  matatu_route_number?: string | null;
  matatu_destination?: string | null;
  matatu_color?: string;
  active_rider_count?: number;
}

export interface StartRidingInput {
  matatuId: string;
  routeOrDestination?: string;
  stageOrLandmark?: string;
  note?: string;
  latitude?: number;
  longitude?: number;
  accuracy?: number;
  locationConsent: boolean;
}

export async function startRidingSession(input: StartRidingInput): Promise<{ data: RidingSession | null; error: string | null }> {
  const identifier = getOrCreateIdentifier();
  const expiresAt = new Date(Date.now() + 2 * 60 * 60 * 1000).toISOString();

  const { data, error } = await supabase
    .from('riding_sessions')
    .insert({
      matatu_id: input.matatuId,
      user_identifier: identifier,
      route_or_destination: input.routeOrDestination || null,
      stage_or_landmark: input.stageOrLandmark || null,
      note: input.note || null,
      latitude: input.latitude || null,
      longitude: input.longitude || null,
      location_accuracy: input.accuracy || null,
      location_consent: input.locationConsent,
      expires_at: expiresAt,
      last_location_update: input.locationConsent ? new Date().toISOString() : null,
      status: 'active',
    })
    .select('*')
    .maybeSingle();

  if (error) return { data: null, error: error.message };
  if (!data) return { data: null, error: 'Failed to start riding session' };

  return { data: data as RidingSession, error: null };
}

export async function stopRidingSession(sessionId: string): Promise<{ error: string | null }> {
  const { error } = await supabase
    .from('riding_sessions')
    .update({ status: 'stopped', updated_at: new Date().toISOString() })
    .eq('id', sessionId)
    .eq('user_identifier', getOrCreateIdentifier());

  return { error: error?.message || null };
}

export async function updateRidingLocation(sessionId: string, lat: number, lng: number, accuracy?: number): Promise<{ error: string | null }> {
  const { error } = await supabase
    .from('riding_sessions')
    .update({
      latitude: lat,
      longitude: lng,
      location_accuracy: accuracy || null,
      last_location_update: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    })
    .eq('id', sessionId)
    .eq('user_identifier', getOrCreateIdentifier());

  return { error: error?.message || null };
}

export async function getMyActiveSession(): Promise<{ data: RidingSession | null; error: string | null }> {
  const { data, error } = await supabase
    .from('riding_sessions')
    .select('*')
    .eq('user_identifier', getOrCreateIdentifier())
    .eq('status', 'active')
    .order('created_at', { ascending: false })
    .limit(1)
    .maybeSingle();

  if (error) return { data: null, error: error.message };

  if (!data) return { data: null, error: null };

  const session = data as RidingSession;

  if (new Date(session.expires_at).getTime() < Date.now()) {
    await supabase
      .from('riding_sessions')
      .update({ status: 'expired', updated_at: new Date().toISOString() })
      .eq('id', session.id);
    return { data: null, error: null };
  }

  const matatuResult = await fetchMatatuById(session.matatu_id);
  if (matatuResult.data) {
    session.matatu_name = matatuResult.data.name;
    session.matatu_route_number = matatuResult.data.route_number;
    session.matatu_destination = matatuResult.data.destination;
    session.matatu_color = matatuResult.data.color;
  }

  return { data: session, error: null };
}

export async function fetchActiveRidingSessions(): Promise<{ data: RidingSession[]; error: string | null }> {
  const { data, error } = await supabase
    .from('riding_sessions')
    .select(`
      *,
      matatus!inner(name, route_number, destination, color)
    `)
    .eq('status', 'active')
    .order('last_location_update', { ascending: false, nullsFirst: false })
    .limit(20);

  if (error) return { data: [], error: error.message };

  const sessions = (data || []).filter((row) => {
    return new Date(row.expires_at).getTime() > Date.now();
  }) as unknown as Array<RidingSession & { matatus: { name: string; route_number: string | null; destination: string; color: string } }>;

  const result: RidingSession[] = sessions.map((row) => {
    const { matatus, ...session } = row;
    return {
      ...session,
      matatu_name: matatus?.name,
      matatu_route_number: matatus?.route_number,
      matatu_destination: matatus?.destination,
      matatu_color: matatus?.color,
    };
  });

  return { data: result, error: null };
}

export function getLocationStatus(session: RidingSession): 'live' | 'recent' | 'unverified' {
  if (!session.last_location_update) return 'unverified';
  const ageMs = Date.now() - new Date(session.last_location_update).getTime();
  if (ageMs < 5 * 60 * 1000) return 'live';
  if (ageMs < 30 * 60 * 1000) return 'recent';
  return 'unverified';
}

export function getTimeRemaining(expiresAt: string): { minutes: number; seconds: number; expired: boolean } {
  const remaining = new Date(expiresAt).getTime() - Date.now();
  if (remaining <= 0) return { minutes: 0, seconds: 0, expired: true };
  const minutes = Math.floor(remaining / 60000);
  const seconds = Math.floor((remaining % 60000) / 1000);
  return { minutes, seconds, expired: false };
}

export async function fetchRiderCounts(matatuIds: string[]): Promise<Map<string, number>> {
  const counts = new Map<string, number>();
  if (matatuIds.length === 0) return counts;

  const { data, error } = await supabase
    .from('riding_sessions')
    .select('matatu_id')
    .in('matatu_id', matatuIds)
    .eq('status', 'active');

  if (error || !data) return counts;

  for (const row of data as { matatu_id: string }[]) {
    counts.set(row.matatu_id, (counts.get(row.matatu_id) || 0) + 1);
  }
  return counts;
}

export function parseDestinationSearch(query: string): { isDestinationSearch: boolean; destination: string | null } {
  const match = query.match(/^(?:any\s+matatu\s+to\s+|matatus?\s+to\s+)(.+)/i);
  if (match) {
    return { isDestinationSearch: true, destination: match[1].trim() };
  }
  return { isDestinationSearch: false, destination: null };
}

export async function fetchDestinations(): Promise<string[]> {
  const { data, error } = await supabase
    .from('matatus')
    .select('destination')
    .not('destination', 'is', null);

  if (error || !data) return [];

  const dests = new Set<string>();
  for (const row of data as { destination: string }[]) {
    if (row.destination) {
      dests.add(row.destination);
      const parts = row.destination.split(/[→\-\s]+/).map((p) => p.trim()).filter(Boolean);
      parts.forEach((p) => dests.add(p));
    }
  }
  return Array.from(dests).sort();
}

export interface ManualSightingInput {
  matatuId: string;
  location: string;
  routeObserved?: string;
  notes?: string;
}

export async function submitManualSighting(input: ManualSightingInput): Promise<{ error: string | null }> {
  const { error } = await supabase
    .from('community_sightings')
    .insert({
      matatu_id: input.matatuId,
      location: input.location || null,
      route_observed: input.routeObserved || null,
      notes: input.notes || null,
      reporter_identifier: getOrCreateIdentifier(),
      sighting_time: new Date().toISOString(),
    });

  return { error: error?.message || null };
}

export async function fetchSightingsForMap(matatuIds?: string[]): Promise<{ data: CommunitySighting[]; error: string | null }> {
  let query = supabase
    .from('community_sightings')
    .select('*')
    .order('sighting_time', { ascending: false })
    .limit(50);

  if (matatuIds && matatuIds.length > 0) {
    query = query.in('matatu_id', matatuIds);
  }

  const { data, error } = await query;

  if (error) return { data: [], error: error.message };
  return { data: (data || []) as CommunitySighting[], error: null };
}
