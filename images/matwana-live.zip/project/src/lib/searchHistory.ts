const HISTORY_KEY = 'matwana_search_history';
const MAX_HISTORY = 10;

export function getSearchHistory(): string[] {
  try {
    const raw = localStorage.getItem(HISTORY_KEY);
    if (!raw) return [];
    return JSON.parse(raw) as string[];
  } catch {
    return [];
  }
}

export function addSearchHistory(term: string): void {
  const trimmed = term.trim();
  if (!trimmed) return;
  let history = getSearchHistory();
  history = history.filter((h) => h.toLowerCase() !== trimmed.toLowerCase());
  history.unshift(trimmed);
  history = history.slice(0, MAX_HISTORY);
  localStorage.setItem(HISTORY_KEY, JSON.stringify(history));
}

export function clearSearchHistory(): void {
  localStorage.removeItem(HISTORY_KEY);
  window.dispatchEvent(new CustomEvent('search-history-change'));
}

export function getSearchSuggestions(availableTerms: string[]): string[] {
  const history = getSearchHistory();
  const lowerHistory = history.map((h) => h.toLowerCase());
  const suggestions = availableTerms.filter(
    (t) => !lowerHistory.includes(t.toLowerCase())
  ).slice(0, 5);
  return [...history.slice(0, 5), ...suggestions];
}
