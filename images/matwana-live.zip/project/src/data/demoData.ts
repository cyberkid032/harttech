import type { Feature, CreateOption, Destination } from '@/types';

export const demoDestinations: Destination[] = [
  { id: 'embakasi', name: 'Embakasi', icon: 'Building2' },
  { id: 'cbd', name: 'CBD', icon: 'Building' },
  { id: 'westlands', name: 'Westlands', icon: 'Briefcase' },
  { id: 'rongai', name: 'Rongai', icon: 'Mountain' },
  { id: 'kasarani', name: 'Kasarani', icon: 'Trophy' },
  { id: 'thika', name: 'Thika', icon: 'Factory' },
  { id: 'ngong', name: 'Ngong', icon: 'Trees' },
];

export const features: Feature[] = [
  {
    id: 'discover',
    title: 'Discover',
    description:
      'Find matatus by name, route number, or destination. Browse the latest nganyas hitting the road across Nairobi and beyond.',
    icon: 'Compass',
    accent: false,
  },
  {
    id: 'share',
    title: 'Share',
    description:
      'Post matatu sightings, short clips, and route updates. Keep the community in the loop about what is on the road today.',
    icon: 'Share2',
    accent: true,
  },
  {
    id: 'connect',
    title: 'Connect',
    description:
      'Follow riders, enthusiasts, and creators who share your routes. Build your crew and stay plugged into matatu culture.',
    icon: 'Users',
    accent: false,
  },
  {
    id: 'track',
    title: 'Track',
    description:
      'Find your desired matatu in real time. Live GPS tracking arrives in a future step — the foundation is being laid now.',
    icon: 'MapPin',
    accent: false,
  },
];

export const createOptions: CreateOption[] = [
  {
    id: 'sighting',
    title: 'Share a Matatu Sighting',
    description:
      'Spot a nganya on the road? Let the community know which matatu, where, and what route it was on.',
    icon: 'Eye',
    badge: 'Coming Soon',
  },
  {
    id: 'video',
    title: 'Upload a Short Video',
    description:
      'Share a clip of the latest matatu art, sound system, or a moment from your ride.',
    icon: 'Video',
    badge: 'Coming Soon',
  },
  {
    id: 'question',
    title: 'Ask the Community',
    description:
      'Looking for which matatu plies a route at a certain time? Ask fellow riders and get answers.',
    icon: 'MessageCircleQuestion',
    badge: 'Coming Soon',
  },
];

export const demoNotifications = [
  {
    id: '1',
    title: 'Welcome to Matwana Live',
    message: 'Your account is ready. Start exploring matatus on routes near you.',
    time: 'Just now',
    unread: true,
    type: 'system' as const,
  },
  {
    id: '2',
    title: 'Add a matatu',
    message: 'Know a matatu that is not in the directory yet? Add it and help the community grow.',
    time: '5 min ago',
    unread: true,
    type: 'matatu' as const,
  },
  {
    id: '3',
    title: 'Community update',
    message: 'Matwana Live is Sacco-neutral. We celebrate all matatus equally.',
    time: '1 hour ago',
    unread: false,
    type: 'system' as const,
  },
  {
    id: '4',
    title: 'Feature preview: Track',
    message: 'Real-time GPS tracking is being designed. Stay tuned for the next step.',
    time: '1 day ago',
    unread: false,
    type: 'system' as const,
  },
];
